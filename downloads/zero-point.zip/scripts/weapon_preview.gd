class_name WeaponPreview
extends Control

## 军械库中央的武器结构预览。后续替换为真实渲染 / 3D 预览视口。

var weapon: Dictionary = {}
var font: Font
var accent := Color("#ff6b2c")

func setup(p_font: Font) -> void:
	font = p_font
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	queue_redraw()

func set_weapon(def: Dictionary) -> void:
	weapon = def
	var slot: String = String(def.get("slot", "primary"))
	accent = Color("#ff6b2c") if slot == "primary" else Color("#42d8ff")
	queue_redraw()

func _draw() -> void:
	var w := size.x
	var h := size.y
	draw_rect(Rect2(Vector2.ZERO, size), Color(0.02, 0.033, 0.042, 0.65))
	for i in range(0, int(w), 24):
		draw_line(Vector2(i, 0), Vector2(i, h), Color(0.4, 0.55, 0.6, 0.04), 1.0)
	for j in range(0, int(h), 24):
		draw_line(Vector2(0, j), Vector2(w, j), Color(0.4, 0.55, 0.6, 0.04), 1.0)
	if weapon.is_empty():
		return
	var name: String = weapon["name"]
	draw_string(font, Vector2(18, 24), "WEAPON SCHEMATIC / 灰盒占位", HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color(0.55, 0.65, 0.7, 0.7))
	draw_string(font, Vector2(18, 47), name, HORIZONTAL_ALIGNMENT_LEFT, -1, 15, Color(0.9, 0.94, 0.95))
	draw_string(font, Vector2(w - 220, 24), "%s  /  %s" % [weapon.get("class_label", ""), weapon.get("mode_label", "")], HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color(0.55, 0.65, 0.7, 0.7))

	var cx := w * 0.52
	var cy := h * 0.58
	var scale := minf(w / 760.0, h / 210.0)
	var gun_len := 360.0 * scale
	# 枪身
	draw_rect(Rect2(cx - gun_len * 0.45, cy - 10 * scale, gun_len * 0.45, 20 * scale), Color("#3d474c"))
	draw_rect(Rect2(cx, cy - 8 * scale, gun_len * 0.42, 16 * scale), Color("#4d595e"))
	draw_rect(Rect2(cx - gun_len * 0.5, cy - 6 * scale, gun_len * 0.1, 12 * scale), Color("#222a2e"))
	# 枪管
	draw_rect(Rect2(cx + gun_len * 0.42, cy - 3 * scale, gun_len * 0.34, 5 * scale), Color("#69767b"))
	# 弹匣 / 握把
	draw_rect(Rect2(cx - 8 * scale, cy + 8 * scale, 26 * scale, 48 * scale), Color("#252d31"))
	draw_rect(Rect2(cx + 55 * scale, cy + 8 * scale, 18 * scale, 38 * scale), Color("#252d31"))
	# 瞄具
	draw_rect(Rect2(cx - 20 * scale, cy - 26 * scale, 48 * scale, 14 * scale), Color("#222a2e"))
	draw_circle(Vector2(cx + 4 * scale, cy - 19 * scale), 4 * scale, accent)
	# 队伍识别条
	draw_rect(Rect2(cx - gun_len * 0.3, cy - 3 * scale, gun_len * 0.38, 3 * scale), accent)
	# 尺寸标注
	draw_line(Vector2(cx - gun_len * 0.5, cy + 72 * scale), Vector2(cx + gun_len * 0.76, cy + 72 * scale), Color(0.5, 0.65, 0.7, 0.25), 1.0)
	draw_string(font, Vector2(cx - gun_len * 0.5, cy + 90 * scale), "ZP-01 // FIELD MODULAR PLATFORM", HORIZONTAL_ALIGNMENT_LEFT, -1, 7, Color(0.5, 0.65, 0.7, 0.45))

	# 数值条
	var bars := GameConfig.weapon_bars(weapon)
	var y := h - 30
	var x := 18
	for row in [["伤害", bars["damage"]], ["控枪", bars["control"]], ["射程", bars["range"]]]:
		draw_string(font, Vector2(x, y + 8), String(row[0]), HORIZONTAL_ALIGNMENT_LEFT, -1, 7, Color(0.55, 0.65, 0.7))
		draw_rect(Rect2(x + 30, y + 3, 90, 3), Color(1, 1, 1, 0.08))
		draw_rect(Rect2(x + 30, y + 3, 90 * float(row[1]), 3), Color(0.3, 0.8, 0.95, 0.85))
		x += 160
