class_name Bomb
extends Node3D

## 黑匣炸弹状机：carried ?dropped ?planted ?defused / exploded
## 安放 10 秒引?40 秒拆?10 秒（拆弹?5 秒）?
var game = null
var state = "idle"
var carrier = null
var site: Dictionary = {}
var remaining = 40.0
var planting_actor = null
var plant_progress = 0.0
var plant_anchor = Vector3.ZERO
var defusing_actor = null
var defuse_progress = 0.0
var defuse_anchor = Vector3.ZERO
var defuse_total = 10.0
var planted_by = null
var defused_by = null

var body: MeshInstance3D
var led: MeshInstance3D
var led_mat: StandardMaterial3D
var ring: MeshInstance3D
var light: OmniLight3D
var beep_timer = 0.0
var pulse = 0.0
var plant_tick = 0.0
var defuse_tick = 0.0

func setup(game_ref: Node) -> void:
	game = game_ref
	_build_mesh()
	reset()

func _apply_bomb_texture(mat: StandardMaterial3D, tint: Color, uv: float) -> void:
	## C4 贴图：assets/textures/props/bomb（tools/gen_textures.py 生成）
	var dir := "res://assets/textures/props/bomb/"
	if not ResourceLoader.exists(dir + "albedo.png"):
		return
	mat.albedo_texture = load(dir + "albedo.png")
	mat.albedo_color = tint
	if ResourceLoader.exists(dir + "roughness.png"):
		mat.roughness_texture = load(dir + "roughness.png")
		mat.roughness = 1.0
	if ResourceLoader.exists(dir + "metallic.png"):
		mat.metallic_texture = load(dir + "metallic.png")
		mat.metallic = 1.0
	if ResourceLoader.exists(dir + "normal.png"):
		mat.normal_enabled = true
		mat.normal_texture = load(dir + "normal.png")
		mat.normal_scale = 0.8
	if ResourceLoader.exists(dir + "emission.png"):
		mat.emission_enabled = true
		mat.emission_texture = load(dir + "emission.png")
		mat.emission = Color.WHITE
		mat.emission_energy_multiplier = 1.0
	mat.uv1_scale = Vector3(uv, uv, uv)


func _build_mesh() -> void:
	body = MeshInstance3D.new()
	var box = BoxMesh.new()
	box.size = Vector3(0.5, 0.32, 0.28)
	body.mesh = box
	body.position.y = 0.16
	var body_mat = StandardMaterial3D.new()
	body_mat.albedo_color = Color("#161c1f")
	body_mat.roughness = 0.55
	body_mat.metallic = 0.52
	_apply_bomb_texture(body_mat, Color.WHITE, 1.6)
	body.material_override = body_mat
	body.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	add_child(body)

	var top = MeshInstance3D.new()
	var top_box = BoxMesh.new()
	top_box.size = Vector3(0.34, 0.06, 0.2)
	top.mesh = top_box
	top.position.y = 0.34
	var dark = StandardMaterial3D.new()
	dark.albedo_color = Color("#0a0e10")
	dark.roughness = 0.78
	_apply_bomb_texture(dark, Color(0.55, 0.55, 0.55), 2.0)
	top.material_override = dark
	add_child(top)

	var strip = MeshInstance3D.new()
	var strip_box = BoxMesh.new()
	strip_box.size = Vector3(0.52, 0.045, 0.29)
	strip.mesh = strip_box
	strip.position.y = 0.22
	var orange = StandardMaterial3D.new()
	orange.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	orange.albedo_color = Color("#ff6b2c")
	strip.material_override = orange
	add_child(strip)

	var antenna = MeshInstance3D.new()
	var antenna_mesh = CylinderMesh.new()
	antenna_mesh.top_radius = 0.01
	antenna_mesh.bottom_radius = 0.01
	antenna_mesh.height = 0.38
	antenna_mesh.radial_segments = 5
	antenna.mesh = antenna_mesh
	antenna.position = Vector3(0.19, 0.5, 0.03)
	antenna.material_override = dark
	add_child(antenna)

	led = MeshInstance3D.new()
	var led_mesh = SphereMesh.new()
	led_mesh.radius = 0.035
	led_mesh.height = 0.07
	led_mesh.radial_segments = 8
	led_mesh.rings = 4
	led.mesh = led_mesh
	led.position = Vector3(0.19, 0.7, 0.03)
	led_mat = StandardMaterial3D.new()
	led_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	led_mat.albedo_color = Color("#ff3a20")
	led_mat.emission_enabled = true
	led_mat.emission = Color("#ff3a20")
	led_mat.emission_energy_multiplier = 3.0
	led.material_override = led_mat
	add_child(led)

	ring = MeshInstance3D.new()
	var torus = TorusMesh.new()
	torus.inner_radius = 1.9
	torus.outer_radius = 2.08
	torus.rings = 48
	torus.ring_segments = 4
	ring.mesh = torus
	ring.position.y = 0.02
	var ring_mat = StandardMaterial3D.new()
	ring_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	ring_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	ring_mat.albedo_color = Color(1.0, 0.42, 0.15, 0.6)
	ring_mat.emission_enabled = true
	ring_mat.emission = Color("#ff6b2c")
	ring_mat.emission_energy_multiplier = 1.2
	ring.material_override = ring_mat
	add_child(ring)

	light = OmniLight3D.new()
	light.light_color = Color("#ff5b2d")
	light.light_energy = 0.0
	light.omni_range = 10.0
	light.position.y = 0.9
	add_child(light)
	visible = false
	ring.visible = false

func reset() -> void:
	state = "idle"
	carrier = null
	site = {}
	remaining = 40.0
	planting_actor = null
	plant_progress = 0.0
	defusing_actor = null
	defuse_progress = 0.0
	planted_by = null
	defused_by = null
	visible = false
	ring.visible = false
	light.light_energy = 0.0
	beep_timer = 0.0

func give_to(actor) -> void:
	if actor == null or not actor.alive:
		return
	reset()
	state = "carried"
	carrier = actor
	global_position = actor.global_position
	actor.bomb_carried = true
	if actor.has_method("set_bomb_carrier"):
		actor.set_bomb_carrier(true)
	if actor.is_player:
		game.ui.update_vitals(actor)

func drop(source = null) -> void:
	if state != "carried":
		return
	var actor = source if source != null else carrier
	if actor != null:
		actor.bomb_carried = false
		if actor.has_method("set_bomb_carrier"):
			actor.set_bomb_carrier(false)
	global_position = actor.global_position if actor != null else global_position
	global_position.y = 0.0
	carrier = null
	planting_actor = null
	plant_progress = 0.0
	state = "dropped"
	visible = true
	ring.visible = true
	light.light_energy = 6.0
	if actor and actor.is_player:
		game.ui.update_vitals(actor)

func pickup(actor) -> bool:
	if state != "dropped" or actor == null or not actor.alive:
		return false
	if global_position.distance_to(actor.global_position) > float(GameConfig.MATCH["bomb_pickup_range"]):
		return false
	state = "carried"
	carrier = actor
	actor.bomb_carried = true
	if actor.has_method("set_bomb_carrier"):
		actor.set_bomb_carrier(true)
	visible = false
	ring.visible = false
	light.light_energy = 0.0
	game.audio.play("buy", -3.0)
	return true

func set_planting(actor, active: bool) -> void:
	if actor == null or not actor.alive:
		return
	if not active:
		if planting_actor == actor:
			planting_actor = null
			plant_progress = 0.0
		return
	if state != "carried" or carrier != actor:
		return
	var s: Dictionary = game.map.site_at(actor.global_position)
	if s.is_empty():
		return
	if planting_actor != null and planting_actor != actor:
		return
	if planting_actor == null:
		planting_actor = actor
		plant_progress = 0.0
		plant_anchor = actor.global_position
		plant_tick = 0.0

func set_defusing(actor, active: bool) -> void:
	if actor == null or not actor.alive:
		return
	if not active:
		if defusing_actor == actor:
			defusing_actor = null
			defuse_progress = 0.0
		return
	if state != "planted":
		return
	if defusing_actor != null and defusing_actor != actor:
		return
	if global_position.distance_to(actor.global_position) > float(GameConfig.MATCH["defuse_range"]):
		return
	if defusing_actor == null:
		defusing_actor = actor
		defuse_progress = 0.0
		defuse_anchor = actor.global_position
		defuse_total = float(GameConfig.MATCH["defuse_kit_time"]) if _has_kit(actor) else float(GameConfig.MATCH["defuse_time"])
		defuse_tick = 0.0

func _has_kit(actor) -> bool:
	if actor.is_player:
		return actor.kit
	return actor.has_kit

func cancel_actor(actor) -> void:
	if planting_actor == actor:
		planting_actor = null
		plant_progress = 0.0
	if defusing_actor == actor:
		defusing_actor = null
		defuse_progress = 0.0

func update(delta: float) -> void:
	pulse += delta
	if state == "carried":
		if carrier == null or not carrier.alive:
			drop(carrier)
			return
		global_position = carrier.global_position
		_update_plant(delta)
	elif state == "dropped":
		light.light_energy = 5.0 + sin(pulse * 5.0) * 2.0
		led_mat.emission_energy_multiplier = 2.0 + sin(pulse * 6.0) * 1.0
		ring.rotation.y += delta * 0.4
	elif state == "planted":
		remaining = maxf(0.0, remaining - delta)
		_update_defuse(delta)
		_update_beeps(delta)
		_update_planted_visual(delta)
		if remaining <= 0.0:
			_explode()

func _update_plant(delta: float) -> void:
	if planting_actor == null:
		return
	if not planting_actor.alive or carrier != planting_actor:
		cancel_actor(planting_actor)
		return
	if planting_actor.global_position.distance_to(plant_anchor) > 0.28:
		cancel_actor(planting_actor)
		return
	if game.map.site_at(planting_actor.global_position).is_empty():
		cancel_actor(planting_actor)
		return
	plant_progress += delta
	plant_tick -= delta
	if plant_tick <= 0.0:
		plant_tick = 0.5
		if planting_actor.is_player:
			game.audio.play("ui", -10.0)
			game.ui.set_interaction_progress(plant_progress / float(GameConfig.MATCH["plant_time"]), "安放黑匣 %.1fs" % maxf(0.0, float(GameConfig.MATCH["plant_time"]) - plant_progress))
	if plant_progress >= float(GameConfig.MATCH["plant_time"]):
		_plant(planting_actor)

func _plant(actor) -> void:
	var s: Dictionary = game.map.site_at(actor.global_position)
	if s.is_empty():
		cancel_actor(actor)
		return
	state = "planted"
	site = s
	planted_by = actor
	carrier = null
	planting_actor = null
	plant_progress = 0.0
	actor.bomb_carried = false
	if actor.has_method("set_bomb_carrier"):
		actor.set_bomb_carrier(false)
	global_position = actor.global_position
	global_position.y = 0.0
	remaining = float(GameConfig.MATCH["bomb_time"])
	visible = true
	ring.visible = true
	light.light_energy = 5.0
	beep_timer = 0.1
	game.audio.play("buy", 0.0)
	game.on_bomb_planted(self, actor, s)
	if actor.is_player:
		game.ui.update_vitals(actor)

func _update_defuse(delta: float) -> void:
	if defusing_actor == null:
		return
	if not defusing_actor.alive:
		cancel_actor(defusing_actor)
		return
	if global_position.distance_to(defusing_actor.global_position) > float(GameConfig.MATCH["defuse_range"]) + 0.25:
		cancel_actor(defusing_actor)
		return
	if defusing_actor.global_position.distance_to(defuse_anchor) > 0.3:
		cancel_actor(defusing_actor)
		return
	defuse_progress += delta
	defuse_tick -= delta
	if defuse_tick <= 0.0:
		defuse_tick = 0.28
		if defusing_actor.is_player:
			game.audio.play("ui", -12.0)
			game.ui.set_interaction_progress(defuse_progress / maxf(0.01, defuse_total), "拆除黑匣 %.1fs" % maxf(0.0, defuse_total - defuse_progress))
	if defuse_progress >= defuse_total:
		defused_by = defusing_actor
		state = "defused"
		defusing_actor = null
		(ring.material_override as StandardMaterial3D).albedo_color = Color(0.25, 0.85, 1.0, 0.7)
		light.light_color = Color("#42d8ff")
		game.audio.defused()
		game.on_bomb_defused(self, defused_by)

func _update_beeps(delta: float) -> void:
	var ratio = clampf(remaining / float(GameConfig.MATCH["bomb_time"]), 0.0, 1.0)
	var interval = 0.14 + ratio * 0.86
	beep_timer -= delta
	if beep_timer <= 0.0:
		beep_timer = interval
		var urgent = ratio < 0.22
		game.audio.beep(urgent, game.player.global_position.distance_to(global_position))
		light.light_energy = 9.0 if urgent else 6.0

func _update_planted_visual(delta: float) -> void:
	var ratio = clampf(remaining / float(GameConfig.MATCH["bomb_time"]), 0.0, 1.0)
	var speed = 6.0 + (1.0 - ratio) * 22.0
	var p = 0.5 + sin(pulse * speed) * 0.5
	led_mat.emission_energy_multiplier = 1.0 + p * 4.0
	led_mat.albedo_color = Color(1.0, 0.1 + p * 0.3, 0.03)
	ring.rotation.y += delta * (0.3 + (1.0 - ratio) * 1.5)
	light.light_energy = 5.0 + p * 8.0

func _explode() -> void:
	if state != "planted":
		return
	state = "exploded"
	visible = false
	ring.visible = false
	light.light_energy = 0.0
	game.audio.explosion()
	game.effects.spawn_explosion(global_position + Vector3(0, 0.2, 0))
	if game.player:
		game.player.shake = 1.4
	game.on_bomb_exploded(self)

func site_label() -> String:
	return String(site.get("id", "—"))

