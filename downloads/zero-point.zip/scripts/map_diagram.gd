class_name MapDiagram
extends Control

var font: Font
var scan = 0.0
var labels = true

func setup(p_font: Font) -> void:
	font = p_font
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_process(true)

func _process(delta: float) -> void:
	scan = fmod(scan + delta * 0.22, 1.0)
	queue_redraw()

func _draw() -> void:
	var w = size.x
	var h = size.y
	draw_rect(Rect2(Vector2.ZERO, size), Color("#0a1015"))
	for i in range(0, int(w) + 1, 22):
		draw_line(Vector2(i, 0), Vector2(i, h), Color(0.35, 0.5, 0.55, 0.08), 1.0)
	for j in range(0, int(h) + 1, 22):
		draw_line(Vector2(0, j), Vector2(w, j), Color(0.35, 0.5, 0.55, 0.08), 1.0)

	var a = Vector2(w * 0.23, h * 0.28)
	var b = Vector2(w * 0.77, h * 0.28)
	var atk = Vector2(w * 0.22, h * 0.85)
	var def = Vector2(w * 0.78, h * 0.85)
	# 路线
	draw_line(atk, a, Color(1.0, 0.42, 0.15, 0.32), 1.0)
	draw_line(atk, b, Color(1.0, 0.42, 0.15, 0.32), 1.0)
	draw_line(a, b, Color(0.65, 0.8, 0.85, 0.18), 1.0)
	draw_line(a, a + Vector2(-12, -18), Color(1.0, 0.42, 0.15, 0.45), 1.0)
	draw_line(b, b + Vector2(12, -18), Color(0.3, 0.85, 1.0, 0.45), 1.0)

	# 包点
	_site_box(a, "A", Color("#ff6b2c"))
	_site_box(b, "B", Color("#42d8ff"))
	draw_string(font, a + Vector2(-18, 55), "ATK ROUTE", HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color(1, 0.6, 0.4, 0.55))
	draw_string(font, b + Vector2(-8, 55), "DEF ROUTE", HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color(0.5, 0.85, 1, 0.55))
	draw_string(font, Vector2(w * 0.47, h * 0.56), "MID", HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color(0.6, 0.72, 0.76, 0.5))
	draw_string(font, Vector2(atk.x - 13, h - 12), "ATK", HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color(1, 0.42, 0.15, 0.7))
	draw_string(font, Vector2(def.x - 13, h - 12), "DEF", HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color(0.3, 0.85, 1, 0.7))
	draw_string(font, Vector2(w - 84, h - 8), "31°14'N / 121°29'E", HORIZONTAL_ALIGNMENT_LEFT, -1, 6, Color(0.4, 0.5, 0.55, 0.5))

	# 扫描线
	var sx = scan * w
	var grad = Color(1.0, 0.45, 0.15, 0.035)
	draw_rect(Rect2(sx - 4, 0, 8, h), grad)
	draw_line(Vector2(sx, 0), Vector2(sx, h), Color(1.0, 0.45, 0.15, 0.18), 1.0)

func _site_box(p: Vector2, text: String, color: Color) -> void:
	var r = Rect2(p - Vector2(17, 17), Vector2(34, 34))
	draw_rect(r, Color(0, 0, 0, 0.5))
	draw_rect(r, color, false, 1.2)
	draw_string(font, p + Vector2(-6, 6), text, HORIZONTAL_ALIGNMENT_LEFT, -1, 18, color)
