class_name Bot
extends CharacterBody3D

## 5V5 Bot锛氭帹杩?/ 鏋剁?/ 涓?/ 鎷嗗?/ 瀵灙銆?## 涓庣帺跺叡鐢ㄥ悓涓€濂墿鐞嗗皠绾夸笌浼ゅ鎺ュ彛銆?
var game = null
var team = "attack"
var bot_name = "Bot"
var ally = false
var index = 0
var skill = 0.5
var is_player = false

var health = 100.0
var armor = 45.0
var alive = true
var frozen = true
var bomb_carried = false
var has_kit = false

var weapon_def: Dictionary = {}
var ammo = 30
var reserve = 999
var reload_timer = 0.0
var fire_cooldown = 0.0
var draw_timer = 0.0
var shot_bloom = 0.0

var site = "A"
var role = "support"
var hold = Vector3.ZERO
var hold_index = 0

var target = null
var target_visible = false
var target_last_seen = 0.0
var last_attacker = null
var alert_timer = 0.0
var reaction_timer = 0.0
var burst_shots = 0
var burst_cooldown = 0.5
var think_timer = 0.0
var activation_delay = 0.0

var path = PackedVector3Array()
var path_index = 0
var goal = Vector3.ZERO
var has_goal = false
var path_timer = 0.0
var goal_changed = true
var stuck_timer = 0.0
var stuck_reference = Vector3.ZERO
var strafe_sign = 1.0
var strafe_timer = 0.0
var roam_wait = 0.0
var roam_anchor = Vector3.ZERO
var scan_timer = 0.0
var scan_sign = 1.0

var planting = false
var defusing = false

var stats = {"kills": 0, "deaths": 0, "headshots": 0}
var aim_error = 0.02

var collision_shape: CollisionShape3D
var visual: Node3D
var legs: Array[Node3D] = []
var gun: Node3D
var muzzle_marker: Node3D
var name_tag: Label3D
var bomb_prop: MeshInstance3D
var body_materials = {}
var death_tween: Tween
var walk_phase = 0.0

func setup(game_ref: Node, p_team: String, p_name: String, p_ally: bool, p_index: int, p_skill: float) -> void:
	game = game_ref
	team = p_team
	bot_name = p_name
	ally = p_ally
	index = p_index
	skill = clampf(p_skill, 0.2, 0.95)
	name = "Bot_" + p_name
	collision_layer = 2
	collision_mask = 1
	floor_snap_length = 0.25
	floor_max_angle = deg_to_rad(50)

	collision_shape = CollisionShape3D.new()
	var capsule = CapsuleShape3D.new()
	capsule.radius = 0.36
	capsule.height = 1.8
	collision_shape.shape = capsule
	collision_shape.position = Vector3(0, 0.9, 0)
	add_child(collision_shape)

	_build_visual()
	aim_error = randf_range(0.022, 0.06) * (1.3 - skill * 0.45)
	add_to_group("characters")

func _build_visual() -> void:
	var team_color: Color = GameConfig.TEAM.get(team, GameConfig.TEAM["attack"])["color"]
	var team_soft: Color = GameConfig.TEAM.get(team, GameConfig.TEAM["attack"])["soft"]
	var suit = StandardMaterial3D.new()
	suit.albedo_color = Color("#252d31")
	suit.roughness = 0.82
	suit.metallic = 0.1
	var armor_mat = StandardMaterial3D.new()
	armor_mat.albedo_color = Color("#4a565c")
	armor_mat.roughness = 0.62
	armor_mat.metallic = 0.25
	var dark = StandardMaterial3D.new()
	dark.albedo_color = Color("#101519")
	dark.roughness = 0.72
	dark.metallic = 0.3
	var accent = StandardMaterial3D.new()
	accent.albedo_color = team_color
	accent.emission_enabled = true
	accent.emission = team_color
	accent.emission_energy_multiplier = 1.5
	var visor = StandardMaterial3D.new()
	visor.albedo_color = team_soft
	visor.emission_enabled = true
	visor.emission = team_soft
	visor.emission_energy_multiplier = 1.8
	visor.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	var glove = StandardMaterial3D.new()
	glove.albedo_color = Color("#1a2023")
	glove.roughness = 0.9
	body_materials = {"suit": suit, "armor": armor_mat, "dark": dark, "accent": accent, "visor": visor, "glove": glove}

	visual = Node3D.new()
	visual.name = "Visual"
	add_child(visual)

	for side in [-1.0, 1.0]:
		var leg = Node3D.new()
		leg.position = Vector3(side * 0.125, 0.86, 0.0)
		var thigh = _box(Vector3(0.16, 0.42, 0.19), Vector3(0, -0.21, 0), suit)
		var shin = _box(Vector3(0.145, 0.4, 0.17), Vector3(0, -0.61, -0.01), dark)
		var boot = _box(Vector3(0.17, 0.15, 0.28), Vector3(0, -0.83, -0.05), dark)
		leg.add_child(thigh)
		leg.add_child(shin)
		leg.add_child(boot)
		visual.add_child(leg)
		legs.append(leg)

	var torso = _box(Vector3(0.48, 0.6, 0.29), Vector3(0, 1.18, 0), suit)
	visual.add_child(torso)
	visual.add_child(_box(Vector3(0.45, 0.36, 0.09), Vector3(0, 1.2, -0.18), armor_mat))
	visual.add_child(_box(Vector3(0.42, 0.08, 0.28), Vector3(0, 0.91, 0), dark))
	visual.add_child(_box(Vector3(0.34, 0.42, 0.18), Vector3(0, 1.22, 0.24), dark))
	visual.add_child(_box(Vector3(0.22, 0.035, 0.02), Vector3(0, 1.36, 0.335), accent))
	visual.add_child(_box(Vector3(0.12, 0.025, 0.015), Vector3(0, 1.29, -0.235), accent))
	for side in [-1.0, 1.0]:
		visual.add_child(_box(Vector3(0.16, 0.1, 0.22), Vector3(side * 0.32, 1.4, 0), armor_mat))
		visual.add_child(_box(Vector3(0.025, 0.05, 0.18), Vector3(side * 0.4, 1.4, 0), accent))

	var head_group = Node3D.new()
	head_group.position = Vector3(0, 1.58, 0)
	var head = MeshInstance3D.new()
	var head_mesh = SphereMesh.new()
	head_mesh.radius = 0.145
	head_mesh.height = 0.29
	head_mesh.radial_segments = 12
	head_mesh.rings = 8
	head.mesh = head_mesh
	head.position.y = 0.16
	head.material_override = armor_mat
	head_group.add_child(head)
	var helmet = MeshInstance3D.new()
	var helmet_mesh = SphereMesh.new()
	helmet_mesh.radius = 0.17
	helmet_mesh.height = 0.22
	helmet_mesh.radial_segments = 12
	helmet_mesh.rings = 6
	helmet.mesh = helmet_mesh
	helmet.position.y = 0.23
	helmet.material_override = dark
	head_group.add_child(helmet)
	head_group.add_child(_box(Vector3(0.3, 0.025, 0.03), Vector3(0, 0.24, -0.14), accent))
	head_group.add_child(_box(Vector3(0.03, 0.025, 0.2), Vector3(0.15, 0.24, 0), accent))
	var visor_mesh = _box(Vector3(0.19, 0.045, 0.013), Vector3(0, 0.16, -0.139), visor)
	head_group.add_child(visor_mesh)
	visual.add_child(head_group)

	# 手臂
	visual.add_child(_box(Vector3(0.11, 0.3, 0.12), Vector3(0.31, 1.3, -0.05), suit))
	visual.add_child(_box(Vector3(0.1, 0.28, 0.11), Vector3(0.34, 1.08, -0.24), armor_mat))
	visual.add_child(_box(Vector3(0.1, 0.09, 0.12), Vector3(0.28, 0.98, -0.42), glove))
	visual.add_child(_box(Vector3(0.11, 0.3, 0.12), Vector3(-0.3, 1.3, -0.03), suit))
	visual.add_child(_box(Vector3(0.1, 0.26, 0.11), Vector3(-0.22, 1.08, -0.28), armor_mat))
	visual.add_child(_box(Vector3(0.1, 0.09, 0.12), Vector3(-0.04, 1.03, -0.48), glove))

	# 武器
	gun = Node3D.new()
	gun.position = Vector3(0.22, 1.18, -0.3)
	var gun_metal = StandardMaterial3D.new()
	gun_metal.albedo_color = Color("#20272b")
	gun_metal.roughness = 0.42
	gun_metal.metallic = 0.62
	gun.add_child(_box(Vector3(0.075, 0.1, 0.42), Vector3(0, 0, -0.08), gun_metal))
	gun.add_child(_box(Vector3(0.05, 0.05, 0.12), Vector3(0, 0.08, -0.2), dark))
	var barrel = MeshInstance3D.new()
	var barrel_mesh = CylinderMesh.new()
	barrel_mesh.top_radius = 0.018
	barrel_mesh.bottom_radius = 0.018
	barrel_mesh.height = 0.38
	barrel_mesh.radial_segments = 8
	barrel.mesh = barrel_mesh
	barrel.rotation_degrees = Vector3(90, 0, 0)
	barrel.position = Vector3(0, 0.015, -0.45)
	barrel.material_override = gun_metal
	gun.add_child(barrel)
	gun.add_child(_box(Vector3(0.05, 0.2, 0.09), Vector3(0, -0.14, -0.1), dark, Vector3(10, 0, 0)))
	gun.add_child(_box(Vector3(0.06, 0.12, 0.22), Vector3(0, 0, 0.16), dark))
	gun.add_child(_box(Vector3(0.01, 0.018, 0.17), Vector3(0.045, 0.02, 0.02), accent))
	muzzle_marker = Node3D.new()
	muzzle_marker.position = Vector3(0, 0.015, -0.78)
	gun.add_child(muzzle_marker)
	visual.add_child(gun)

# 鑳屽?/ 榛戝專鏍囘
	visual.add_child(_box(Vector3(0.34, 0.42, 0.18), Vector3(0, 1.22, 0.24), dark))
	visual.add_child(_box(Vector3(0.22, 0.035, 0.02), Vector3(0, 1.36, 0.335), accent))
	bomb_prop = _box(Vector3(0.24, 0.28, 0.13), Vector3(0, 1.15, 0.38), dark)
	var bomb_stripe = _box(Vector3(0.25, 0.045, 0.135), Vector3(0, 0.1, 0), accent)
	bomb_prop.add_child(bomb_stripe)
	bomb_prop.visible = false
	visual.add_child(bomb_prop)

	# 友军名牌
	if ally:
		name_tag = Label3D.new()
		name_tag.text = bot_name
		name_tag.font = game.map.ui_font if game and game.map else null
		name_tag.font_size = 22
		name_tag.pixel_size = 0.0055
		name_tag.outline_size = 6
		name_tag.modulate = team_soft
		name_tag.outline_modulate = Color(0, 0, 0, 0.8)
		name_tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		name_tag.position = Vector3(0, 2.12, 0)
		name_tag.no_depth_test = false
		add_child(name_tag)

func _box(size: Vector3, pos: Vector3, mat: Material, rot_deg = Vector3.ZERO) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.material_override = mat
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
	return mi

func configure_round(p_team: String, p_site: String, p_role: String, p_hold: Vector3, p_spawn: Vector3, p_yaw: float, weapon_id: String, p_has_kit: bool, p_bomb_carried: bool) -> void:
	team = p_team
	site = p_site
	role = p_role
	hold = p_hold
	if game and game.nav:
		var hold_variation: Vector3 = game.nav.random_point_near(hold.x, hold.z, 0.8, 3.2)
		if hold_variation.distance_to(hold) > 0.4:
			hold = hold_variation
	roam_anchor = hold
	roam_wait = randf_range(0.2, 0.9)
	scan_timer = randf_range(0.8, 2.4)
	scan_sign = -1.0 if randf() < 0.5 else 1.0
	global_position = p_spawn
	velocity = Vector3.ZERO
	rotation = Vector3(0, p_yaw, 0)
	health = 100.0
	armor = 45.0
	alive = true
	frozen = true
	has_kit = p_has_kit
	bomb_carried = p_bomb_carried
	weapon_def = GameConfig.resolve_weapon(weapon_id)
	weapon_def["id"] = weapon_id
	ammo = int(weapon_def["mag"])
	reserve = 999
	reload_timer = 0.0
	fire_cooldown = 0.0
	draw_timer = float(weapon_def.get("draw_time", 0.4))
	shot_bloom = 0.0
	target = null
	target_visible = false
	target_last_seen = 0.0
	last_attacker = null
	alert_timer = 0.0
	reaction_timer = 0.0
	burst_shots = 0
	burst_cooldown = 0.4
	think_timer = randf_range(0.0, 0.2)
	activation_delay = randf_range(0.9, 3.2)
	path = PackedVector3Array()
	path_index = 0
	has_goal = false
	goal_changed = true
	path_timer = 0.0
	stuck_timer = 0.0
	stuck_reference = global_position
	planting = false
	defusing = false
	aim_error = randf_range(0.022, 0.06) * (1.3 - skill * 0.45)
	if death_tween and death_tween.is_valid():
		death_tween.kill()
	visual.rotation = Vector3.ZERO
	visual.position = Vector3.ZERO
	visual.visible = true
	if gun:
		gun.visible = true
	if name_tag:
		name_tag.visible = ally
	if bomb_prop:
		bomb_prop.visible = bomb_carried
	collision_shape.set_deferred("disabled", false)

func set_frozen(value: bool) -> void:
	frozen = value
	if value:
		velocity.x = 0.0
		velocity.z = 0.0

func set_bomb_carrier(value: bool) -> void:
	bomb_carried = value
	if bomb_prop:
		bomb_prop.visible = value and alive

func _physics_process(delta: float) -> void:
	if not alive:
		return
	if not is_on_floor():
		velocity.y -= 19.0 * delta
	else:
		velocity.y = 0.0

	if frozen:
		velocity.x = 0.0
		velocity.z = 0.0
		move_and_slide()
		return

	_update_timers(delta)
	if activation_delay > 0.0:
		activation_delay -= delta
		move_and_slide()
		return

	think_timer -= delta
	if think_timer <= 0.0:
		think_timer = 0.23
		_think(delta)

	_update_target_state(delta)
	_update_objective(delta)
	_apply_interactions()
	_update_combat(delta)
	_move(delta)
	_update_animation(delta)
	if shot_bloom > 0.0:
		shot_bloom = maxf(0.0, shot_bloom - delta * 2.4)

func _update_timers(delta: float) -> void:
	fire_cooldown = maxf(0.0, fire_cooldown - delta)
	draw_timer = maxf(0.0, draw_timer - delta)
	burst_cooldown -= delta
	alert_timer = maxf(0.0, alert_timer - delta)
	if reload_timer > 0.0:
		reload_timer = maxf(0.0, reload_timer - delta)
		if reload_timer <= 0.0:
			var need = int(weapon_def.get("mag", 30)) - ammo
			var take = mini(need, reserve)
			ammo += take
			reserve -= take
	if ammo <= 0 and reload_timer <= 0.0:
		_start_reload()
	if shot_bloom > 0.0:
		shot_bloom = maxf(0.0, shot_bloom - delta * 2.4)

func _start_reload() -> void:
	if reload_timer > 0.0 or ammo >= int(weapon_def.get("mag", 30)) or reserve <= 0:
		return
	reload_timer = float(weapon_def.get("reload", 2.0))

func _think(delta: float) -> void:
	if not target or not _is_valid_target(target):
		target = null
		target_visible = false
		var found = _find_visible_enemy()
		if found:
			target = found
			target_visible = true
			reaction_timer = randf_range(0.5, 1.15) * (1.2 - skill * 0.35)
			burst_shots = 0
	if target and _can_see(target):
		target_visible = true
		target_last_seen = 0.0
	elif target:
		target_visible = false
		target_last_seen += 0.23
		if target_last_seen > 2.2:
			target = null
	if alert_timer > 0.0 and last_attacker and is_instance_valid(last_attacker) and last_attacker.alive:
		if _can_see(last_attacker):
			target = last_attacker
			target_visible = true
			reaction_timer = minf(reaction_timer, 0.35)

func _is_valid_target(node) -> bool:
	return is_instance_valid(node) and node.alive and node.team != team

func _find_visible_enemy():
	var best = null
	var best_score = INF
	for enemy in game.get_enemies_of(team):
		if not is_instance_valid(enemy) or not enemy.alive:
			continue
		var distance: float = global_position.distance_to(enemy.global_position)
		if distance > 78.0:
			continue
		if not _in_fov(enemy) or not _can_see(enemy):
			continue
		var score = distance + (-3.0 if enemy.is_player else 0.0)
		if score < best_score:
			best_score = score
			best = enemy
	return best

func _in_fov(enemy) -> bool:
	var to_enemy = enemy.global_position - global_position
	if to_enemy.length() < 3.8:
		return true
	to_enemy.y = 0.0
	var forward = -global_transform.basis.z
	forward.y = 0.0
	return forward.normalized().dot(to_enemy.normalized()) > cos(deg_to_rad(64.0))

func _can_see(enemy) -> bool:
	var from = global_position + Vector3(0, 1.56, 0)
	var to = enemy.global_position + Vector3(0, 1.25 if not enemy.is_player else 1.35, 0)
	var query = PhysicsRayQueryParameters3D.create(from, to)
	query.collision_mask = 1
	var hit = get_world_3d().direct_space_state.intersect_ray(query)
	return hit.is_empty() or hit.get("position", Vector3.ZERO).distance_to(from) > from.distance_to(to) - 0.2

func _update_target_state(delta: float) -> void:
	if target and not _is_valid_target(target):
		target = null
		target_visible = false
	if target and target_visible:
		var to_target = target.global_position - global_position
		var desired_yaw = atan2(-to_target.x, -to_target.z)
		rotation.y = lerp_angle(rotation.y, desired_yaw, 1.0 - exp(-9.0 * delta))
	else:
		rotation.y = lerp_angle(rotation.y, rotation.y, 1.0)

func _update_combat(delta: float) -> void:
	if planting or defusing:
		return
	if not target or not target_visible:
		burst_shots = 0
		return
	var distance = global_position.distance_to(target.global_position)
	var weapon_range: float = float(weapon_def.get("range", 60.0))
	if distance > weapon_range * 1.15:
		return
	if reaction_timer > 0.0:
		reaction_timer -= delta
		return
	if reload_timer > 0.0 or draw_timer > 0.0:
		return
	if ammo <= 0:
		_start_reload()
		return
	if burst_shots > 0:
		if fire_cooldown <= 0.0:
			_fire_at_target(distance)
			burst_shots -= 1
			if burst_shots <= 0:
				burst_cooldown = randf_range(0.35, 0.8) * (1.3 - skill * 0.35)
	elif burst_cooldown <= 0.0:
		burst_shots = maxi(2, roundi(randf_range(2.0, 5.0) * (1.0 if skill > 0.6 else 0.85)))
		if fire_cooldown <= 0.0:
			_fire_at_target(distance)
			burst_shots -= 1
		if burst_shots <= 0:
			burst_cooldown = 0.4

func _fire_at_target(distance: float) -> void:
	if weapon_def.is_empty() or ammo <= 0 or fire_cooldown > 0.0:
		return
	ammo -= 1
	fire_cooldown = 60.0 / float(weapon_def.get("rpm", 600.0))
	var origin = global_position + Vector3(0, 1.56, 0)
	var aim = target.global_position + Vector3(0, 1.25 if not target.is_player else 1.32, 0)
	var direction = (aim - origin).normalized()
	var speed = Vector2(velocity.x, velocity.z).length()
	var error = aim_error * (0.8 + distance / 48.0) * (1.0 + speed * 0.08) * 1.15
	var right = direction.cross(Vector3.UP).normalized()
	if right.length() < 0.01:
		right = Vector3.RIGHT
	var up = right.cross(direction).normalized()
	direction += right * randf_range(-1.0, 1.0) * error
	direction += up * randf_range(-1.0, 1.0) * error * 0.7
	direction = direction.normalized()
	game.bot_fire(self, weapon_def, origin, direction)
	game.effects.spawn_muzzle_flash(muzzle_marker.global_position, Color("#ffc477") if team == "attack" else Color("#9ae8ff"), 0.7)
	game.audio.shot(String(weapon_def.get("id", "ar21")), global_position.distance_to(game.player.global_position))
	shot_bloom = minf(1.5, shot_bloom + 0.5)

func _update_objective(delta: float) -> void:
	planting = false
	defusing = false
	var bomb = game.bomb
	if bomb == null:
		return
	if team == "defense":
		if bomb.state == "planted":
			var dist = global_position.distance_to(bomb.global_position)
			if dist <= 1.9 and (not target_visible or bomb.remaining < 8.0):
				defusing = true
				_set_goal(bomb.global_position)
			elif dist > 2.5:
				_set_goal(bomb.global_position)
			else:
				_patrol_goal(bomb.global_position, 2.2, delta)
		else:
			_patrol_goal(hold, 11.0, delta)
		return

	# 进攻方
	if bomb.state == "planted":
		_patrol_goal(game.map.get_post_plant_hold(hold_index, site), 12.0, delta)
		return
	if bomb.state == "dropped":
		if game.should_bot_pickup_bomb(self):
			if global_position.distance_to(bomb.global_position) <= GameConfig.MATCH["bomb_pickup_range"] + 0.15:
				if bomb.pickup(self):
					set_bomb_carrier(true)
					game.ui.toast("%s 回收了黑匣" % bot_name, "danger")
			_set_goal(bomb.global_position)
			return
	if bomb.state == "carried" and bomb.carrier == self:
		var center: Vector3 = game.map.get_site(site)["center"]
		_set_goal(center)
		if Vector2(global_position.x - center.x, global_position.z - center.z).length() <= float(game.map.get_site(site)["radius"]) - 0.2 and not target_visible:
			planting = true
		return
	_patrol_goal(hold, 12.0, delta)

func _patrol_goal(anchor: Vector3, radius: float, delta: float) -> void:
	if planting or defusing:
		return
	if has_goal and global_position.distance_to(goal) > 1.8:
		return
	roam_wait -= delta
	if roam_wait > 0.0:
		return
	var candidate: Vector3 = game.nav.random_point_near(anchor.x, anchor.z, 2.0, radius)
	if candidate.distance_to(global_position) < 2.0:
		roam_wait = 0.6
		return
	var test_path: PackedVector3Array = game.nav.find_path(global_position, candidate)
	if test_path.is_empty():
		roam_wait = 0.5
		return
	_set_goal(candidate)
	roam_wait = randf_range(0.4, 1.2)

func _apply_interactions() -> void:
	game.bomb.set_planting(self, planting)
	game.bomb.set_defusing(self, defusing)

func _set_goal(point: Vector3) -> void:
	if not has_goal or goal.distance_to(point) > 1.4:
		goal = point
		has_goal = true
		goal_changed = true
		path_timer = 0.0

func _move(delta: float) -> void:
	if planting or defusing:
		velocity.x = 0.0
		velocity.z = 0.0
		move_and_slide()
		return
	if not has_goal:
		return
	var distance = global_position.distance_to(goal)
	var speed = 3.65
	if target_visible and target:
		var target_distance = global_position.distance_to(target.global_position)
		speed = 3.4
		strafe_timer -= delta
		if strafe_timer <= 0.0:
			strafe_timer = randf_range(0.5, 1.4)
			strafe_sign *= -1.0
		if target_distance < 16.0:
			var to_target = target.global_position - global_position
			to_target.y = 0.0
			var right = to_target.normalized().cross(Vector3.UP).normalized()
			velocity.x = lerpf(velocity.x, right.x * strafe_sign * 2.0, 1.0 - exp(-8.0 * delta))
			velocity.z = lerpf(velocity.z, right.z * strafe_sign * 2.0, 1.0 - exp(-8.0 * delta))
			rotation.y = lerp_angle(rotation.y, atan2(-to_target.x, -to_target.z), 1.0 - exp(-8.0 * delta))
			move_and_slide()
			return
		if bomb_carried:
			speed = 4.2
		else:
			speed = 3.0
	elif distance > 12.0:
		speed = 5.1

	path_timer -= delta
	if path.is_empty() or goal_changed or path_timer <= 0.0:
		path_timer = randf_range(1.3, 2.2)
		goal_changed = false
		path = game.nav.find_path(global_position, goal)
		path_index = 0
		if path.is_empty():
			path = PackedVector3Array([goal])

	while path_index < path.size():
		var p = path[path_index]
		if Vector2(p.x - global_position.x, p.z - global_position.z).length() < 0.55:
			path_index += 1
		else:
			break
	if path_index >= path.size():
		velocity.x = lerpf(velocity.x, 0.0, 1.0 - exp(-10.0 * delta))
		velocity.z = lerpf(velocity.z, 0.0, 1.0 - exp(-10.0 * delta))
		move_and_slide()
		return
	var point = path[path_index]
	var to_point = Vector3(point.x - global_position.x, 0, point.z - global_position.z)
	if to_point.length() < 0.15:
		path_index += 1
		return
	to_point = to_point.normalized()
	velocity.x = lerpf(velocity.x, to_point.x * speed, 1.0 - exp(-10.0 * delta))
	velocity.z = lerpf(velocity.z, to_point.z * speed, 1.0 - exp(-10.0 * delta))
	if not target_visible:
		rotation.y = lerp_angle(rotation.y, atan2(-to_point.x, -to_point.z), 1.0 - exp(-8.0 * delta))
	move_and_slide()

	stuck_timer += delta
	if stuck_timer > 0.9:
		if global_position.distance_to(stuck_reference) < 0.15 and distance > 1.0:
			path = PackedVector3Array()
			path_timer = 0.0
			goal_changed = true
			var jitter = game.nav.random_point_near(global_position.x, global_position.z, 1.2, 4.0)
			_set_goal(jitter)
			roam_wait = 0.4
		stuck_timer = 0.0
		stuck_reference = global_position

func _update_animation(delta: float) -> void:
	var speed = Vector2(velocity.x, velocity.z).length()
	if speed > 0.3:
		walk_phase += delta * (7.0 + speed)
		var swing = sin(walk_phase) * clampf(speed / 5.0, 0.0, 1.0) * 0.55
		legs[0].rotation.x = swing
		legs[1].rotation.x = -swing
		visual.position.y = absf(sin(walk_phase)) * 0.015
	else:
		legs[0].rotation.x = lerpf(legs[0].rotation.x, 0.0, 1.0 - exp(-8.0 * delta))
		legs[1].rotation.x = lerpf(legs[1].rotation.x, 0.0, 1.0 - exp(-8.0 * delta))
		visual.position.y = lerpf(visual.position.y, 0.0, 1.0 - exp(-8.0 * delta))

func take_damage(amount: float, attacker, headshot = false) -> void:
	if not alive:
		return
	var resolved = maxf(1.0, roundf(amount))
	var health_damage = resolved
	if armor > 0.0:
		var absorbed = minf(armor, resolved * 0.5)
		armor = maxf(0.0, armor - absorbed)
		health_damage = resolved - absorbed
	health = maxf(0.0, health - health_damage)
	game.bomb.cancel_actor(self)
	alert_timer = 3.4
	if attacker and is_instance_valid(attacker) and attacker.alive:
		last_attacker = attacker
		if not target or not target_visible:
			target = attacker
			target_visible = true
			reaction_timer = minf(reaction_timer, 0.35)
	if health <= 0.0:
		_die(attacker, headshot)

func _die(attacker, headshot: bool) -> void:
	if not alive:
		return
	alive = false
	stats["deaths"] = int(stats["deaths"]) + 1
	velocity = Vector3.ZERO
	collision_shape.set_deferred("disabled", true)
	planting = false
	defusing = false
	if bomb_carried:
		bomb_carried = false
		if bomb_prop:
			bomb_prop.visible = false
	if name_tag:
		name_tag.visible = false
	if gun:
		gun.visible = false
	game.bomb.cancel_actor(self)
	game.on_bot_death(self, attacker, headshot)
	if death_tween and death_tween.is_valid():
		death_tween.kill()
	death_tween = create_tween()
	death_tween.set_parallel(true)
	death_tween.tween_property(visual, "rotation:z", PI * 0.48, 0.45).set_ease(Tween.EASE_OUT)
	death_tween.tween_property(visual, "position:y", -0.05, 0.45)

func get_aim_point(head = false) -> Vector3:
	return global_position + Vector3(0, 1.7 if head else 1.25, 0)

func get_eye_position() -> Vector3:
	return global_position + Vector3(0, 1.56, 0)

func get_muzzle_position() -> Vector3:
	if muzzle_marker:
		return muzzle_marker.global_position
	return global_position + Vector3(0, 1.3, -0.8)

func get_score_line() -> Dictionary:
	return {
		"name": bot_name,
		"team": team,
		"kills": stats["kills"],
		"deaths": stats["deaths"],
		"headshots": stats["headshots"],
		"alive": alive,
		"is_player": false,
	}

