class_name GameUI
extends CanvasLayer

const WeaponPreviewScript = preload("res://scripts/weapon_preview.gd")

## 原生 UI：主菜单 / HUD / 军械库 / 暂停 / 计分板 / 结算 / 设置。
## 全部布局由代码构建，后续可逐步替换为 .tscn 场景而不影响 Match 接口。
const C_BG = Color("#06090c")
const C_PANEL = Color(0.047, 0.071, 0.086, 0.94)
const C_PANEL_2 = Color(0.071, 0.102, 0.12, 0.97)
const C_LINE = Color(0.84, 0.91, 0.93, 0.13)
const C_LINE_STRONG = Color(0.84, 0.91, 0.93, 0.28)
const C_TEXT = Color("#e9f0f2")
const C_MUTED = Color("#8b9ba4")
const C_DIM = Color("#5d6b73")
const C_ORANGE = Color("#ff6b2c")
const C_ORANGE_SOFT = Color("#ff925f")
const C_CYAN = Color("#42d8ff")
const C_CYAN_SOFT = Color("#8ce8ff")
const C_GREEN = Color("#7fe3a0")
const C_RED = Color("#ff4d4d")
const C_SAND = Color("#e8dfcf")

var game
var font_regular: SystemFont
var font_display: SystemFont
var theme: Theme

var root: Control
var loading_layer: Control
var menu_layer: Control
var hud_layer: Control
var buy_layer: Control
var pause_layer: Control
var scoreboard_layer: Control
var manual_layer: Control
var settings_layer: Control
var end_layer: Control
var damage_overlay: ColorRect
var crosshair: Crosshair
var minimap: MiniMap
var banner: Control
var banner_kicker: Label
var banner_title: Label
var banner_sub: Label
var banner_tween: Tween
var toast_box: VBoxContainer
var kill_feed: VBoxContainer

var menu_side = "random"
var knife_buttons: Dictionary = {}
var buy_open = false
var current_tab = "primary"
var current_budget = 10000
var loadout = {"primary_id": "ar21", "secondary_id": "p9", "armor": true, "kit": false, "ammo": false}
var attachments = {}
var buy_deploy_btn: Button
var buy_money_label: Label
var buy_clock_label: Label
var buy_list: GridContainer
var weapon_preview
var buy_list_kicker: Label
var loadout_list: VBoxContainer
var loadout_stats: VBoxContainer
var buy_tabs: Array[Button] = []
var _manual_from_pause = false

# HUD refs
var score_attack: Label
var score_defense: Label
var alive_attack: Label
var alive_defense: Label
var dots_attack: HBoxContainer
var dots_defense: HBoxContainer
var round_number_label: Label
var round_timer: Label
var round_phase: Label
var objective_label: Label
var bomb_clock: Label
var health_label: Label
var armor_label: Label
var money_label: Label
var kit_label: Label
var carry_label: Label
var operator_side: Label
var weapon_class: Label
var weapon_mode: Label
var weapon_name: Label
var ammo_mag: Label
var ammo_reserve: Label
var ammo_sep: Label
var reload_hint: Label
var slot_primary: Button
var slot_secondary: Button
var slot_knife: Button
var interaction_panel: PanelContainer
var interaction_label: Label
var interaction_time: Label
var interaction_bar: ProgressBar
var planted_alert: PanelContainer
var spectate_panel: PanelContainer
var weapon_panel: PanelContainer
var vitals_panel: PanelContainer
var fps_label: Label

func setup(game_ref) -> void:
	game = game_ref
	layer = 20
	_build_fonts()
	_build_root()
	_build_loading()
	_build_menu()
	_build_hud()
	_build_buy()
	_build_pause()
	_build_scoreboard()
	_build_manual()
	_build_settings()
	_build_end()
	show_menu()

func _build_fonts() -> void:
	font_regular = SystemFont.new()
	font_regular.font_names = PackedStringArray(["Microsoft YaHei UI", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", "Arial"])
	font_regular.font_weight = 500
	font_regular.allow_system_fallback = true
	font_display = SystemFont.new()
	font_display.font_names = PackedStringArray(["Bahnschrift", "DIN Alternate", "Microsoft YaHei UI", "Arial Narrow", "Arial"])
	font_display.font_weight = 700
	font_display.allow_system_fallback = true
	theme = Theme.new()
	theme.default_font = font_regular
	theme.default_font_size = 14

	attachments = {}
	for id in GameConfig.DEFAULT_ATTACHMENTS.keys():
		attachments[id] = (GameConfig.DEFAULT_ATTACHMENTS[id] as Dictionary).duplicate(true)

func _build_root() -> void:
	root = Control.new()
	root.name = "UIRoot"
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.theme = theme
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

func _build_loading() -> void:
	loading_layer = Control.new()
	loading_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	loading_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(loading_layer)
	var bg = ColorRect.new()
	bg.color = C_BG
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	loading_layer.add_child(bg)
	var center = VBoxContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	center.position = Vector2(-130, -60)
	center.custom_minimum_size = Vector2(260, 120)
	center.alignment = BoxContainer.ALIGNMENT_CENTER
	loading_layer.add_child(center)
	var mark = Label.new()
	mark.text = "◇"
	mark.add_theme_font_size_override("font_size", 52)
	mark.add_theme_color_override("font_color", C_ORANGE)
	mark.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	center.add_child(mark)
	var title = Label.new()
	title.text = "ZERO POINT"
	title.add_theme_font_override("font", font_display)
	title.add_theme_font_size_override("font_size", 18)
	title.add_theme_color_override("font_color", C_TEXT)
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	center.add_child(title)
	var sub = Label.new()
	sub.name = "LoadingSub"
	sub.text = "正在建立战术链路"
	sub.add_theme_font_size_override("font_size", 11)
	sub.add_theme_color_override("font_color", C_MUTED)
	sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	center.add_child(sub)

func hide_loading() -> void:
	var t = create_tween()
	t.tween_property(loading_layer, "modulate:a", 0.0, 0.55)
	t.tween_callback(loading_layer.hide)

# ============================================================
# Helpers
# ============================================================
func _style(bg: Color, border = Color.TRANSPARENT, border_width = 0, radius = 0, margin = 12) -> StyleBoxFlat:
	var s = StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(border_width)
	s.set_corner_radius_all(radius)
	s.content_margin_left = margin
	s.content_margin_right = margin
	s.content_margin_top = margin
	s.content_margin_bottom = margin
	return s

func _label(text: String, size: int, color = C_TEXT, font: Font = null) -> Label:
	var l = Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	if font:
		l.add_theme_font_override("font", font)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return l

func _panel(style: StyleBoxFlat) -> PanelContainer:
	var p = PanelContainer.new()
	p.add_theme_stylebox_override("panel", style)
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return p

func _margin(child: Control, left: int, top: int, right: int, bottom: int) -> MarginContainer:
	var m = MarginContainer.new()
	m.add_theme_constant_override("margin_left", left)
	m.add_theme_constant_override("margin_top", top)
	m.add_theme_constant_override("margin_right", right)
	m.add_theme_constant_override("margin_bottom", bottom)
	m.add_child(child)
	return m

func _add_rect(parent: Control, color: Color, anchor_left: float, anchor_top: float, anchor_right: float, anchor_bottom: float, left: float, top: float, right: float, bottom: float) -> ColorRect:
	var r = ColorRect.new()
	r.color = color
	r.anchor_left = anchor_left
	r.anchor_top = anchor_top
	r.anchor_right = anchor_right
	r.anchor_bottom = anchor_bottom
	r.offset_left = left
	r.offset_top = top
	r.offset_right = right
	r.offset_bottom = bottom
	r.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(r)
	return r

func _make_button(text: String, font_size = 13, primary = false) -> Button:
	var b = Button.new()
	b.text = text
	b.focus_mode = Control.FOCUS_NONE
	b.add_theme_font_size_override("font_size", font_size)
	b.mouse_default_cursor_shape = Control.CURSOR_POINTING_HAND
	if primary:
		b.add_theme_stylebox_override("normal", _style(C_ORANGE, C_ORANGE, 0, 2, 14))
		b.add_theme_stylebox_override("hover", _style(Color("#ff814b"), C_ORANGE, 0, 2, 14))
		b.add_theme_stylebox_override("pressed", _style(Color("#e85a1e"), C_ORANGE, 0, 2, 14))
		b.add_theme_color_override("font_color", Color("#0c0c0c"))
		b.add_theme_color_override("font_hover_color", Color("#0c0c0c"))
		b.add_theme_color_override("font_pressed_color", Color("#0c0c0c"))
	else:
		b.add_theme_stylebox_override("normal", _style(Color(1, 1, 1, 0.015), C_LINE, 1, 2, 12))
		b.add_theme_stylebox_override("hover", _style(Color(1, 1, 1, 0.06), C_LINE_STRONG, 1, 2, 12))
		b.add_theme_stylebox_override("pressed", _style(Color(1, 1, 1, 0.1), C_LINE_STRONG, 1, 2, 12))
		b.add_theme_color_override("font_color", C_MUTED)
		b.add_theme_color_override("font_hover_color", C_TEXT)
	b.add_theme_stylebox_override("disabled", _style(Color(1, 1, 1, 0.02), C_LINE, 1, 2, 12))
	b.add_theme_color_override("font_disabled_color", Color(1, 1, 1, 0.2))
	return b

func _spacer(height: int) -> Control:
	var c = Control.new()
	c.custom_minimum_size = Vector2(0, height)
	c.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return c

# ============================================================
# Main menu
# ============================================================
func _build_menu() -> void:
	menu_layer = Control.new()
	menu_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	menu_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	root.add_child(menu_layer)

	var base_dim = ColorRect.new()
	base_dim.color = Color(0.016, 0.031, 0.043, 0.5)
	base_dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	base_dim.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_layer.add_child(base_dim)

	var grad = Gradient.new()
	grad.offsets = PackedFloat32Array([0.0, 0.35, 0.66, 1.0])
	grad.colors = PackedColorArray([
		Color(0.016, 0.031, 0.043, 0.97),
		Color(0.016, 0.031, 0.043, 0.86),
		Color(0.016, 0.031, 0.043, 0.25),
		Color(0.016, 0.031, 0.043, 0.55),
	])
	var gtex = GradientTexture2D.new()
	gtex.gradient = grad
	gtex.width = 256
	gtex.height = 8
	gtex.fill_from = Vector2(0, 0)
	gtex.fill_to = Vector2(1, 0)
	var gleft = TextureRect.new()
	gleft.texture = gtex
	gleft.anchor_left = 0.0
	gleft.anchor_top = 0.0
	gleft.anchor_right = 0.7
	gleft.anchor_bottom = 1.0
	gleft.offset_left = 0
	gleft.offset_top = 0
	gleft.offset_right = 0
	gleft.offset_bottom = 0
	gleft.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	gleft.stretch_mode = TextureRect.STRETCH_SCALE
	gleft.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_layer.add_child(gleft)

	# 顶栏
	var top = HBoxContainer.new()
	top.anchor_left = 0
	top.anchor_top = 0
	top.anchor_right = 1
	top.anchor_bottom = 0
	top.offset_left = 42
	top.offset_top = 24
	top.offset_right = -42
	top.offset_bottom = 66
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_layer.add_child(top)
	var brand_mark = _label("◇", 26, C_ORANGE, font_display)
	top.add_child(brand_mark)
	var brand_box = VBoxContainer.new()
	brand_box.add_theme_constant_override("separation", 0)
	brand_box.add_child(_label("零点交火", 15, C_TEXT))
	brand_box.add_child(_label("ZERO POINT", 8, C_DIM, font_display))
	top.add_child(brand_box)
	var top_spacer = Control.new()
	top_spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	top_spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(top_spacer)
	var status = _label("●  战术网络在线    /    BUILD 0.1.0", 9, C_DIM, font_display)
	top.add_child(status)
	var line = ColorRect.new()
	line.color = C_LINE
	line.anchor_left = 0
	line.anchor_top = 0
	line.anchor_right = 1
	line.anchor_bottom = 0
	line.offset_left = 42
	line.offset_top = 80
	line.offset_right = -42
	line.offset_bottom = 81
	line.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_layer.add_child(line)

	# 左侧主文案
	var hero = VBoxContainer.new()
	hero.anchor_left = 0
	hero.anchor_top = 0
	hero.anchor_right = 0.6
	hero.anchor_bottom = 1
	hero.offset_left = 58
	hero.offset_top = 160
	hero.offset_right = -80
	hero.offset_bottom = -150
	hero.add_theme_constant_override("separation", 10)
	hero.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_layer.add_child(hero)
	hero.add_child(_label("——  5V5 TACTICAL DEMOLITION", 10, C_ORANGE_SOFT, font_display))
	var title_cn = _label("零点交火", 84, C_TEXT, font_regular)
	title_cn.add_theme_constant_override("outline_size", 0)
	hero.add_child(title_cn)
	var title_en = _label("ZERO\nPOINT", 48, Color(1, 1, 1, 0.02), font_display)
	title_en.add_theme_color_override("font_outline_color", Color(1.0, 0.42, 0.17, 0.8))
	title_en.add_theme_constant_override("outline_size", 2)
	title_en.add_theme_constant_override("line_spacing", 2)
	hero.add_child(title_en)
	var desc = _label("黑匣已接入电网。突破防线，安放炸弹；\n或者，在倒计时归零前把它拆掉。", 15, Color("#a9b5bb"))
	desc.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	hero.add_child(desc)
	hero.add_child(_spacer(12))

	var actions = HBoxContainer.new()
	actions.add_theme_constant_override("separation", 10)
	hero.add_child(actions)
	var start_btn = _make_button("进入行动   →", 18, true)
	start_btn.custom_minimum_size = Vector2(260, 62)
	start_btn.pressed.connect(func(): game.start_match(menu_side))
	actions.add_child(start_btn)
	var manual_btn = _make_button("作战手册  [H]", 13, false)
	manual_btn.custom_minimum_size = Vector2(130, 62)
	manual_btn.pressed.connect(func(): show_manual(false))
	actions.add_child(manual_btn)

	hero.add_child(_spacer(12))
	var random_note = HBoxContainer.new()
	random_note.add_theme_constant_override("separation", 8)
	random_note.add_child(_label("◈", 11, C_ORANGE))
	random_note.add_child(_label("攻防阵营每局随机分配", 10, C_MUTED))
	var note_tag = _label("RANDOM SIDE", 8, C_DIM, font_display)
	random_note.add_child(note_tag)
	hero.add_child(random_note)

	hero.add_child(_spacer(5))
	var knife_row = HBoxContainer.new()
	knife_row.add_theme_constant_override("separation", 6)
	knife_row.add_child(_label("近战武器 · 局外配置", 9, C_DIM))
	for knife_id in GameConfig.KNIFE_ORDER:
		var knife_def: Dictionary = GameConfig.KNIVES[knife_id]
		var kb := _make_button(String(knife_def["short"]), 10)
		kb.custom_minimum_size = Vector2(76, 30)
		kb.tooltip_text = String(knife_def["desc"])
		kb.pressed.connect(func(): _select_knife(knife_id))
		knife_buttons[knife_id] = kb
		knife_row.add_child(kb)
	hero.add_child(knife_row)
	_refresh_knife_buttons()

	# 右侧任务面板
	var mission = _panel(_style(C_PANEL, C_LINE, 1, 3, 18))
	mission.anchor_left = 1.0
	mission.anchor_top = 0.0
	mission.anchor_right = 1.0
	mission.anchor_bottom = 0.0
	mission.offset_left = -428
	mission.offset_top = 138
	mission.offset_right = -42
	mission.offset_bottom = 758
	mission.mouse_filter = Control.MOUSE_FILTER_IGNORE
	menu_layer.add_child(mission)
	var mission_v = VBoxContainer.new()
	mission_v.add_theme_constant_override("separation", 8)
	mission.add_child(mission_v)
	mission_v.add_child(_label("OPERATION / 01", 9, C_ORANGE_SOFT, font_display))
	var mission_head = HBoxContainer.new()
	mission_head.add_child(_label("零点电站", 28, C_TEXT))
	var mspacer = Control.new()
	mspacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mission_head.add_child(mspacer)
	mission_head.add_child(_label("ZP-01", 9, C_MUTED, font_display))
	mission_v.add_child(mission_head)
	mission_v.add_child(_label("ZERO POINT SUBSTATION  /  80 × 60 M", 8, C_DIM, font_display))
	var diagram = MapDiagram.new()
	diagram.custom_minimum_size = Vector2(0, 160)
	diagram.size_flags_vertical = Control.SIZE_EXPAND_FILL
	diagram.setup(font_regular)
	mission_v.add_child(diagram)
	var facts = GridContainer.new()
	facts.columns = 2
	facts.add_theme_constant_override("h_separation", 18)
	facts.add_theme_constant_override("v_separation", 7)
	mission_v.add_child(facts)
	for row in [
		["赛制", "5V5 · 先取 6 分"],
		["炸弹", "安放 10s · 引爆 40s"],
		["经济", "每回合 10,000 信用点"],
		["换边", "第 6 回合后"],
	]:
		facts.add_child(_label(row[0], 10, C_DIM))
		var value = _label(row[1], 10, C_TEXT)
		value.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		value.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		facts.add_child(value)
	var mfooter = HBoxContainer.new()
	mfooter.add_child(_label("●  LOCAL SIMULATION", 8, Color(0.5, 0.89, 0.63, 0.8), font_display))
	var fspacer = Control.new()
	fspacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	mfooter.add_child(fspacer)
	mfooter.add_child(_label("ATK / DEF", 8, C_DIM, font_display))
	mission_v.add_child(mfooter)

	# 底栏
	var bottom = HBoxContainer.new()
	bottom.anchor_left = 0
	bottom.anchor_top = 1
	bottom.anchor_right = 1
	bottom.anchor_bottom = 1
	bottom.offset_left = 42
	bottom.offset_top = -52
	bottom.offset_right = -42
	bottom.offset_bottom = -24
	menu_layer.add_child(bottom)
	bottom.add_child(_label("点击“进入行动”后锁定鼠标", 9, C_DIM))
	bottom.add_child(_label("  /  WASD 移动 · 左键射击 · E 交互", 9, C_DIM))
	var bspacer = Control.new()
	bspacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bottom.add_child(bspacer)
	bottom.add_child(_label("HEADPHONES RECOMMENDED  ▮▮▮", 8, C_DIM, font_display))

# ============================================================
# HUD
# ============================================================
func _build_hud() -> void:
	hud_layer = Control.new()
	hud_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud_layer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(hud_layer)
	hud_layer.visible = false

	damage_overlay = ColorRect.new()
	damage_overlay.color = Color(0.7, 0.04, 0.02, 0.0)
	damage_overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	damage_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_layer.add_child(damage_overlay)

	# 顶部比分
	var top = HBoxContainer.new()
	top.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	top.position = Vector2(-270, 16)
	top.custom_minimum_size = Vector2(540, 90)
	top.add_theme_constant_override("separation", 0)
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_layer.add_child(top)
	var a_panel = _panel(_style(C_PANEL, Color(1, 0.42, 0.15, 0.35), 1, 0, 10))
	a_panel.custom_minimum_size = Vector2(185, 90)
	a_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(a_panel)
	var a_box = VBoxContainer.new()
	a_box.add_theme_constant_override("separation", 1)
	a_panel.add_child(a_box)
	var a_top = HBoxContainer.new()
	a_top.add_child(_label("ATK", 9, C_ORANGE, font_display))
	var a_spacer = Control.new()
	a_spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	a_top.add_child(a_spacer)
	score_attack = _label("0", 30, C_ORANGE_SOFT, font_display)
	a_top.add_child(score_attack)
	a_box.add_child(a_top)
	var a_bottom = HBoxContainer.new()
	a_bottom.add_child(_label("进攻方", 9, C_DIM))
	var a_b_spacer = Control.new()
	a_b_spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	a_bottom.add_child(a_b_spacer)
	alive_attack = _label("5", 10, C_MUTED, font_display)
	a_bottom.add_child(alive_attack)
	a_box.add_child(a_bottom)
	dots_attack = HBoxContainer.new()
	dots_attack.add_theme_constant_override("separation", 3)
	a_box.add_child(dots_attack)

	var clock_panel = _panel(_style(Color(0.024, 0.04, 0.05, 0.97), C_LINE, 1, 0, 8))
	clock_panel.custom_minimum_size = Vector2(132, 90)
	top.add_child(clock_panel)
	var clock_box = VBoxContainer.new()
	clock_box.alignment = BoxContainer.ALIGNMENT_CENTER
	clock_panel.add_child(clock_box)
	var round_line = HBoxContainer.new()
	round_line.alignment = BoxContainer.ALIGNMENT_CENTER
	round_line.add_child(_label("ROUND ", 8, C_DIM, font_display))
	round_number_label = _label("01", 8, C_MUTED, font_display)
	round_line.add_child(round_number_label)
	clock_box.add_child(round_line)
	round_timer = _label("1:30", 27, C_SAND, font_display)
	round_timer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	clock_box.add_child(round_timer)
	round_phase = _label("行动阶段", 8, C_MUTED)
	round_phase.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	clock_box.add_child(round_phase)

	var d_panel = _panel(_style(C_PANEL, Color(0.25, 0.85, 1.0, 0.3), 1, 0, 10))
	d_panel.custom_minimum_size = Vector2(185, 90)
	top.add_child(d_panel)
	var d_box = VBoxContainer.new()
	d_box.add_theme_constant_override("separation", 1)
	d_panel.add_child(d_box)
	var d_top = HBoxContainer.new()
	score_defense = _label("0", 30, C_CYAN_SOFT, font_display)
	d_top.add_child(score_defense)
	var d_spacer = Control.new()
	d_spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	d_top.add_child(d_spacer)
	d_top.add_child(_label("DEF", 9, C_CYAN, font_display))
	d_box.add_child(d_top)
	var d_bottom = HBoxContainer.new()
	alive_defense = _label("5", 10, C_MUTED, font_display)
	d_bottom.add_child(alive_defense)
	var d_b_spacer = Control.new()
	d_b_spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	d_bottom.add_child(d_b_spacer)
	d_bottom.add_child(_label("防守方", 9, C_DIM))
	d_box.add_child(d_bottom)
	dots_defense = HBoxContainer.new()
	dots_defense.add_theme_constant_override("separation", 3)
	dots_defense.alignment = BoxContainer.ALIGNMENT_END
	d_box.add_child(dots_defense)

	for i in 6:
		var da = ColorRect.new()
		da.color = Color(1, 1, 1, 0.08)
		da.custom_minimum_size = Vector2(14, 3)
		dots_attack.add_child(da)
		var dd = ColorRect.new()
		dd.color = Color(1, 1, 1, 0.08)
		dd.custom_minimum_size = Vector2(14, 3)
		dots_defense.add_child(dd)

	# 目标条
	var obj_panel = _panel(_style(Color(0.024, 0.04, 0.05, 0.7), C_LINE, 1, 0, 6))
	obj_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	obj_panel.position = Vector2(-240, 112)
	obj_panel.custom_minimum_size = Vector2(480, 28)
	hud_layer.add_child(obj_panel)
	var obj_box = HBoxContainer.new()
	obj_box.add_theme_constant_override("separation", 8)
	obj_panel.add_child(obj_box)
	obj_box.add_child(_label("◇", 10, C_ORANGE))
	objective_label = _label("前往 A / B 包点，安放黑匣炸弹", 9, C_MUTED)
	objective_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	obj_box.add_child(objective_label)
	bomb_clock = _label("", 11, C_ORANGE_SOFT, font_display)
	obj_box.add_child(bomb_clock)

	# 雷达
	var radar = _panel(_style(C_PANEL, C_LINE, 1, 0, 8))
	radar.anchor_left = 0
	radar.anchor_top = 0
	radar.offset_left = 18
	radar.offset_top = 18
	radar.offset_right = 238
	radar.offset_bottom = 208
	hud_layer.add_child(radar)
	var radar_box = VBoxContainer.new()
	radar_box.add_theme_constant_override("separation", 4)
	radar.add_child(radar_box)
	var radar_head = HBoxContainer.new()
	radar_head.add_child(_label("战术雷达", 8, C_MUTED, font_display))
	var r_spacer = Control.new()
	r_spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	radar_head.add_child(r_spacer)
	radar_head.add_child(_label("ZP-01", 7, C_DIM, font_display))
	radar_box.add_child(radar_head)
	minimap = MiniMap.new()
	minimap.custom_minimum_size = Vector2(204, 142)
	minimap.size_flags_vertical = Control.SIZE_EXPAND_FILL
	radar_box.add_child(minimap)
	var radar_foot = HBoxContainer.new()
	radar_foot.add_child(_label("● 友军  ● 已暴露  A 包点", 7, C_DIM))
	radar_box.add_child(radar_foot)

	# 击杀信息
	kill_feed = VBoxContainer.new()
	kill_feed.anchor_left = 1
	kill_feed.anchor_right = 1
	kill_feed.offset_left = -318
	kill_feed.offset_right = -18
	kill_feed.offset_top = 18
	kill_feed.offset_bottom = 260
	kill_feed.alignment = BoxContainer.ALIGNMENT_BEGIN
	kill_feed.add_theme_constant_override("separation", 4)
	kill_feed.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_layer.add_child(kill_feed)

	# 准星
	crosshair = Crosshair.new()
	crosshair.set_anchors_preset(Control.PRESET_CENTER)
	crosshair.anchor_left = 0.5
	crosshair.anchor_top = 0.5
	crosshair.anchor_right = 0.5
	crosshair.anchor_bottom = 0.5
	crosshair.offset_left = -32
	crosshair.offset_top = -32
	crosshair.offset_right = 32
	crosshair.offset_bottom = 32
	hud_layer.add_child(crosshair)
	crosshair.offset_left = -32
	crosshair.offset_top = -32
	crosshair.offset_right = 32
	crosshair.offset_bottom = 32

	# 左下生命
	vitals_panel = _panel(_style(C_PANEL, C_LINE, 1, 0, 12))
	vitals_panel.anchor_left = 0
	vitals_panel.anchor_top = 1
	vitals_panel.offset_left = 18
	vitals_panel.offset_top = -176
	vitals_panel.offset_right = 288
	vitals_panel.offset_bottom = -18
	hud_layer.add_child(vitals_panel)
	var vbox = VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 5)
	vitals_panel.add_child(vbox)
	var op = HBoxContainer.new()
	op.add_child(_label("游隼", 14, C_TEXT))
	operator_side = _label("ATK", 8, C_ORANGE, font_display)
	op.add_child(operator_side)
	var o_spacer = Control.new()
	o_spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	op.add_child(o_spacer)
	op.add_child(_label("₡ ", 10, C_GREEN))
	money_label = _label("10,000", 10, C_GREEN, font_display)
	op.add_child(money_label)
	vbox.add_child(op)
	vbox.add_child(_hp_row("生命", C_ORANGE, "health"))
	vbox.add_child(_hp_row("护甲", C_CYAN, "armor"))
	var vmeta = HBoxContainer.new()
	kit_label = _label("无拆弹器", 8, C_DIM)
	vmeta.add_child(kit_label)
	var vm_spacer = Control.new()
	vm_spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	vmeta.add_child(vm_spacer)
	carry_label = _label("携带黑匣", 8, C_ORANGE_SOFT)
	carry_label.visible = false
	vmeta.add_child(carry_label)
	vbox.add_child(vmeta)

	# 右下武器
	weapon_panel = _panel(_style(C_PANEL, C_LINE, 1, 0, 12))
	weapon_panel.anchor_left = 1
	weapon_panel.anchor_top = 1
	weapon_panel.offset_left = -298
	weapon_panel.offset_top = -176
	weapon_panel.offset_right = -18
	weapon_panel.offset_bottom = -18
	hud_layer.add_child(weapon_panel)
	var wbox = VBoxContainer.new()
	wbox.add_theme_constant_override("separation", 2)
	weapon_panel.add_child(wbox)
	var wtop = HBoxContainer.new()
	weapon_class = _label("突击步枪", 8, C_DIM, font_display)
	wtop.add_child(weapon_class)
	var w_spacer = Control.new()
	w_spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	wtop.add_child(w_spacer)
	weapon_mode = _label("全自动", 8, C_DIM, font_display)
	wtop.add_child(weapon_mode)
	wbox.add_child(wtop)
	weapon_name = _label("AR-21「熔火」", 14, C_TEXT)
	weapon_name.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	wbox.add_child(weapon_name)
	var ammo_row = HBoxContainer.new()
	ammo_row.alignment = BoxContainer.ALIGNMENT_END
	ammo_mag = _label("30", 38, C_SAND, font_display)
	ammo_row.add_child(ammo_mag)
	ammo_sep = _label(" / ", 15, C_DIM)
	ammo_row.add_child(ammo_sep)
	ammo_reserve = _label("90", 15, C_MUTED, font_display)
	ammo_row.add_child(ammo_reserve)
	wbox.add_child(ammo_row)
	var slots = HBoxContainer.new()
	slots.add_theme_constant_override("separation", 4)
	wbox.add_child(slots)
	slot_primary = _make_button("1 主武器", 8)
	slot_secondary = _make_button("2 副武器", 8)
	slot_knife = _make_button("3 刀", 8)
	for b in [slot_primary, slot_secondary, slot_knife]:
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.disabled = false
		b.mouse_filter = Control.MOUSE_FILTER_IGNORE
		slots.add_child(b)
	reload_hint = _label("R 换弹", 8, C_ORANGE_SOFT)
	reload_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	reload_hint.visible = false
	wbox.add_child(reload_hint)

	# 交互提示
	interaction_panel = _panel(_style(Color(0.024, 0.04, 0.05, 0.9), C_ORANGE, 1, 0, 9))
	interaction_panel.anchor_left = 0.5
	interaction_panel.anchor_top = 1
	interaction_panel.anchor_right = 0.5
	interaction_panel.anchor_bottom = 1
	interaction_panel.offset_left = -160
	interaction_panel.offset_top = -258
	interaction_panel.offset_right = 160
	interaction_panel.offset_bottom = -204
	interaction_panel.visible = false
	hud_layer.add_child(interaction_panel)
	var ibox = VBoxContainer.new()
	interaction_panel.add_child(ibox)
	var iline = HBoxContainer.new()
	var key = _label("E", 10, C_ORANGE_SOFT, font_display)
	key.custom_minimum_size = Vector2(22, 20)
	key.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	iline.add_child(key)
	interaction_label = _label("安放炸弹", 10, C_TEXT)
	interaction_label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	iline.add_child(interaction_label)
	interaction_time = _label("10.0s", 10, C_ORANGE_SOFT, font_display)
	iline.add_child(interaction_time)
	ibox.add_child(iline)
	interaction_bar = ProgressBar.new()
	interaction_bar.custom_minimum_size = Vector2(0, 3)
	interaction_bar.show_percentage = false
	interaction_bar.max_value = 1.0
	interaction_bar.value = 0.0
	interaction_bar.add_theme_stylebox_override("background", _style(Color(1, 1, 1, 0.08), Color.TRANSPARENT, 0, 0, 0))
	interaction_bar.add_theme_stylebox_override("fill", _style(C_ORANGE, Color.TRANSPARENT, 0, 0, 0))
	ibox.add_child(interaction_bar)

	# 已安放警告
	planted_alert = _panel(_style(Color(0.16, 0.035, 0.03, 0.88), Color(1, 0.3, 0.25, 0.35), 1, 0, 8))
	planted_alert.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	planted_alert.position = Vector2(-105, 140)
	planted_alert.custom_minimum_size = Vector2(210, 38)
	planted_alert.visible = false
	hud_layer.add_child(planted_alert)
	var pa = HBoxContainer.new()
	pa.add_child(_label("●", 10, C_RED))
	var ptxt = VBoxContainer.new()
	ptxt.add_child(_label("黑匣炸弹已激活", 9, Color("#ffb0a5")))
	ptxt.add_child(_label("立即前往拆除", 8, Color(1, 0.6, 0.55, 0.6)))
	pa.add_child(ptxt)
	planted_alert.add_child(pa)

	# 阵亡观战
	spectate_panel = _panel(_style(Color(0.02, 0.035, 0.045, 0.7), C_LINE, 1, 0, 12))
	spectate_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	spectate_panel.position = Vector2(-120, -30)
	spectate_panel.custom_minimum_size = Vector2(240, 60)
	spectate_panel.visible = false
	hud_layer.add_child(spectate_panel)
	var sbox = VBoxContainer.new()
	sbox.alignment = BoxContainer.ALIGNMENT_CENTER
	sbox.add_child(_label("你已阵亡", 9, C_ORANGE_SOFT))
	var spec = _label("观战中 · 等待回合结束", 10, C_MUTED)
	spec.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sbox.add_child(spec)
	spectate_panel.add_child(sbox)

	# 鍥炲悎妯箙
	banner = Control.new()
	banner.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	banner.position = Vector2(-300, -170)
	banner.custom_minimum_size = Vector2(600, 100)
	banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	hud_layer.add_child(banner)
	var bbox = VBoxContainer.new()
	bbox.alignment = BoxContainer.ALIGNMENT_CENTER
	bbox.add_theme_constant_override("separation", 2)
	banner.add_child(bbox)
	banner_kicker = _label("ROUND 01", 9, C_ORANGE_SOFT, font_display)
	banner_kicker.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	bbox.add_child(banner_kicker)
	banner_title = _label("行动开始", 32, C_TEXT)
	banner_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	bbox.add_child(banner_title)
	banner_sub = _label("安放黑匣炸弹，摧毁目标", 10, C_MUTED)
	banner_sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	bbox.add_child(banner_sub)
	banner.modulate.a = 0.0

	fps_label = _label("-- FPS", 8, Color(1, 1, 1, 0.3), font_display)
	fps_label.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	fps_label.position = Vector2(-20, 4)
	hud_layer.add_child(fps_label)

func _hp_row(label_text: String, color: Color, kind: String) -> HBoxContainer:
	var row = HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	var icon = _label("+" if kind == "health" else "◈", 12, color if kind == "health" else C_CYAN_SOFT, font_display)
	icon.custom_minimum_size = Vector2(20, 20)
	icon.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	row.add_child(icon)
	var box = VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(box)
	var line = HBoxContainer.new()
	line.add_child(_label(label_text, 8, C_DIM))
	var spacer = Control.new()
	spacer.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	line.add_child(spacer)
	var value = _label("100" if kind == "health" else "0", 18, C_SAND, font_display)
	line.add_child(value)
	box.add_child(line)
	var bar = ProgressBar.new()
	bar.custom_minimum_size = Vector2(0, 5)
	bar.show_percentage = false
	bar.max_value = 100.0
	bar.value = 100.0 if kind == "health" else 0.0
	bar.add_theme_stylebox_override("background", _style(Color(1, 1, 1, 0.07), Color.TRANSPARENT, 0, 0, 0))
	bar.add_theme_stylebox_override("fill", _style(color if kind == "health" else C_CYAN, Color.TRANSPARENT, 0, 0, 0))
	if kind == "health":
		health_label = value
		health_bar = bar
	else:
		armor_label = value
		armor_bar = bar
	box.add_child(bar)
	return row

var health_bar: ProgressBar
var armor_bar: ProgressBar

func _select_knife(knife_id: String) -> void:
	if not GameConfig.KNIVES.has(knife_id):
		return
	game.settings["knife"] = knife_id
	game.save_settings()
	_refresh_knife_buttons()

func _refresh_knife_buttons() -> void:
	var selected := String(game.settings.get("knife", "tactical"))
	for id in knife_buttons.keys():
		var b: Button = knife_buttons[id]
		var active: bool = id == selected
		b.add_theme_stylebox_override("normal", _style(C_ORANGE.darkened(0.75) if active else Color(1, 1, 1, 0.015), C_ORANGE if active else C_LINE, 1, 2, 8))
		b.add_theme_color_override("font_color", C_ORANGE_SOFT if active else C_MUTED)

# ============================================================
# Buy menu
# ============================================================
func _build_buy() -> void:
	buy_layer = Control.new()
	buy_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	buy_layer.mouse_filter = Control.MOUSE_FILTER_STOP
	buy_layer.visible = false
	root.add_child(buy_layer)
	var dim = ColorRect.new()
	dim.color = Color(0.01, 0.02, 0.025, 0.8)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	buy_layer.add_child(dim)
	var shell = _panel(_style(Color(0.031, 0.047, 0.059, 0.985), C_LINE, 1, 2, 0))
	shell.anchor_left = 0.04
	shell.anchor_top = 0.05
	shell.anchor_right = 0.96
	shell.anchor_bottom = 0.95
	buy_layer.add_child(shell)
	var main = VBoxContainer.new()
	main.add_theme_constant_override("separation", 0)
	shell.add_child(main)

	var header = _margin(_build_buy_header(), 22, 15, 22, 13)
	main.add_child(header)
	var divider = ColorRect.new()
	divider.color = C_LINE
	divider.custom_minimum_size = Vector2(0, 1)
	main.add_child(divider)

	var body = HBoxContainer.new()
	body.size_flags_vertical = Control.SIZE_EXPAND_FILL
	body.add_theme_constant_override("separation", 0)
	main.add_child(body)

	var tabs_wrap = _margin(_build_buy_tabs(), 0, 12, 0, 12)
	tabs_wrap.custom_minimum_size = Vector2(166, 0)
	body.add_child(tabs_wrap)
	var sep1 = ColorRect.new(); sep1.color = C_LINE; sep1.custom_minimum_size = Vector2(1, 0); body.add_child(sep1)

	var list_wrap = _margin(_build_buy_list_area(), 18, 14, 18, 14)
	list_wrap.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	body.add_child(list_wrap)
	var sep2 = ColorRect.new(); sep2.color = C_LINE; sep2.custom_minimum_size = Vector2(1, 0); body.add_child(sep2)

	var side_wrap = _margin(_build_buy_side(), 16, 14, 16, 14)
	side_wrap.custom_minimum_size = Vector2(280, 0)
	body.add_child(side_wrap)

	var footer = _margin(_build_buy_footer(), 22, 11, 22, 11)
	main.add_child(footer)

func _build_buy_header() -> Control:
	var h = HBoxContainer.new()
	h.add_theme_constant_override("separation", 18)
	h.add_theme_constant_override("separation", 18)
	var title_box = VBoxContainer.new()
	title_box.add_child(_label("ARMORY / 军械库", 9, C_ORANGE_SOFT, font_display))
	title_box.add_child(_label("配置你的下一回合", 24, C_TEXT))
	h.add_child(title_box)
	var sp = Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; h.add_child(sp)
	var money_box = VBoxContainer.new()
	money_box.add_child(_label("可用信用点", 8, C_DIM))
	var mrow = HBoxContainer.new()
	mrow.add_child(_label("₡ ", 13, C_GREEN, font_display))
	buy_money_label = _label("10,000", 26, C_GREEN, font_display)
	mrow.add_child(buy_money_label)
	money_box.add_child(mrow)
	h.add_child(money_box)
	var sep = ColorRect.new(); sep.color = C_LINE; sep.custom_minimum_size = Vector2(1, 44); h.add_child(sep)
	var time_box = VBoxContainer.new()
	time_box.add_child(_label("部署倒计时", 8, C_DIM))
	buy_clock_label = _label("0:12", 26, C_SAND, font_display)
	time_box.add_child(buy_clock_label)
	h.add_child(time_box)
	return h

func _build_buy_tabs() -> Control:
	var v = VBoxContainer.new()
	v.add_theme_constant_override("separation", 0)
	var defs = [["primary", "01  主武器", "PRIMARY"], ["secondary", "02  副武器", "SIDEARM"], ["gear", "03  护甲与道具", "GEAR"], ["mods", "04  武器改装", "GUNSMITH"]]
	for d in defs:
		var b = _make_button("%s\n%s" % [d[1], d[2]], 11)
		b.alignment = HORIZONTAL_ALIGNMENT_LEFT
		b.custom_minimum_size = Vector2(166, 58)
		b.pressed.connect(func(): current_tab = d[0]; _refresh_buy())
		v.add_child(b)
		buy_tabs.append(b)
	return v

func _build_buy_list_area() -> Control:
	var v = VBoxContainer.new()
	var head = HBoxContainer.new()
	buy_list_kicker = _label("PRIMARY WEAPONS", 9, C_MUTED, font_display)
	head.add_child(buy_list_kicker)
	var sp = Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; head.add_child(sp)
	head.add_child(_label("点击购买 · 同阵营掉落可回收", 8, C_DIM))
	v.add_child(head)
	var line = ColorRect.new(); line.color = C_LINE; line.custom_minimum_size = Vector2(0, 1); v.add_child(line)
	var scroll = ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(scroll)
	buy_list = GridContainer.new()
	buy_list.columns = 2
	buy_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	buy_list.add_theme_constant_override("h_separation", 8)
	buy_list.add_theme_constant_override("v_separation", 8)
	scroll.add_child(buy_list)
	var preview_panel = _panel(_style(Color(0.02, 0.033, 0.042, 0.7), C_LINE, 1, 0, 0))
	preview_panel.custom_minimum_size = Vector2(0, 205)
	weapon_preview = WeaponPreviewScript.new()
	weapon_preview.setup(font_regular)
	preview_panel.add_child(weapon_preview)
	v.add_child(preview_panel)
	return v

func _build_buy_side() -> Control:
	var v = VBoxContainer.new()
	var head = HBoxContainer.new()
	head.add_child(_label("当前配装", 9, C_MUTED))
	var sp = Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; head.add_child(sp)
	head.add_child(_label("LOADOUT", 8, C_DIM, font_display))
	v.add_child(head)
	var line = ColorRect.new(); line.color = C_LINE; line.custom_minimum_size = Vector2(0, 1); v.add_child(line)
	loadout_list = VBoxContainer.new()
	loadout_list.add_theme_constant_override("separation", 7)
	v.add_child(loadout_list)
	loadout_stats = VBoxContainer.new()
	loadout_stats.add_theme_constant_override("separation", 6)
	v.add_child(loadout_stats)
	var spacer = Control.new(); spacer.size_flags_vertical = Control.SIZE_EXPAND_FILL; v.add_child(spacer)
	var tip = _panel(_style(Color(1, 1, 1, 0.02), C_LINE, 1, 0, 8))
	var tip_label = _label("本回合拥有 10,000 信用点预算。所有枪械配件免费。阵亡敌人的装备可回收换取信用点。", 8, C_DIM)
	tip_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	tip.add_child(tip_label)
	v.add_child(tip)
	return v

func _build_buy_footer() -> Control:
	var h = HBoxContainer.new()
	h.add_child(_label("B 关闭军械库", 8, C_DIM, font_display))
	h.add_child(_label("  /  改装不影响价格", 8, C_DIM))
	var sp = Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; h.add_child(sp)
	buy_deploy_btn = _make_button("部署完毕  →", 15, true)
	buy_deploy_btn.custom_minimum_size = Vector2(220, 46)
	buy_deploy_btn.pressed.connect(_on_deploy_pressed)
	h.add_child(buy_deploy_btn)
	return h

func _on_deploy_pressed() -> void:
	close_buy()
	game.ready_up()

func open_buy() -> void:
	if game.game_match == null or game.game_match.phase != "buy":
		return
	buy_open = true
	buy_layer.visible = true
	current_tab = "primary"
	current_budget = int(GameConfig.MATCH["start_credits"])
	game.on_buy_opened()
	_refresh_buy()

func close_buy(silent = false) -> void:
	if not buy_open:
		return
	buy_open = false
	buy_layer.visible = false
	if not silent:
		game.on_buy_closed()

func toggle_buy() -> void:
	if buy_open:
		close_buy()
	else:
		open_buy()

func get_round_loadout(side: String, budget = 10000) -> Dictionary:
	current_budget = budget
	var kit_allowed = side == "defense"
	var cost = _calc_cost(loadout["primary_id"], loadout["secondary_id"], loadout["armor"], kit_allowed and loadout["kit"], loadout["ammo"])
	var primary_id: String = loadout["primary_id"]
	var secondary_id: String = loadout["secondary_id"]
	return {
		"primary_id": primary_id,
		"primary_attachments": (attachments.get(primary_id, {}) as Dictionary).duplicate(),
		"secondary_id": secondary_id,
		"secondary_attachments": (attachments.get(secondary_id, {}) as Dictionary).duplicate(),
		"armor": 100 if loadout["armor"] else 0,
		"kit": kit_allowed and loadout["kit"],
		"ammo_bonus": 60 if loadout["ammo"] else 0,
		"cost": cost,
		"knife_id": String(game.settings.get("knife", "tactical")),
	}

func _calc_cost(primary_id: String, secondary_id: String, armor: bool, kit: bool, ammo: bool) -> int:
	var cost = 0
	if primary_id != "":
		cost += int(GameConfig.WEAPONS[primary_id]["price"])
	if secondary_id != "":
		cost += int(GameConfig.WEAPONS[secondary_id]["price"])
	if armor:
		cost += int(GameConfig.ECONOMY["armor_price"])
	if kit:
		cost += int(GameConfig.ECONOMY["kit_price"])
	if ammo:
		cost += int(GameConfig.ECONOMY["ammo_price"])
	return cost

func _refresh_buy() -> void:
	if buy_list == null:
		return
	for i in buy_tabs.size():
		var active: bool = ["primary", "secondary", "gear", "mods"][i] == current_tab
		var b: Button = buy_tabs[i]
		b.add_theme_stylebox_override("normal", _style(Color(0.15, 0.06, 0.03, 0.8) if active else Color(1, 1, 1, 0.01), C_ORANGE if active else C_LINE, 1, 0, 12))
		b.add_theme_color_override("font_color", C_ORANGE_SOFT if active else C_MUTED)
	for child in buy_list.get_children():
		child.queue_free()
	var cost = _calc_cost(loadout["primary_id"], loadout["secondary_id"], loadout["armor"], (loadout["kit"] and game.player.team == "defense"), loadout["ammo"])
	buy_money_label.text = _fmt_int(maxi(0, current_budget - cost))
	buy_clock_label.text = _clock_label(game.game_match.phase_time)
	buy_deploy_btn.disabled = cost > current_budget
	if current_tab == "primary":
		buy_list_kicker.text = "PRIMARY WEAPONS / 主武器"
		for id in GameConfig.PRIMARY_WEAPONS:
			buy_list.add_child(_weapon_card(id, "primary"))
	elif current_tab == "secondary":
		buy_list_kicker.text = "SIDEARMS / 副武器"
		for id in GameConfig.SECONDARY_WEAPONS:
			buy_list.add_child(_weapon_card(id, "secondary"))
	elif current_tab == "gear":
		buy_list_kicker.text = "ARMOR & UTILITY / 护甲与道具"
		buy_list.columns = 1
		buy_list.add_child(_gear_card("armor", "陶瓷护甲", "100 点护甲，优先吸收 50% 伤害。", int(GameConfig.ECONOMY["armor_price"]), loadout["armor"], true))
		buy_list.add_child(_gear_card("kit", "拆弹器", "拆除时间从 10 秒缩短到 5 秒。仅防守方可用。", int(GameConfig.ECONOMY["kit_price"]), loadout["kit"], game.player.team == "defense"))
		buy_list.add_child(_gear_card("ammo", "弹药补给", "所有武器备用弹药 +60。", int(GameConfig.ECONOMY["ammo_price"]), loadout["ammo"], true))
	else:
		buy_list_kicker.text = "GUNSMITH / 武器改装"
		buy_list.columns = 1
		_add_mods_ui()
	if current_tab != "gear" and current_tab != "mods":
		buy_list.columns = 2
	if weapon_preview:
		weapon_preview.set_weapon(GameConfig.WEAPONS[loadout["primary_id"]])
	_build_loadout_side()

func _weapon_card(id: String, slot_type: String) -> Button:
	var def: Dictionary = GameConfig.WEAPONS[id]
	var owned: bool = loadout["primary_id"] == id if slot_type == "primary" else loadout["secondary_id"] == id
	var b = Button.new()
	b.custom_minimum_size = Vector2(260, 100)
	b.focus_mode = Control.FOCUS_NONE
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.add_theme_font_size_override("font_size", 11)
	b.text = "%s\n%s · %s\n伤害 %d  /  RPM %d  /  弹匣 %d\n₡ %s" % [
		def["name"], def["class_label"], def["mode_label"], int(def["damage"]), int(def["rpm"]), int(def["mag"]),
		"已装备" if owned else _fmt_int(int(def["price"]))
	]
	b.add_theme_stylebox_override("normal", _style(Color(0.25, 0.47, 0.55, 0.12) if owned else Color(1, 1, 1, 0.02), C_CYAN if owned else C_LINE, 1, 0, 10))
	b.add_theme_stylebox_override("hover", _style(Color(1, 1, 1, 0.055), C_LINE_STRONG, 1, 0, 10))
	b.add_theme_stylebox_override("pressed", _style(Color(1, 1, 1, 0.08), C_ORANGE, 1, 0, 10))
	b.add_theme_color_override("font_color", C_TEXT)
	b.add_theme_color_override("font_hover_color", C_TEXT)
	b.pressed.connect(func(): _select_weapon(slot_type, id))
	return b

func _gear_card(key: String, name: String, desc: String, price: int, owned: bool, allowed: bool) -> Button:
	var b = Button.new()
	b.custom_minimum_size = Vector2(0, 62)
	b.focus_mode = Control.FOCUS_NONE
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.add_theme_font_size_override("font_size", 10)
	b.text = "%s  %s\n%s" % [name, "— 已装备" if owned else "— ₡ %s" % _fmt_int(price), desc]
	b.disabled = not allowed
	b.add_theme_stylebox_override("normal", _style(Color(0.25, 0.47, 0.55, 0.12) if owned else Color(1, 1, 1, 0.02), C_CYAN if owned else C_LINE, 1, 0, 8))
	b.add_theme_stylebox_override("hover", _style(Color(1, 1, 1, 0.055), C_LINE_STRONG, 1, 0, 8))
	b.pressed.connect(func(): _toggle_gear(key))
	return b

func _add_mods_ui() -> void:
	var primary: String = loadout["primary_id"]
	var header = _panel(_style(Color(1, 1, 1, 0.02), C_LINE, 1, 0, 8))
	var hv = VBoxContainer.new()
	hv.add_child(_label("%s · 免费改装" % GameConfig.WEAPONS[primary]["name"], 11, C_TEXT))
	hv.add_child(_label("所有配件免费。调整后立即反映到下一回合的枪械数值。", 8, C_DIM))
	header.add_child(hv)
	buy_list.add_child(header)
	for group in GameConfig.ATTACHMENT_GROUPS:
		var block = _panel(_style(Color(1, 1, 1, 0.015), C_LINE, 1, 0, 8))
		var vb = VBoxContainer.new()
		vb.add_theme_constant_override("separation", 5)
		var gh = HBoxContainer.new()
		gh.add_child(_label(group["label"], 10, C_MUTED))
		var sp = Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; gh.add_child(sp)
		gh.add_child(_label(group["en"], 7, C_DIM, font_display))
		vb.add_child(gh)
		var opts = HBoxContainer.new()
		opts.add_theme_constant_override("separation", 5)
		var chosen: String = attachments.get(primary, {}).get(group["id"], group["options"][0]["id"])
		for opt in group["options"]:
			var b = _make_button("%s\n%s" % [opt["label"], opt["note"]], 8)
			b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			b.custom_minimum_size = Vector2(0, 42)
			var active: bool = chosen == opt["id"]
			b.add_theme_stylebox_override("normal", _style(Color(0.18, 0.07, 0.03, 0.8) if active else Color(1, 1, 1, 0.02), C_ORANGE if active else C_LINE, 1, 2, 8))
			b.add_theme_color_override("font_color", C_ORANGE_SOFT if active else C_DIM)
			b.pressed.connect(func(): _select_attachment(group["id"], opt["id"]))
			opts.add_child(b)
		vb.add_child(opts)
		block.add_child(vb)
		buy_list.add_child(block)

func _select_weapon(slot_type: String, id: String) -> void:
	var key = "primary_id" if slot_type == "primary" else "secondary_id"
	var proposed: Dictionary = loadout.duplicate()
	proposed[key] = id
	var cost = _calc_cost(proposed["primary_id"], proposed["secondary_id"], proposed["armor"], (proposed["kit"] and game.player.team == "defense"), proposed["ammo"])
	if cost > current_budget:
		toast("信用点不足，无法购买该配装", "danger")
		return
	loadout = proposed
	game.audio.buy()
	_refresh_buy()

func _toggle_gear(key: String) -> void:
	if key == "kit" and game.player.team != "defense":
		toast("拆弹器仅防守方可用", "danger")
		return
	var proposed: Dictionary = loadout.duplicate()
	proposed[key] = not proposed[key]
	var cost = _calc_cost(proposed["primary_id"], proposed["secondary_id"], proposed["armor"], (proposed["kit"] and game.player.team == "defense"), proposed["ammo"])
	if cost > current_budget:
		toast("信用点不足，无法购买该配装", "danger")
		return
	loadout = proposed
	game.audio.buy()
	_refresh_buy()

func _select_attachment(group_id: String, option_id: String) -> void:
	var primary: String = loadout["primary_id"]
	attachments[primary][group_id] = option_id
	game.audio.buy()
	_refresh_buy()

func _build_loadout_side() -> void:
	if loadout_list == null:
		return
	for c in loadout_list.get_children():
		c.queue_free()
	for c in loadout_stats.get_children():
		c.queue_free()
	var primary: Dictionary = GameConfig.WEAPONS[loadout["primary_id"]]
	var secondary: Dictionary = GameConfig.WEAPONS[loadout["secondary_id"]]
	for row in [
		["PRIMARY / 主武器", primary["name"]],
		["SIDEARM / 副武器", secondary["name"]],
		["ARMOR / 护甲", "陶瓷护甲 · 100" if loadout["armor"] else "未装备"],
		["UTILITY / 道具", "拆弹器" if (loadout["kit"] and game.player.team == "defense") else "无"],
	]:
		var box = VBoxContainer.new()
		box.add_theme_constant_override("separation", 0)
		box.add_child(_label(row[0], 7, C_DIM, font_display))
		box.add_child(_label(row[1], 10, C_MUTED if row[1] == "未装备" or row[1] == "无" else C_TEXT))
		loadout_list.add_child(box)
	var bars = GameConfig.weapon_bars(primary)
	for row in [["伤害", bars["damage"]], ["控枪", bars["control"]], ["射程", bars["range"]], ["机动", bars["mobility"]]]:
		loadout_stats.add_child(_stat_line(row[0], row[1]))
	var cost = _calc_cost(loadout["primary_id"], loadout["secondary_id"], loadout["armor"], (loadout["kit"] and game.player.team == "defense"), loadout["ammo"])

func _stat_line(label_text: String, value: float) -> Control:
	var h = HBoxContainer.new()
	h.add_theme_constant_override("separation", 6)
	var l = _label(label_text, 7, C_DIM)
	l.custom_minimum_size = Vector2(38, 0)
	h.add_child(l)
	var bar = ProgressBar.new()
	bar.custom_minimum_size = Vector2(0, 3)
	bar.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	bar.show_percentage = false
	bar.max_value = 1.0
	bar.value = value
	bar.add_theme_stylebox_override("background", _style(Color(1, 1, 1, 0.07), Color.TRANSPARENT, 0, 0, 0))
	bar.add_theme_stylebox_override("fill", _style(C_CYAN, Color.TRANSPARENT, 0, 0, 0))
	h.add_child(bar)
	h.add_child(_label(str(roundi(value * 100)), 7, C_MUTED, font_display))
	return h

# ============================================================
# Pause / scoreboard / manual / settings / end
# ============================================================
func _build_pause() -> void:
	pause_layer = Control.new()
	pause_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	pause_layer.visible = false
	root.add_child(pause_layer)
	var dim = ColorRect.new(); dim.color = Color(0.01, 0.02, 0.025, 0.72); dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); pause_layer.add_child(dim)
	var panel = _panel(_style(Color(0.043, 0.063, 0.078, 0.98), C_LINE, 1, 2, 24))
	panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	panel.position = Vector2(-200, -210)
	panel.custom_minimum_size = Vector2(400, 420)
	pause_layer.add_child(panel)
	var v = VBoxContainer.new(); v.add_theme_constant_override("separation", 8); panel.add_child(v)
	v.add_child(_label("TACTICAL PAUSE", 8, C_ORANGE_SOFT, font_display))
	v.add_child(_label("行动暂停", 30, C_TEXT))
	v.add_child(_label("战术链路保持连接。你的小队正在等待。", 9, C_DIM))
	v.add_child(_spacer(10))
	var resume = _make_button("继续行动   →", 15, true); resume.custom_minimum_size = Vector2(0, 48); resume.pressed.connect(func(): game.resume()); v.add_child(resume)
	var manual = _make_button("作战手册", 12); manual.pressed.connect(func(): show_manual(true)); v.add_child(manual)
	var settings = _make_button("设置", 12); settings.pressed.connect(func(): show_settings(true)); v.add_child(settings)
	var leave = _make_button("撤离行动", 12); leave.pressed.connect(func(): game.return_to_menu()); v.add_child(leave)
	v.add_child(_spacer(10))
	var meta = HBoxContainer.new(); meta.add_child(_label("本地模拟 · 5V5", 7, C_DIM)); var sp = Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; meta.add_child(sp); meta.add_child(_label("ESC 返回战场", 7, C_DIM)); v.add_child(meta)

func show_pause(show: bool) -> void:
	pause_layer.visible = show
	if show:
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _build_scoreboard() -> void:
	scoreboard_layer = Control.new()
	scoreboard_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	scoreboard_layer.visible = false
	root.add_child(scoreboard_layer)
	var dim = ColorRect.new(); dim.color = Color(0.01, 0.02, 0.025, 0.62); dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); scoreboard_layer.add_child(dim)
	var panel = _panel(_style(Color(0.031, 0.047, 0.059, 0.98), C_LINE, 1, 2, 20))
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.position = Vector2(-440, -270)
	panel.custom_minimum_size = Vector2(880, 540)
	scoreboard_layer.add_child(panel)
	var v = VBoxContainer.new(); v.add_theme_constant_override("separation", 8); panel.add_child(v)
	var head = HBoxContainer.new()
	var hb = VBoxContainer.new(); hb.add_child(_label("TACTICAL OVERVIEW", 8, C_ORANGE_SOFT, font_display)); hb.add_child(_label("零点电站 · 行动数据", 20, C_TEXT)); head.add_child(hb)
	var sp = Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; head.add_child(sp)
	head.add_child(_label("先取 6 分 · 第 6 回合换边", 8, C_DIM))
	v.add_child(head)
	var rows = VBoxContainer.new(); rows.name = "Rows"; rows.size_flags_vertical = Control.SIZE_EXPAND_FILL; v.add_child(rows)
	v.add_child(_label("松开 TAB 关闭", 8, C_DIM))

func show_scoreboard(show: bool) -> void:
	scoreboard_layer.visible = show
	if show and game.game_match:
		_refresh_scoreboard()

func _refresh_scoreboard() -> void:
	var panel = scoreboard_layer.get_child(1)
	var rows = panel.get_child(0).get_node("Rows") as VBoxContainer
	for c in rows.get_children():
		c.queue_free()
	var score = HBoxContainer.new()
	score.add_child(_label("%d" % game.game_match.scores["attack"], 28, C_ORANGE_SOFT, font_display))
	score.add_child(_label("  :  ", 14, C_DIM))
	score.add_child(_label("%d" % game.game_match.scores["defense"], 28, C_CYAN_SOFT, font_display))
	rows.add_child(score)
	var data: Array = game.game_match.get_scoreboard()
	for team in ["attack", "defense"]:
		var label = _label(GameConfig.TEAM[team]["label"] + "  /  " + GameConfig.TEAM[team]["short"], 9, GameConfig.TEAM[team]["color"], font_display)
		rows.add_child(label)
		var grid = GridContainer.new(); grid.columns = 5
		grid.add_theme_constant_override("h_separation", 20)
		for h in ["干员", "击杀", "死亡", "爆头", "状态"]:
			var hl = _label(h, 8, C_DIM)
			hl.custom_minimum_size = Vector2(390, 0) if h == "干员" else Vector2(56, 0)
			hl.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT if h == "干员" else HORIZONTAL_ALIGNMENT_RIGHT
			grid.add_child(hl)
		for row in data:
			if row["team"] != team:
				continue
			var nl = _label(("★ " if row["is_player"] else "") + row["name"], 10, C_ORANGE_SOFT if row["is_player"] else C_TEXT)
			nl.custom_minimum_size = Vector2(390, 0)
			grid.add_child(nl)
			for value in [str(row["kills"]), str(row["deaths"]), str(row["headshots"])]:
				var cell = _label(value, 10, C_MUTED)
				cell.custom_minimum_size = Vector2(56, 0)
				cell.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
				grid.add_child(cell)
			var state = _label("ACTIVE" if row["alive"] else "DOWN", 9, C_DIM if row["alive"] else C_RED)
			state.custom_minimum_size = Vector2(56, 0)
			state.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
			grid.add_child(state)
		rows.add_child(grid)
		var line = ColorRect.new(); line.color = C_LINE; line.custom_minimum_size = Vector2(0, 1); rows.add_child(line)

func _build_manual() -> void:
	manual_layer = Control.new()
	manual_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	manual_layer.visible = false
	root.add_child(manual_layer)
	var dim = ColorRect.new(); dim.color = Color(0.01, 0.02, 0.025, 0.78); dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); manual_layer.add_child(dim)
	var panel = _panel(_style(Color(0.031, 0.047, 0.059, 0.99), C_LINE, 1, 2, 20))
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.position = Vector2(-390, -280)
	panel.custom_minimum_size = Vector2(780, 560)
	manual_layer.add_child(panel)
	var v = VBoxContainer.new(); v.add_theme_constant_override("separation", 10); panel.add_child(v)
	var head = HBoxContainer.new()
	var hb = VBoxContainer.new(); hb.add_child(_label("FIELD MANUAL / 01", 8, C_ORANGE_SOFT, font_display)); hb.add_child(_label("作战手册", 24, C_TEXT)); head.add_child(hb)
	var sp = Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; head.add_child(sp)
	var close = _make_button("×", 16); close.custom_minimum_size = Vector2(34, 34); close.pressed.connect(func(): hide_manual()); head.add_child(close)
	v.add_child(head)
	var scroll = ScrollContainer.new(); scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL; v.add_child(scroll)
	var text = RichTextLabel.new(); text.bbcode_enabled = true; text.fit_content = true; text.custom_minimum_size = Vector2(710, 0); text.add_theme_font_size_override("normal_font_size", 10); text.add_theme_color_override("default_color", C_MUTED); text.mouse_filter = Control.MOUSE_FILTER_PASS
	text.text = """[color=#e8dfcf][b]01  行动目标[/b][/color]
进攻方需在 A / B 包点安放黑匣炸弹，或消灭全部防守方；防守方需拆除炸弹、阻止安放，或拖满回合时间。
[color=#ff925f]安放时长[/color]  10 秒        [color=#ff925f]引爆倒计时[/color]  40 秒
[color=#8ce8ff]拆除时长[/color]  10 秒        [color=#8ce8ff]拆弹器[/color]  5 秒

[color=#e8dfcf][b]02  操作键位[/b][/color]
[color=#ff925f]W A S D[/color]  移动        [color=#ff925f]Shift[/color]  冲刺        [color=#ff925f]Ctrl[/color]  蹲伏
[color=#ff925f]鼠标左键[/color]  射击        [color=#ff925f]鼠标右键[/color]  瞄准        [color=#ff925f]Space[/color]  跳跃
[color=#ff925f]R[/color]  换弹        [color=#ff925f]E[/color]  交互        [color=#ff925f]1 / 2[/color]  切换武器
[color=#ff925f]B[/color]  军械库        [color=#ff925f]Tab[/color]  计分板        [color=#ff925f]Esc[/color]  暂停

[color=#e8dfcf][b]03  经济与改装[/b][/color]
每回合获得 10,000 信用点，购买主武器、护甲、拆弹器与弹药。所有枪械配件免费，可在军械库中随时调整。
击倒敌人会掉落装备，靠近后按 E 回收，换取额外信用点。

[color=#e8dfcf][b]04  胜负与换边[/b][/color]
先取得 6 个回合胜利的队伍赢得比赛。第 6 回合结束后双方交换攻防，比赛最多进行 11 回合。
枪械有后坐力与散布。短点射、站稳再开火，比按住左键更有效。"""
	scroll.add_child(text)
	var footer = HBoxContainer.new(); footer.add_child(_label("本地 5V5 模拟 · BOT 会执行安放、拆除与架点", 8, C_DIM)); var fsp = Control.new(); fsp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; footer.add_child(fsp); var ok = _make_button("返回", 11); ok.pressed.connect(func(): hide_manual()); footer.add_child(ok); v.add_child(footer)

func show_manual(from_pause = false) -> void:
	_manual_from_pause = from_pause
	manual_layer.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func hide_manual() -> void:
	manual_layer.visible = false
	if game.state == "playing" and game.game_match and game.game_match.phase == "live" and not buy_open and not pause_layer.visible:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _build_settings() -> void:
	settings_layer = Control.new()
	settings_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	settings_layer.visible = false
	root.add_child(settings_layer)
	var dim = ColorRect.new(); dim.color = Color(0.01, 0.02, 0.025, 0.78); dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); settings_layer.add_child(dim)
	var panel = _panel(_style(Color(0.031, 0.047, 0.059, 0.99), C_LINE, 1, 2, 24))
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.position = Vector2(-260, -210)
	panel.custom_minimum_size = Vector2(520, 420)
	settings_layer.add_child(panel)
	var v = VBoxContainer.new(); v.add_theme_constant_override("separation", 12); panel.add_child(v)
	var head = HBoxContainer.new()
	var hb = VBoxContainer.new(); hb.add_child(_label("SYSTEM / CONFIG", 8, C_ORANGE_SOFT, font_display)); hb.add_child(_label("设置", 24, C_TEXT)); head.add_child(hb)
	var sp = Control.new(); sp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; head.add_child(sp)
	var close = _make_button("×", 16); close.custom_minimum_size = Vector2(34, 34); close.pressed.connect(func(): hide_settings()); head.add_child(close)
	v.add_child(head)
	v.add_child(_setting_row("鼠标灵敏度", "MOUSE SENSITIVITY", 0.4, 2.2, 0.05, game.settings["sensitivity"], func(value): game.settings["sensitivity"] = value; game.save_settings()))
	v.add_child(_setting_row("主音量", "MASTER VOLUME", 0.0, 1.0, 0.05, game.settings["volume"], func(value): game.settings["volume"] = value; game.audio.set_volume(value); game.save_settings()))
	v.add_child(_setting_row("视野范围", "FIELD OF VIEW", 65.0, 95.0, 1.0, game.settings["fov"], func(value): game.settings["fov"] = value; game.save_settings()))
	var footer = HBoxContainer.new(); footer.add_child(_label("设置自动保存在本地", 8, C_DIM)); var fsp = Control.new(); fsp.size_flags_horizontal = Control.SIZE_EXPAND_FILL; footer.add_child(fsp); var ok = _make_button("完成", 11); ok.pressed.connect(func(): hide_settings()); footer.add_child(ok); v.add_child(footer)

func _setting_row(label_text: String, en: String, minv: float, maxv: float, step: float, value: float, on_change: Callable) -> Control:
	var h = HBoxContainer.new()
	h.add_theme_constant_override("separation", 14)
	var lb = VBoxContainer.new(); lb.custom_minimum_size = Vector2(205, 0); lb.add_child(_label(label_text, 10, C_MUTED)); lb.add_child(_label(en, 7, C_DIM, font_display)); h.add_child(lb)
	var slider = HSlider.new(); slider.min_value = minv; slider.max_value = maxv; slider.step = step; slider.value = value; slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL; slider.custom_minimum_size = Vector2(160, 20)
	var out = _label("%.2f" % value if step < 0.1 else str(roundi(value)), 9, C_ORANGE_SOFT, font_display)
	out.custom_minimum_size = Vector2(48, 0); out.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	slider.value_changed.connect(func(val):
		out.text = "%.2f" % val if step < 0.1 else str(roundi(val))
		on_change.call(val))
	h.add_child(slider); h.add_child(out)
	return h

func show_settings(from_pause = false) -> void:
	settings_layer.visible = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func hide_settings() -> void:
	settings_layer.visible = false
	if game.state == "playing" and game.game_match and game.game_match.phase == "live" and not buy_open and not pause_layer.visible:
		Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _build_end() -> void:
	end_layer = Control.new()
	end_layer.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	end_layer.visible = false
	root.add_child(end_layer)
	var dim = ColorRect.new(); dim.color = Color(0.01, 0.02, 0.025, 0.82); dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT); end_layer.add_child(dim)
	var panel = _panel(_style(Color(0.031, 0.047, 0.059, 0.99), C_LINE, 1, 2, 26))
	panel.set_anchors_preset(Control.PRESET_CENTER)
	panel.position = Vector2(-270, -245)
	panel.custom_minimum_size = Vector2(540, 490)
	end_layer.add_child(panel)
	var v = VBoxContainer.new(); v.add_theme_constant_override("separation", 8); v.alignment = BoxContainer.ALIGNMENT_CENTER; panel.add_child(v)
	var kicker = _label("OPERATION COMPLETE", 9, C_ORANGE_SOFT, font_display); kicker.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; kicker.name = "Kicker"; v.add_child(kicker)
	var title = _label("行动成功", 44, C_TEXT); title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; title.name = "Title"; v.add_child(title)
	var sub = _label("你的小队控制了零点电站。", 10, C_MUTED); sub.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; sub.name = "Sub"; v.add_child(sub)
	var score = HBoxContainer.new(); score.alignment = BoxContainer.ALIGNMENT_CENTER; score.name = "Score"; score.add_theme_constant_override("separation", 18); v.add_child(score)
	var stats = HBoxContainer.new(); stats.alignment = BoxContainer.ALIGNMENT_CENTER; stats.name = "Stats"; stats.add_theme_constant_override("separation", 18); v.add_child(stats)
	var spacer = Control.new(); spacer.custom_minimum_size = Vector2(0, 8); v.add_child(spacer)
	var again = _make_button("再次部署   →", 15, true); again.custom_minimum_size = Vector2(0, 48); again.pressed.connect(func(): game.start_match(menu_side)); v.add_child(again)
	var menu = _make_button("返回主菜单", 12); menu.pressed.connect(func(): game.return_to_menu()); v.add_child(menu)

# ============================================================
# Runtime API
# ============================================================
func show_menu() -> void:
	menu_layer.visible = true
	hud_layer.visible = false
	buy_layer.visible = false
	pause_layer.visible = false
	scoreboard_layer.visible = false
	manual_layer.visible = false
	settings_layer.visible = false
	end_layer.visible = false
	buy_open = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func show_hud() -> void:
	menu_layer.visible = false
	hud_layer.visible = true

func reset_match(match) -> void:
	menu_layer.visible = false
	hud_layer.visible = true
	buy_layer.visible = false
	pause_layer.visible = false
	scoreboard_layer.visible = false
	end_layer.visible = false
	manual_layer.visible = false
	settings_layer.visible = false
	buy_open = false
	kill_feed_clear()
	planted_alert.visible = false
	spectate_panel.visible = false
	damage_overlay.color.a = 0.0
	round_number_label.text = "01"
	score_attack.text = "0"; score_defense.text = "0"
	alive_attack.text = "5"; alive_defense.text = "5"
	for c in dots_attack.get_children(): (c as ColorRect).color = Color(1, 1, 1, 0.08)
	for c in dots_defense.get_children(): (c as ColorRect).color = Color(1, 1, 1, 0.08)
	fps_label.visible = true
	crosshair.visible = true
	weapon_panel.modulate.a = 1.0
	interaction_panel.visible = false
	banner.modulate.a = 0.0

func update_round(number: int) -> void:
	round_number_label.text = "%02d" % number

func update_score(scores: Dictionary) -> void:
	score_attack.text = str(scores["attack"])
	score_defense.text = str(scores["defense"])
	for i in dots_attack.get_child_count():
		(dots_attack.get_child(i) as ColorRect).color = C_ORANGE if i < int(scores["attack"]) else Color(1, 1, 1, 0.08)
	for i in dots_defense.get_child_count():
		(dots_defense.get_child(i) as ColorRect).color = C_CYAN if i < int(scores["defense"]) else Color(1, 1, 1, 0.08)

func update_alive(attack: int, defense: int) -> void:
	alive_attack.text = str(attack)
	alive_defense.text = str(defense)

func update_clock(data: Dictionary) -> void:
	var phase: String = data["phase"]
	var bomb_remaining = data.get("bomb_remaining", null)
	var text = ""
	var phase_label = ""
	if phase == "buy":
		text = _clock_label(float(data["phase_time"]))
		phase_label = "购买阶段"
		buy_clock_label.text = text
	elif phase == "planted":
		text = "%.1f" % float(bomb_remaining)
		phase_label = "黑匣已激活"
	else:
		text = _clock_label(float(data["round_time"]))
		phase_label = "行动阶段"
	round_timer.text = text
	round_phase.text = phase_label
	round_timer.add_theme_color_override("font_color", C_ORANGE if phase == "planted" and float(bomb_remaining) < 10.0 else C_SAND)
	bomb_clock.text = "%.1f" % float(bomb_remaining) if bomb_remaining != null else ""
	bomb_clock.visible = bomb_remaining != null

func set_objective(text: String) -> void:
	objective_label.text = text

func set_interaction(data) -> void:
	if data == null:
		interaction_panel.visible = false
		return
	interaction_panel.visible = true
	interaction_label.text = String(data.get("label", ""))
	interaction_time.text = String(data.get("time", ""))
	interaction_bar.value = float(data.get("progress", 0.0))
	var tone: String = data.get("tone", "plant")
	var col = C_ORANGE
	if tone == "defuse":
		col = C_CYAN
	elif tone == "pickup":
		col = C_GREEN
	interaction_panel.add_theme_stylebox_override("panel", _style(Color(0.024, 0.04, 0.05, 0.92), col, 1, 0, 9))
	interaction_bar.add_theme_stylebox_override("fill", _style(col, Color.TRANSPARENT, 0, 0, 0))

func set_interaction_progress(progress: float, label: String) -> void:
	interaction_panel.visible = true
	interaction_bar.value = clampf(progress, 0.0, 1.0)
	if label != "":
		interaction_label.text = label

func update_vitals(player: Player) -> void:
	health_label.text = str(roundi(player.health))
	armor_label.text = str(roundi(player.armor))
	health_bar.value = player.health
	armor_bar.value = player.armor
	money_label.text = _fmt_int(player.money)
	operator_side.text = GameConfig.TEAM[player.team]["short"]
	operator_side.add_theme_color_override("font_color", GameConfig.TEAM[player.team]["color"])
	kit_label.text = ("拆弹器已装备" if player.kit else "无拆弹器") if player.team == "defense" else "进攻方"
	carry_label.visible = player.bomb_carried

func update_weapon(player: Player) -> void:
	var state = player.weapons.get(player.current_slot, null)
	if state == null:
		return
	var def: Dictionary = state["def"]
	weapon_class.text = def["class_label"]
	weapon_name.text = def["name"]
	update_ammo(player)
	slot_primary.visible = player.weapons["primary"] != null
	slot_secondary.visible = player.weapons["secondary"] != null
	slot_knife.visible = true
	for i in [slot_primary, slot_secondary, slot_knife]:
		i.add_theme_color_override("font_color", C_DIM)
	if player.current_slot == "primary" and player.weapons["primary"]:
		slot_primary.add_theme_color_override("font_color", C_ORANGE_SOFT)
	elif player.current_slot == "secondary":
		slot_secondary.add_theme_color_override("font_color", C_ORANGE_SOFT)
	elif player.current_slot == "knife":
		slot_knife.add_theme_color_override("font_color", C_ORANGE_SOFT)

func update_ammo(player: Player) -> void:
	var state = player.weapons.get(player.current_slot, null)
	if state == null:
		return
	var current_def: Dictionary = state["def"]
	weapon_class.text = current_def.get("class_label", "武器")
	weapon_name.text = current_def.get("name", "")
	weapon_mode.text = current_def.get("mode_label", "")
	if player.current_slot == "knife":
		ammo_mag.text = "∞"
		ammo_reserve.visible = false
		ammo_sep.visible = false
		reload_hint.visible = false
		return
	ammo_reserve.visible = true
	ammo_sep.visible = true
	ammo_mag.text = "%02d" % int(state["ammo"])
	ammo_reserve.text = "%02d" % int(state["reserve"])
	reload_hint.visible = player.reload_timer > 0.0 or (int(state["ammo"]) == 0 and int(state["reserve"]) > 0)
	if player.reload_timer > 0.0:
		reload_hint.text = "换弹中… %.1fs" % player.reload_timer
	else:
		reload_hint.text = "R 换弹"

func pulse_crosshair(amount: float) -> void:
	crosshair.set_spread(7.0 + amount * 10.0)
	var t = create_tween()
	t.tween_interval(0.08)
	t.tween_callback(func(): crosshair.set_spread(6.0))

func show_hitmarker(headshot = false, kill = false) -> void:
	crosshair.flash_hit(kill or headshot)

func on_player_damaged(amount: int, headshot: bool, attacker) -> void:
	damage_overlay.color.a = clampf(0.28 + amount / 100.0, 0.28, 0.8)
	var t = create_tween()
	t.tween_property(damage_overlay, "color:a", 0.0, 0.45)
	update_vitals(game.player)

func add_kill_feed(data: Dictionary) -> void:
	var label = RichTextLabel.new()
	label.bbcode_enabled = true
	label.fit_content = true
	label.scroll_active = false
	label.custom_minimum_size = Vector2(292, 22)
	label.add_theme_font_size_override("normal_font_size", 9)
	label.add_theme_color_override("default_color", C_MUTED)
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var kc: Color = GameConfig.TEAM[data["killer_team"]]["soft"]
	var vc: Color = GameConfig.TEAM[data["victim_team"]]["soft"]
	label.text = "[color=#%s]%s[/color]  [color=#6b7a82]%s[/color]  →  [color=#%s]%s[/color]%s" % [
		kc.to_html(false), data["killer_name"], data["weapon"], vc.to_html(false), data["victim_name"],
		"  [color=#ff6b2c]◉[/color]" if data.get("headshot", false) else ""
	]
	kill_feed.add_child(label)
	while kill_feed.get_child_count() > 5:
		kill_feed.get_child(0).queue_free()
	var t = create_tween()
	t.tween_interval(5.4)
	t.tween_property(label, "modulate:a", 0.0, 0.3)
	t.tween_callback(label.queue_free)

func kill_feed_clear() -> void:
	for c in kill_feed.get_children():
		c.queue_free()

func show_banner(kicker: String, title: String, sub: String, duration = 2.4) -> void:
	banner_kicker.text = kicker
	banner_title.text = title
	banner_sub.text = sub
	if banner_tween and banner_tween.is_valid():
		banner_tween.kill()
	banner.modulate.a = 0.0
	banner.position.y = -160
	banner_tween = create_tween()
	banner_tween.set_parallel(true)
	banner_tween.tween_property(banner, "modulate:a", 1.0, 0.25)
	banner_tween.tween_property(banner, "position:y", -170, 0.3).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	banner_tween.chain().tween_interval(duration)
	banner_tween.chain().tween_property(banner, "modulate:a", 0.0, 0.3)

func show_round_result(data: Dictionary) -> void:
	var winner_label: String = "进攻方" if data["winner"] == "attack" else "防守方"
	show_banner("ROUND %02d · %s获胜" % [data["round_number"], winner_label], "回合胜利" if data["player_won"] else "回合失败", "%s  ·  %d : %d" % [data["reason"], data["scores"]["attack"], data["scores"]["defense"]], 4.8)
	planted_alert.visible = false

func show_planted_alert(show: bool) -> void:
	planted_alert.visible = show

func set_dead(dead: bool) -> void:
	crosshair.visible = not dead
	weapon_panel.modulate.a = 0.5 if dead else 1.0
	vitals_panel.modulate.a = 0.65 if dead else 1.0

func show_spectate(show: bool) -> void:
	spectate_panel.visible = show
	if show:
		crosshair.visible = false

func toast(text: String, tone = "info") -> void:
	var panel = _panel(_style(Color(0.024, 0.04, 0.05, 0.92), C_ORANGE if tone == "info" else (C_GREEN if tone == "success" else C_RED), 1, 0, 8))
	panel.custom_minimum_size = Vector2(300, 30)
	var l = _label(text, 9, C_MUTED)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	panel.add_child(l)
	if toast_box == null:
		toast_box = VBoxContainer.new()
		toast_box.set_anchors_preset(Control.PRESET_CENTER_BOTTOM)
		toast_box.position = Vector2(-150, -170)
		toast_box.custom_minimum_size = Vector2(300, 0)
		toast_box.add_theme_constant_override("separation", 5)
		toast_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
		root.add_child(toast_box)
	toast_box.add_child(panel)
	while toast_box.get_child_count() > 4:
		toast_box.get_child(0).queue_free()
	var t = create_tween()
	t.tween_interval(2.8)
	t.tween_property(panel, "modulate:a", 0.0, 0.3)
	t.tween_callback(panel.queue_free)

func set_fps(value: int) -> void:
	fps_label.text = "%d FPS" % value

func show_match_end(data: Dictionary) -> void:
	show_hud()
	_show_end_texts(data)
	end_layer.visible = true
	hud_layer.visible = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func _show_end_texts(data: Dictionary) -> void:
	# 使用递归查找，避免依赖节点路径变更。
	var kicker: Label = _find_label(end_layer, "Kicker")
	var title: Label = _find_label(end_layer, "Title")
	var sub: Label = _find_label(end_layer, "Sub")
	if kicker: kicker.text = "OPERATION COMPLETE" if data["player_won"] else "OPERATION FAILED"
	if title: title.text = "行动成功" if data["player_won"] else "行动失败"
	if sub: sub.text = "你的小队控制了零点电站。" if data["player_won"] else "零点电站失守。调整配装，再次部署。"
	var score: HBoxContainer = _find_container(end_layer, "Score")
	if score:
		for c in score.get_children(): c.queue_free()
		score.add_child(_label(str(data["scores"]["attack"]), 40, C_ORANGE_SOFT, font_display))
		score.add_child(_label(":", 20, C_DIM, font_display))
		score.add_child(_label(str(data["scores"]["defense"]), 40, C_CYAN_SOFT, font_display))
	var stats: HBoxContainer = _find_container(end_layer, "Stats")
	if stats:
		for c in stats.get_children(): c.queue_free()
		for row in [["击杀", data["stats"]["kills"]], ["死亡", data["stats"]["deaths"]], ["爆头", data["stats"]["headshots"]], ["安放/拆除", "%d / %d" % [data["stats"]["plants"], data["stats"]["defuses"]]]]:
			var box = VBoxContainer.new()
			var l = _label(row[0], 8, C_DIM); l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; box.add_child(l)
			var v = _label(str(row[1]), 20, C_SAND, font_display); v.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER; box.add_child(v)
			stats.add_child(box)

func _find_label(node: Node, target_name: String) -> Label:
	if node is Label and node.name == target_name:
		return node
	for child in node.get_children():
		var found = _find_label(child, target_name)
		if found: return found
	return null

func _find_container(node: Node, target_name: String) -> HBoxContainer:
	if node is HBoxContainer and node.name == target_name:
		return node
	for child in node.get_children():
		var found = _find_container(child, target_name)
		if found: return found
	return null

func _clock_label(seconds: float) -> String:
	var s = maxi(0, int(ceil(seconds)))
	return "%d:%02d" % [s / 60, s % 60]

func _fmt_int(value: int) -> String:
	var s = str(value)
	var out = ""
	var count = 0
	for i in range(s.length() - 1, -1, -1):
		out = s.substr(i, 1) + out
		count += 1
		if count % 3 == 0 and i > 0:
			out = "," + out
	return out


