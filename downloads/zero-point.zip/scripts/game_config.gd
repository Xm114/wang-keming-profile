class_name GameConfig
extends RefCounted

## 零点交火 — 全局规则、武器与经济数据。
## 改这一个文件即可调整整局节奏与枪械数值。

const MATCH = {
	"team_size": 5,
	"rounds_to_win": 6,
	"max_rounds": 11,
	"switch_sides_after": 6,
	"buy_time": 10.0,
	"round_time": 90.0,
	"round_end_delay": 5.4,
	"plant_time": 10.0,
	"defuse_time": 10.0,
	"defuse_kit_time": 5.0,
	"bomb_time": 40.0,
	"bomb_pickup_range": 2.25,
	"plant_range": 4.15,
	"defuse_range": 2.35,
	"start_credits": 10000,
	"kill_reward": 250,
	"plant_reward": 300,
	"defuse_reward": 300,
	"pickup_min": 380,
	"pickup_max": 920,
	"kill_feed_time": 5.4,
}

const ECONOMY = {
	"armor_price": 2000,
	"kit_price": 600,
	"ammo_price": 400,
	"armor_value": 100,
	"ammo_bonus": 60,
}

const TEAM = {
	"attack": {
		"label": "进攻方",
		"short": "ATK",
		"color": Color("#ff6b2c"),
		"soft": Color("#ff925f"),
	},
	"defense": {
		"label": "防守方",
		"short": "DEF",
		"color": Color("#42d8ff"),
		"soft": Color("#8ce8ff"),
	},
}

const WEAPONS = {
	"ar21": {
		"name": "AR-21「熔火」",
		"short": "AR-21",
		"class_label": "突击步枪",
		"mode_label": "全自动",
		"slot": "primary",
		"price": 3200,
		"damage": 28.0,
		"head_multiplier": 2.55,
		"pellets": 1,
		"rpm": 640.0,
		"auto": true,
		"mag": 30,
		"reserve": 120,
		"reload": 2.15,
		"spread_hip": 0.0115,
		"spread_ads": 0.0028,
		"moving_spread": 0.014,
		"recoil": 0.88,
		"recoil_horizontal": 0.42,
		"range": 90.0,
		"falloff_start": 34.0,
		"falloff_end": 90.0,
		"ads_fov": 54.0,
		"draw_time": 0.48,
		"accent": Color("#c2c8ca"),
	},
	"smg9": {
		"name": "SMG-9「蜂群」",
		"short": "SMG-9",
		"class_label": "冲锋枪",
		"mode_label": "全自动",
		"slot": "primary",
		"price": 2300,
		"damage": 22.0,
		"head_multiplier": 2.2,
		"pellets": 1,
		"rpm": 900.0,
		"auto": true,
		"mag": 32,
		"reserve": 128,
		"reload": 1.75,
		"spread_hip": 0.017,
		"spread_ads": 0.0052,
		"moving_spread": 0.009,
		"recoil": 0.62,
		"recoil_horizontal": 0.55,
		"range": 58.0,
		"falloff_start": 20.0,
		"falloff_end": 58.0,
		"ads_fov": 58.0,
		"draw_time": 0.38,
		"accent": Color("#9ea6a9"),
	},
	"dmr7": {
		"name": "DMR-7「远望」",
		"short": "DMR-7",
		"class_label": "精确射手步枪",
		"mode_label": "半自动",
		"slot": "primary",
		"price": 4300,
		"damage": 54.0,
		"head_multiplier": 2.6,
		"pellets": 1,
		"rpm": 230.0,
		"auto": false,
		"mag": 10,
		"reserve": 40,
		"reload": 2.55,
		"spread_hip": 0.006,
		"spread_ads": 0.0011,
		"moving_spread": 0.02,
		"recoil": 1.75,
		"recoil_horizontal": 0.32,
		"range": 140.0,
		"falloff_start": 55.0,
		"falloff_end": 140.0,
		"ads_fov": 38.0,
		"draw_time": 0.56,
		"accent": Color("#b6a88e"),
	},
	"sg12": {
		"name": "SG-12「破门」",
		"short": "SG-12",
		"class_label": "战术霰弹枪",
		"mode_label": "泵动",
		"slot": "primary",
		"price": 2600,
		"damage": 13.0,
		"head_multiplier": 1.5,
		"pellets": 8,
		"rpm": 82.0,
		"auto": false,
		"mag": 7,
		"reserve": 28,
		"reload": 2.9,
		"spread_hip": 0.061,
		"spread_ads": 0.044,
		"moving_spread": 0.004,
		"recoil": 2.1,
		"recoil_horizontal": 0.6,
		"range": 30.0,
		"falloff_start": 9.0,
		"falloff_end": 30.0,
		"ads_fov": 62.0,
		"draw_time": 0.55,
		"accent": Color("#7d8589"),
	},
	"p9": {
		"name": "P9「短哨」",
		"short": "P9",
		"class_label": "制式手枪",
		"mode_label": "半自动",
		"slot": "secondary",
		"price": 0,
		"damage": 26.0,
		"head_multiplier": 2.45,
		"pellets": 1,
		"rpm": 390.0,
		"auto": false,
		"mag": 15,
		"reserve": 60,
		"reload": 1.45,
		"spread_hip": 0.014,
		"spread_ads": 0.004,
		"moving_spread": 0.012,
		"recoil": 0.68,
		"recoil_horizontal": 0.34,
		"range": 52.0,
		"falloff_start": 16.0,
		"falloff_end": 52.0,
		"ads_fov": 62.0,
		"draw_time": 0.3,
		"accent": Color("#aab0b0"),
	},
	"r6": {
		"name": "R6「铆钉」",
		"short": "R6",
		"class_label": "大口径左轮",
		"mode_label": "半自动",
		"slot": "secondary",
		"price": 900,
		"damage": 48.0,
		"head_multiplier": 2.7,
		"pellets": 1,
		"rpm": 190.0,
		"auto": false,
		"mag": 6,
		"reserve": 30,
		"reload": 2.25,
		"spread_hip": 0.017,
		"spread_ads": 0.005,
		"moving_spread": 0.018,
		"recoil": 1.55,
		"recoil_horizontal": 0.48,
		"range": 64.0,
		"falloff_start": 24.0,
		"falloff_end": 64.0,
		"ads_fov": 60.0,
		"draw_time": 0.42,
		"accent": Color("#c4b08a"),
	},
}

const KNIVES = {
	"tactical": {
		"name": "经典匕首",
		"short": "经典",
		"class_label": "近战武器",
		"mode_label": "快速挥砍",
		"slot": "knife",
		"damage": 58.0,
		"backstab": 3.0,
		"range": 1.8,
		"rate": 1.25,
		"draw_time": 0.28,
		"ads_fov": 78.0,
		"desc": "CS 经典匕首：均衡、干净，正面与背刺都可靠。",
	},
	"butterfly": {
		"name": "蝴蝶刀",
		"short": "蝴蝶",
		"class_label": "近战武器",
		"mode_label": "甩刀连斩",
		"slot": "knife",
		"damage": 50.0,
		"backstab": 3.1,
		"range": 1.72,
		"rate": 1.5,
		"draw_time": 0.34,
		"ads_fov": 78.0,
		"desc": "双柄甩刀，出刀花哨且极快，贴身连续挥砍。",
	},
	"karambit": {
		"name": "爪子刀",
		"short": "爪刀",
		"class_label": "近战武器",
		"mode_label": "连续勾斩",
		"slot": "knife",
		"damage": 46.0,
		"backstab": 3.25,
		"range": 1.58,
		"rate": 1.6,
		"draw_time": 0.22,
		"ads_fov": 78.0,
		"desc": "CS 爪子刀：极快的勾斩，背刺致命。",
	},
	"bayonet": {
		"name": "刺刀",
		"short": "刺刀",
		"class_label": "近战武器",
		"mode_label": "突刺",
		"slot": "knife",
		"damage": 72.0,
		"backstab": 2.5,
		"range": 2.05,
		"rate": 0.9,
		"draw_time": 0.4,
		"ads_fov": 78.0,
		"desc": "更长的刀身与突刺距离，正面伤害最高，但出刀慢。",
	},
	"flip": {
		"name": "折叠刀",
		"short": "折叠",
		"class_label": "近战武器",
		"mode_label": "快速翻刀",
		"slot": "knife",
		"damage": 48.0,
		"backstab": 3.1,
		"range": 1.65,
		"rate": 1.45,
		"draw_time": 0.26,
		"ads_fov": 78.0,
		"desc": "CS 折叠刀：轻巧、收刀快，适合游走与背刺。",
	},
}

const KNIFE_ORDER = ["tactical", "butterfly", "karambit", "bayonet", "flip"]

const PRIMARY_WEAPONS = ["ar21", "smg9", "dmr7", "sg12"]
const SECONDARY_WEAPONS = ["p9", "r6"]
const WEAPON_ORDER = ["ar21", "smg9", "dmr7", "sg12", "p9", "r6"]

const ATTACHMENT_GROUPS = [
	{
		"id": "optic",
		"label": "瞄具",
		"en": "OPTIC",
		"options": [
			{"id": "iron", "label": "机械瞄具", "en": "IRON", "mods": {"ads_time": -0.015}, "note": "最快开镜"},
			{"id": "reflex", "label": "反射红点", "en": "REFLEX", "mods": {"spread_ads": -0.0005, "ads_time": 0.012}, "note": "视野清晰"},
			{"id": "scope2", "label": "2× 战术镜", "en": "2X", "mods": {"spread_ads": -0.0011, "range": 18.0, "ads_fov": -12.0, "ads_time": 0.045}, "note": "远点架枪"},
		],
	},
	{
		"id": "barrel",
		"label": "枪管",
		"en": "BARREL",
		"options": [
			{"id": "standard", "label": "标准枪管", "en": "STD", "mods": {}, "note": "均衡"},
			{"id": "long", "label": "加长枪管", "en": "LONG", "mods": {"range": 24.0, "spread_ads": -0.0007, "ads_time": 0.035}, "note": "提升射程"},
			{"id": "compact", "label": "短枪管", "en": "CQB", "mods": {"range": -10.0, "spread_hip": 0.0015, "ads_time": -0.03, "recoil_horizontal": 0.08}, "note": "近战提速"},
		],
	},
	{
		"id": "grip",
		"label": "握把",
		"en": "GRIP",
		"options": [
			{"id": "standard", "label": "标准握把", "en": "STD", "mods": {}, "note": "均衡"},
			{"id": "vertical", "label": "垂直握把", "en": "VERT", "mods": {"recoil": -0.16, "spread_ads": -0.0003}, "note": "压枪更稳"},
			{"id": "angled", "label": "轻型握把", "en": "LIGHT", "mods": {"recoil": -0.08, "ads_time": -0.02, "moving_spread": -0.001}, "note": "快速开镜"},
		],
	},
	{
		"id": "mag",
		"label": "弹匣",
		"en": "MAG",
		"options": [
			{"id": "standard", "label": "标准弹匣", "en": "STD", "mods": {}, "note": "均衡"},
			{"id": "extended", "label": "扩容弹匣", "en": "EXT", "mods": {"mag": 10, "reload": 0.22}, "note": "持续火力"},
			{"id": "quick", "label": "快拔弹匣", "en": "QUICK", "mods": {"mag": -3, "reload": -0.28}, "note": "快速换弹"},
		],
	},
]

const DEFAULT_ATTACHMENTS = {
	"ar21": {"optic": "reflex", "barrel": "standard", "grip": "vertical", "mag": "standard"},
	"smg9": {"optic": "reflex", "barrel": "compact", "grip": "angled", "mag": "standard"},
	"dmr7": {"optic": "scope2", "barrel": "long", "grip": "vertical", "mag": "standard"},
	"sg12": {"optic": "iron", "barrel": "compact", "grip": "angled", "mag": "standard"},
	"p9": {"optic": "iron", "barrel": "standard", "grip": "standard", "mag": "standard"},
	"r6": {"optic": "iron", "barrel": "standard", "grip": "standard", "mag": "standard"},
}

const BOT_NAMES_ATTACK = ["渡鸦", "赤潮", "断线", "灰烬", "钨丝"]
const BOT_NAMES_DEFENSE = ["霜刃", "静默", "回声", "铁幕", "磷光"]
const BOT_WEAPONS_ATTACK = ["ar21", "smg9", "ar21", "dmr7", "sg12"]
const BOT_WEAPONS_DEFENSE = ["ar21", "dmr7", "smg9", "ar21", "sg12"]

static func other_team(team: String) -> String:
	return "defense" if team == "attack" else "attack"

static func resolve_weapon(id: String, attachments: Dictionary = {}) -> Dictionary:
	var base: Dictionary = WEAPONS.get(id, WEAPONS["ar21"]).duplicate(true)
	var applied: Dictionary = (DEFAULT_ATTACHMENTS.get(id, {}) as Dictionary).duplicate()
	applied.merge(attachments, true)
	base["attachments"] = applied
	base["ads_time"] = base.get("ads_time", 0.2)
	for group in ATTACHMENT_GROUPS:
		var chosen: String = applied.get(group["id"], group["options"][0]["id"])
		var option: Dictionary = group["options"][0]
		for candidate in group["options"]:
			if candidate["id"] == chosen:
				option = candidate
				break
		var mods: Dictionary = option.get("mods", {})
		for key in mods.keys():
			base[key] = float(base.get(key, 0.0)) + float(mods[key])
	base["mag"] = maxi(1, int(round(float(base["mag"]))))
	base["spread_hip"] = maxf(0.0005, float(base["spread_hip"]))
	base["spread_ads"] = maxf(0.0002, float(base["spread_ads"]))
	base["recoil"] = maxf(0.1, float(base["recoil"]))
	base["ads_fov"] = clampf(float(base.get("ads_fov", 54.0)), 25.0, 75.0)
	return base

static func resolve_knife(id: String) -> Dictionary:
	var base: Dictionary = KNIVES.get(id, KNIVES["tactical"]).duplicate(true)
	base["id"] = id if KNIVES.has(id) else "tactical"
	base["auto"] = false
	base["mag"] = 1
	base["reserve"] = 0
	base["reload"] = 0.0
	base["spread_hip"] = 0.0
	base["spread_ads"] = 0.0
	base["moving_spread"] = 0.0
	base["recoil"] = 0.0
	return base

static func weapon_bars(def: Dictionary) -> Dictionary:
	return {
		"damage": clampf(float(def.get("damage", 20.0)) / 60.0, 0.0, 1.0),
		"control": clampf(1.25 - float(def.get("recoil", 1.0)) / 2.4, 0.0, 1.0),
		"range": clampf(float(def.get("range", 50.0)) / 140.0, 0.0, 1.0),
		"mobility": clampf(1.15 - float(def.get("reload", 2.0)) / 4.0, 0.0, 1.0),
	}
