class_name AudioBus
extends Node

## 程序化占位音效。所有声音在启动时合成，不依赖外部素材。
## 后续替换真实音频时，把流加载进 _streams 即可。

const RATE = 22050
var _players: Array[AudioStreamPlayer] = []
var _next = 0
var _streams = {}
var master_volume = 0.65

func _ready() -> void:
	for i in 18:
		var player = AudioStreamPlayer.new()
		player.bus = "Master"
		add_child(player)
		_players.append(player)
	_streams["shot_ar21"] = _gunshot(0.11, 1750.0, 95.0, 0.42)
	_streams["shot_smg9"] = _gunshot(0.075, 2200.0, 125.0, 0.33)
	_streams["shot_dmr7"] = _gunshot(0.16, 1450.0, 82.0, 0.52)
	_streams["shot_sg12"] = _gunshot(0.22, 900.0, 58.0, 0.6)
	_streams["shot_p9"] = _gunshot(0.08, 2050.0, 140.0, 0.28)
	_streams["shot_r6"] = _gunshot(0.15, 1280.0, 72.0, 0.52)
	_streams["beep"] = _beep(1450.0, 0.07, 0.18)
	_streams["beep_urgent"] = _beep(1860.0, 0.07, 0.24)
	_streams["hit"] = _beep(820.0, 0.045, 0.13)
	_streams["headshot"] = _beep(1650.0, 0.055, 0.18)
	_streams["empty"] = _beep(1750.0, 0.025, 0.1)
	_streams["ui"] = _beep(1260.0, 0.03, 0.08)
	_streams["buy"] = _sweep(720.0, 1180.0, 0.1, 0.16)
	_streams["reload"] = _reload_sound()
	_streams["explosion"] = _explosion()
	_streams["damage"] = _damage_sound()
	_streams["round_start"] = _round_start()
	_streams["defused"] = _sweep(880.0, 1760.0, 0.3, 0.2)
	_streams["knife_swing"] = _whoosh()

func set_volume(value: float) -> void:
	master_volume = clampf(value, 0.0, 1.0)
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(0.0001, master_volume)))

func play(sound_name: String, volume_db: float = 0.0, pitch: float = 1.0) -> void:
	if not _streams.has(sound_name):
		return
	var player = _players[_next % _players.size()]
	_next += 1
	player.stream = _streams[sound_name]
	player.volume_db = volume_db
	player.pitch_scale = pitch
	player.play()

func shot(id: String, distance: float = 0.0) -> void:
	var attenuation = clampf(1.0 - distance / 55.0, 0.08, 1.0)
	play("shot_" + id, linear_to_db(maxf(0.02, attenuation)), randf_range(0.96, 1.04))

func beep(urgent = false, distance: float = 0.0) -> void:
	var attenuation = clampf(1.0 - distance / 40.0, 0.15, 1.0)
	play("beep_urgent" if urgent else "beep", linear_to_db(attenuation))

func hit(headshot = false) -> void:
	play("headshot" if headshot else "hit")

func empty() -> void:
	play("empty")

func reload() -> void:
	play("reload", -3.0)

func explosion() -> void:
	play("explosion", 2.0)

func damage() -> void:
	play("damage", -1.5)

func round_start() -> void:
	play("round_start", -2.0)

func defused() -> void:
	play("defused", -1.0)

func ui() -> void:
	play("ui", -4.0)

func buy() -> void:
	play("buy", -2.0)

func knife() -> void:
	play("knife_swing", -4.0, randf_range(0.95, 1.05))

func _whoosh() -> AudioStreamWAV:
	var count := int(0.18 * RATE)
	var samples := PackedFloat32Array()
	samples.resize(count)
	var noise := 0.0
	for i in count:
		var t := float(i) / RATE
		noise = lerpf(noise, randf_range(-1.0, 1.0), 0.35)
		var env := sin(PI * clampf(t / 0.18, 0.0, 1.0)) * (1.0 - t * 2.0)
		samples[i] = noise * maxf(0.0, env) * 0.28
	return _wav(samples)

func _add_sample(samples: PackedFloat32Array, index: int, value: float) -> void:
	if index >= 0 and index < samples.size():
		samples[index] += value

func _wav(samples: PackedFloat32Array) -> AudioStreamWAV:
	var data = PackedByteArray()
	data.resize(samples.size() * 2)
	for i in samples.size():
		var v = int(clampf(samples[i], -1.0, 1.0) * 32767.0)
		data[i * 2] = v & 0xFF
		data[i * 2 + 1] = (v >> 8) & 0xFF
	var stream = AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = RATE
	stream.stereo = false
	stream.data = data
	return stream

func _gunshot(duration: float, noise_freq: float, thump_freq: float, gain: float) -> AudioStreamWAV:
	var count = int(duration * RATE)
	var samples = PackedFloat32Array()
	samples.resize(count)
	var noise = 0.0
	var phase = 0.0
	for i in count:
		var t = float(i) / RATE
		var env = exp(-t * 34.0)
		noise = lerpf(noise, randf_range(-1.0, 1.0), clampf(noise_freq / RATE, 0.0, 1.0))
		phase += TAU * thump_freq * (1.0 - t * 1.8) / RATE
		var body = sin(phase) * exp(-t * 24.0) * 0.55
		var crack = noise * env * 0.85
		samples[i] = (crack + body) * gain
	return _wav(samples)

func _beep(freq: float, duration: float, gain: float) -> AudioStreamWAV:
	var count = int(duration * RATE)
	var samples = PackedFloat32Array()
	samples.resize(count)
	for i in count:
		var t = float(i) / RATE
		var env = minf(1.0, t * 500.0) * exp(-t * 60.0)
		samples[i] = sin(TAU * freq * t) * env * gain
	return _wav(samples)

func _sweep(from: float, to: float, duration: float, gain: float) -> AudioStreamWAV:
	var count = int(duration * RATE)
	var samples = PackedFloat32Array()
	samples.resize(count)
	var phase = 0.0
	for i in count:
		var t = float(i) / RATE
		var f = lerpf(from, to, t / duration)
		phase += TAU * f / RATE
		var env = sin(PI * clampf(t / duration, 0.0, 1.0))
		samples[i] = sin(phase) * env * gain
	return _wav(samples)

func _reload_sound() -> AudioStreamWAV:
	var count = int(0.26 * RATE)
	var samples = PackedFloat32Array()
	samples.resize(count)
	for i in count:
		var t = float(i) / RATE
		var v = 0.0
		if t < 0.03:
			v += randf_range(-1.0, 1.0) * exp(-t * 90.0) * 0.18
		if t > 0.14 and t < 0.17:
			v += sin(TAU * 1100.0 * t) * exp(-(t - 0.14) * 120.0) * 0.12
		if t > 0.2 and t < 0.24:
			v += randf_range(-1.0, 1.0) * exp(-(t - 0.2) * 80.0) * 0.2
		samples[i] = v
	return _wav(samples)

func _explosion() -> AudioStreamWAV:
	var count = int(1.7 * RATE)
	var samples = PackedFloat32Array()
	samples.resize(count)
	var phase = 0.0
	var noise = 0.0
	for i in count:
		var t = float(i) / RATE
		noise = lerpf(noise, randf_range(-1.0, 1.0), 0.12)
		phase += TAU * lerpf(70.0, 24.0, t / 1.7) / RATE
		var env = exp(-t * 2.4)
		samples[i] = (noise * 0.55 + sin(phase) * 0.4) * env * 0.8
	return _wav(samples)

func _damage_sound() -> AudioStreamWAV:
	var count = int(0.18 * RATE)
	var samples = PackedFloat32Array()
	samples.resize(count)
	var noise = 0.0
	for i in count:
		var t = float(i) / RATE
		noise = lerpf(noise, randf_range(-1.0, 1.0), 0.2)
		samples[i] = noise * exp(-t * 18.0) * 0.35 + sin(TAU * 60.0 * t) * exp(-t * 25.0) * 0.2
	return _wav(samples)

func _round_start() -> AudioStreamWAV:
	var count = int(0.45 * RATE)
	var samples = PackedFloat32Array()
	samples.resize(count)
	for i in count:
		var t = float(i) / RATE
		var v = 0.0
		if t < 0.16:
			v += sin(TAU * 330.0 * t) * sin(PI * t / 0.16) * 0.14
		if t > 0.16 and t < 0.34:
			v += sin(TAU * 495.0 * t) * sin(PI * (t - 0.16) / 0.18) * 0.12
		samples[i] = v
	return _wav(samples)
