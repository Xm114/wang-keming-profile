class_name Player
extends CharacterBody3D

## 朜玩：原生人称控制、器图模型命丈定入口亡战?
var game = null
var camera: Camera3D
var collision_shape: CollisionShape3D
var weapon_holder: Node3D
var muzzle_flash: MeshInstance3D
var muzzle_light: OmniLight3D
var viewmodel_light: OmniLight3D
var flash_timer = 0.0
var current_weapon_mesh: Node3D
var muzzle_local := Vector3(0.0, 0.02, -0.68)

var team = "attack"
var player_name = "游隼"
var is_player = true
var ally = true

var health = 100.0
var armor = 0.0
var money = 10000
var kit = false
var ammo_bonus = 0
var alive = true
var frozen = true
var bomb_carried = false

var yaw = 0.0
var pitch = 0.0
var eye_height = 1.62
var target_eye_height = 1.62
var crouching = false
var sprinting = false
var ads = 0.0
var shake = 0.0
var bob_time = 0.0
var mouse_look_delta = Vector2.ZERO
var look_lock_timer = 0.0
var fire_held_last = false

var weapons = {"primary": null, "secondary": null, "knife": null}
var current_slot = "secondary"
var reload_timer = 0.0
var reload_total = 0.0
var draw_timer = 0.0
var fire_cooldown = 0.0
var shot_bloom = 0.0
var melee_anim = 0.0
var inspect_timer := 0.0
var inspect_duration := 2.3
var death_time = 0.0
var death_position = Vector3.ZERO

var stats = {"kills": 0, "deaths": 0, "headshots": 0, "plants": 0, "defuses": 0, "damage": 0}

var _base_speed = 4.5
var _sprint_speed = 6.5
var _crouch_speed = 2.0
var _gravity = 19.0
var _jump_velocity = 5.8

func setup(game_ref: Node) -> void:
	game = game_ref
	name = "LocalPlayer"
	collision_layer = 2
	collision_mask = 1
	floor_snap_length = 0.3
	floor_max_angle = deg_to_rad(50)
	up_direction = Vector3.UP

	collision_shape = CollisionShape3D.new()
	var capsule = CapsuleShape3D.new()
	capsule.radius = 0.36
	capsule.height = 1.78
	collision_shape.shape = capsule
	collision_shape.position = Vector3(0, 0.89, 0)
	add_child(collision_shape)

	camera = Camera3D.new()
	camera.name = "Camera"
	camera.position = Vector3(0, 1.62, 0)
	camera.fov = 78.0
	camera.near = 0.05
	camera.far = 240.0
	camera.current = true
	add_child(camera)

	weapon_holder = Node3D.new()
	weapon_holder.name = "WeaponHolder"
	weapon_holder.position = Vector3(0.26, -0.17, -0.72)
	weapon_holder.rotation_degrees = Vector3(0, 7.0, 2.0)
	camera.add_child(weapon_holder)

	muzzle_light = OmniLight3D.new()
	muzzle_light.light_color = Color("#ffc17d")
	muzzle_light.light_energy = 0.0
	muzzle_light.omni_range = 6.0
	muzzle_light.position = Vector3(0, 0.02, -0.68)
	weapon_holder.add_child(muzzle_light)

	muzzle_flash = MeshInstance3D.new()
	var flash_mesh = SphereMesh.new()
	flash_mesh.radius = 0.08
	flash_mesh.height = 0.16
	muzzle_flash.mesh = flash_mesh
	var flash_mat = StandardMaterial3D.new()
	flash_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	flash_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	flash_mat.albedo_color = Color(1.0, 0.78, 0.35, 0.95)
	flash_mat.emission_enabled = true
	flash_mat.emission = Color("#ffb15e")
	flash_mat.emission_energy_multiplier = 4.0
	muzzle_flash.material_override = flash_mat
	muzzle_flash.position = Vector3(0, 0.02, -0.68)
	muzzle_flash.visible = false
	weapon_holder.add_child(muzzle_flash)

	# 视图模型补光：夜间场景里枪身几乎全黑，用一盏小范围补光保证可读
	viewmodel_light = OmniLight3D.new()
	viewmodel_light.light_color = Color("#dbe3e8")
	viewmodel_light.light_energy = 1.6
	viewmodel_light.omni_range = 2.0
	viewmodel_light.omni_attenuation = 0.7
	viewmodel_light.position = Vector3(0.10, 0.55, -0.30)
	weapon_holder.add_child(viewmodel_light)

func set_frozen(value: bool) -> void:
	frozen = value
	if value:
		velocity.x = 0.0
		velocity.z = 0.0
		ads = 0.0
	else:
		look_lock_timer = 0.22
		mouse_look_delta = Vector2.ZERO

func set_team(value: String) -> void:
	team = value
	_rebuild_weapon_view()

func set_mouse_captured(value: bool) -> void:
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED if value else Input.MOUSE_MODE_VISIBLE

func lock_look(duration: float = 0.2) -> void:
	look_lock_timer = maxf(look_lock_timer, duration)
	mouse_look_delta = Vector2.ZERO

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseMotion and alive and game and game.can_control:
		if look_lock_timer > 0.0:
			return
		var sensitivity: float = float(game.settings.get("sensitivity", 1.0)) * 0.0022
		mouse_look_delta += event.relative
		yaw -= event.relative.x * sensitivity
		pitch -= event.relative.y * sensitivity
		pitch = clampf(pitch, -1.32, 1.28)
		rotation.y = yaw
		camera.rotation.x = pitch

func _physics_process(delta: float) -> void:
	look_lock_timer = maxf(0.0, look_lock_timer - delta)
	if not alive:
		_update_dead_camera(delta)
		return

	_update_camera(delta)
	_update_weapon_timers(delta)
	if not game or not game.can_control:
		_apply_idle_physics(delta)
		return

	_handle_movement(delta)
	_handle_actions(delta)
	_update_weapon_view(delta)
	_update_ui()

func _apply_idle_physics(delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0.0, 30.0 * delta)
	velocity.z = move_toward(velocity.z, 0.0, 30.0 * delta)
	if not is_on_floor():
		velocity.y -= _gravity * delta
	else:
		velocity.y = 0.0
	move_and_slide()
	_update_weapon_view(delta)
	_update_ui()

func _handle_movement(delta: float) -> void:
	var input_vec = Vector2.ZERO
	if Input.is_action_pressed("move_forward"):
		input_vec.y -= 1.0
	if Input.is_action_pressed("move_back"):
		input_vec.y += 1.0
	if Input.is_action_pressed("move_left"):
		input_vec.x -= 1.0
	if Input.is_action_pressed("move_right"):
		input_vec.x += 1.0
	input_vec = input_vec.normalized()

	crouching = Input.is_action_pressed("crouch")
	sprinting = Input.is_action_pressed("sprint") and not crouching and not ads and input_vec.length() > 0.2
	var speed = _base_speed
	if crouching:
		speed = _crouch_speed
	elif sprinting:
		speed = _sprint_speed
	if ads > 0.35:
		speed *= 0.58

	# Godot 的 basis.z 指向角色背后；input_vec.y 在 W 时为 -1。
	# 因此这里必须是 “+ basis.z * input_vec.y”，否则 W/S 会反。
	var direction = (transform.basis.x * input_vec.x + transform.basis.z * input_vec.y).normalized()
	var target = direction * speed
	var accel = 14.0 if is_on_floor() else 3.5
	velocity.x = lerpf(velocity.x, target.x, 1.0 - exp(-accel * delta))
	velocity.z = lerpf(velocity.z, target.z, 1.0 - exp(-accel * delta))

	if is_on_floor():
		if Input.is_action_just_pressed("jump"):
			velocity.y = _jump_velocity
		else:
			velocity.y = 0.0
	else:
		velocity.y -= _gravity * delta

	move_and_slide()
	if input_vec.length() > 0.2 and is_on_floor():
		bob_time += delta * (11.0 if sprinting else 7.5)

	target_eye_height = 1.08 if crouching else 1.62
	eye_height = lerpf(eye_height, target_eye_height, 1.0 - exp(-12.0 * delta))

func _start_inspect() -> void:
	if not alive or game == null or not game.can_control:
		return
	if inspect_timer > 0.0 or draw_timer > 0.0 or reload_timer > 0.0 or ads > 0.2:
		return
	if current_weapon_mesh == null:
		return
	# 刀做 CS 那种整把翻腕，枪只是抬起来看一眼
	inspect_duration = 2.3 if current_slot == "knife" else 1.6
	inspect_timer = inspect_duration


func _apply_inspect(delta: float) -> void:
	if inspect_timer <= 0.0 or current_weapon_mesh == null:
		return
	inspect_timer = maxf(0.0, inspect_timer - delta)
	var t := 1.0 - inspect_timer / maxf(0.01, inspect_duration)
	var lift := sin(clampf(t / 0.22, 0.0, 1.0) * PI * 0.5) * (1.0 - smoothstep(0.80, 1.0, t))
	var swing := sin(t * PI)
	current_weapon_mesh.position = Vector3(0.015 * lift, 0.060 * lift, 0.045 * lift)
	if current_slot == "knife":
		# 整把刀绕前向轴转一圈（翻腕），同时轻微偏航/俯仰
		var spin := smoothstep(0.08, 0.90, t) * TAU
		current_weapon_mesh.rotation = Vector3(swing * 0.35, swing * 0.55, spin)
	else:
		current_weapon_mesh.rotation = Vector3(swing * 0.18, swing * 0.85, swing * 0.30)
	if inspect_timer <= 0.0:
		current_weapon_mesh.position = Vector3.ZERO
		current_weapon_mesh.rotation = Vector3.ZERO


func _handle_actions(delta: float) -> void:
	if Input.is_action_just_pressed("reload"):
		_start_reload()
	if Input.is_action_just_pressed("inspect"):
		_start_inspect()
	if Input.is_action_just_pressed("weapon_1"):
		_switch_slot("primary")
	if Input.is_action_just_pressed("weapon_2"):
		_switch_slot("secondary")
	if Input.is_action_just_pressed("weapon_3"):
		_switch_slot("knife")

	var want_ads = Input.is_action_pressed("aim") and current_slot != "knife" and not sprinting and not _is_reloading()
	ads = move_toward(ads, 1.0 if want_ads else 0.0, delta * 6.0)
	var fov = lerpf(float(game.settings.get("fov", 78.0)), float(current_def().get("ads_fov", 54.0)), ads)
	camera.fov = lerpf(camera.fov, fov, 1.0 - exp(-14.0 * delta))

	var can_fire = not _is_reloading() and draw_timer <= 0.0 and fire_cooldown <= 0.0
	if can_fire:
		var def = current_def()
		var auto: bool = bool(def.get("auto", false))
		var trigger = Input.is_action_pressed("fire") if auto else Input.is_action_just_pressed("fire")
		if trigger:
			_fire()

func _fire() -> void:
	var state: Dictionary = weapons[current_slot]
	if state == null:
		return
	if fire_cooldown > 0.0 or draw_timer > 0.0 or reload_timer > 0.0:
		return
	# 开火会打断检视，并把手上的模型复位
	if inspect_timer > 0.0:
		inspect_timer = 0.0
		if current_weapon_mesh != null:
			current_weapon_mesh.position = Vector3.ZERO
			current_weapon_mesh.rotation = Vector3.ZERO
	if current_slot == "knife":
		var knife_def: Dictionary = state["def"]
		fire_cooldown = 1.0 / maxf(0.2, float(knife_def.get("rate", 1.2)))
		melee_anim = 1.0
		var knife_origin := camera.global_position
		var knife_dir := -camera.global_transform.basis.z
		game.player_melee(self, knife_def, knife_origin, knife_dir)
		game.audio.knife()
		return
	if int(state["ammo"]) <= 0:
		if fire_cooldown <= 0.0:
			game.audio.empty()
			fire_cooldown = 0.2
			if int(state["reserve"]) > 0:
				_start_reload()
		return
	state["ammo"] = int(state["ammo"]) - 1
	fire_cooldown = 60.0 / float(state["def"].get("rpm", 600.0))
	shot_bloom = clampf(shot_bloom + 0.75, 0.0, 2.4)

	var def: Dictionary = state["def"]
	var origin = camera.global_position
	var base_dir = -camera.global_transform.basis.z
	var spread: float = float(def.get("spread_ads", 0.003)) if ads > 0.65 else float(def.get("spread_hip", 0.01))
	spread += shot_bloom * 0.004
	if is_on_floor() and Vector2(velocity.x, velocity.z).length() > 0.5:
		spread += float(def.get("moving_spread", 0.01)) * 0.55
	var pellets: int = int(def.get("pellets", 1))
	for i in pellets:
		var dir = _apply_spread(base_dir, spread)
		game.player_fire(self, state["def"], origin, dir)

	var muzzle = get_muzzle_position()
	game.effects.spawn_muzzle_flash(muzzle, Color("#ffc17d"), 1.0)
	game.audio.shot(String(def.get("id", "ar21")), 0.0)
	muzzle_flash.visible = true
	muzzle_light.light_energy = 3.2
	flash_timer = 0.05

	var recoil: float = float(def.get("recoil", 1.0))
	pitch += recoil * 0.0062 * (0.7 if ads > 0.6 else 1.0)
	yaw += randf_range(-1.0, 1.0) * float(def.get("recoil_horizontal", 0.3)) * 0.0018
	pitch = clampf(pitch, -1.32, 1.28)
	camera.rotation.x = pitch
	rotation.y = yaw
	shake = minf(0.8, shake + recoil * 0.035)
	game.ui.update_ammo(self)
	game.ui.pulse_crosshair(shot_bloom)

func _apply_spread(direction: Vector3, spread: float) -> Vector3:
	var basis = camera.global_transform.basis
	var dir = direction
	dir += basis.x * randf_range(-spread, spread)
	dir += basis.y * randf_range(-spread, spread)
	return dir.normalized()

func _update_camera(delta: float) -> void:
	var speed = Vector2(velocity.x, velocity.z).length()
	var moving = speed > 0.6 and is_on_floor()
	var bob_scale = 1.0 - ads * 0.75
	var bob_x = cos(bob_time * 0.5) * 0.012 * bob_scale if moving else 0.0
	var bob_y = absf(sin(bob_time)) * 0.022 * bob_scale if moving else 0.0
	shake = maxf(0.0, shake - delta * 2.4)
	var shake_x = randf_range(-1.0, 1.0) * 0.035 * shake
	var shake_y = randf_range(-1.0, 1.0) * 0.03 * shake
	camera.position = Vector3(bob_x + shake_x, eye_height + bob_y + shake_y, 0.0)
	camera.rotation.z = lerpf(camera.rotation.z, randf_range(-1.0, 1.0) * 0.03 * shake, 1.0 - exp(-10.0 * delta))
	camera.rotation.x = pitch
	rotation.y = yaw

func _update_weapon_timers(delta: float) -> void:
	fire_cooldown = maxf(0.0, fire_cooldown - delta)
	draw_timer = maxf(0.0, draw_timer - delta)
	shot_bloom = maxf(0.0, shot_bloom - delta * 2.4)
	if reload_timer > 0.0:
		reload_timer = maxf(0.0, reload_timer - delta)
		if reload_timer <= 0.0:
			_finish_reload()
	if flash_timer > 0.0:
		flash_timer -= delta
		if flash_timer <= 0.0:
			muzzle_flash.visible = false
			muzzle_light.light_energy = 0.0
	_update_camera_fov(delta)

func _update_camera_fov(delta: float) -> void:
	var def = current_def()
	var target_fov = lerpf(float(game.settings.get("fov", 78.0)), float(def.get("ads_fov", 54.0)), ads)
	camera.fov = lerpf(camera.fov, target_fov, 1.0 - exp(-14.0 * delta))

func _update_weapon_view(delta: float) -> void:
	var speed = Vector2(velocity.x, velocity.z).length()
	var moving = speed > 0.6 and is_on_floor()
	var wid := String(current_def().get("id", "ar21"))
	var view := WeaponView.view_transform(wid)
	var hip: Vector3 = view["pos"]
	var base_rot: Vector3 = view["rot"]
	var ads_pos: Vector3 = view["ads"]
	var target = hip.lerp(ads_pos, ads)
	var bob_amount = (0.018 if sprinting else 0.008) * (1.0 - ads * 0.7) if moving else 0.0
	target.y += absf(sin(bob_time)) * bob_amount
	target.x += cos(bob_time * 0.5) * bob_amount * 0.6
	if reload_timer > 0.0:
		var progress = 1.0 - reload_timer / maxf(0.01, reload_total)
		var arc = sin(progress * PI)
		target.y -= arc * 0.13
		target.x += arc * 0.03
		weapon_holder.rotation.z = arc * 0.35
	else:
		var rest_roll: float = deg_to_rad(base_rot.z) * (1.0 - ads)
		weapon_holder.rotation.z = lerpf(weapon_holder.rotation.z, rest_roll, 1.0 - exp(-10.0 * delta))
	weapon_holder.rotation.y = lerpf(
		weapon_holder.rotation.y, deg_to_rad(base_rot.y) * (1.0 - ads), 1.0 - exp(-12.0 * delta)
	)
	if draw_timer > 0.0:
		target.y -= (draw_timer / maxf(0.01, float(current_def().get("draw_time", 0.4)))) * 0.3
	if current_slot == "knife" and melee_anim > 0.0:
		melee_anim = maxf(0.0, melee_anim - delta * 5.0)
		var slash := sin((1.0 - melee_anim) * PI)
		weapon_holder.rotation.z = 0.45 * slash
		weapon_holder.rotation.y = -0.5 * slash
		target.x += 0.06 * slash
	weapon_holder.position = weapon_holder.position.lerp(target, 1.0 - exp(-16.0 * delta))
	var recoil_offset = shot_bloom * 0.025
	weapon_holder.position.z += recoil_offset
	weapon_holder.rotation.x = lerpf(weapon_holder.rotation.x, -recoil_offset * 1.2, 1.0 - exp(-12.0 * delta))
	_apply_inspect(delta)

func _start_reload() -> void:
	if current_slot == "knife":
		return
	var state: Dictionary = weapons[current_slot]
	if state == null:
		return
	if reload_timer > 0.0 or int(state["ammo"]) >= int(state["def"]["mag"]) or int(state["reserve"]) <= 0:
		return
	reload_total = float(state["def"]["reload"])
	reload_timer = reload_total
	game.audio.reload()

func _finish_reload() -> void:
	var state: Dictionary = weapons[current_slot]
	if state == null:
		return
	var need = int(state["def"]["mag"]) - int(state["ammo"])
	var take = mini(need, int(state["reserve"]))
	state["ammo"] = int(state["ammo"]) + take
	state["reserve"] = int(state["reserve"]) - take
	game.ui.update_ammo(self)

func _switch_slot(slot: String) -> void:
	if slot == current_slot or weapons.get(slot, null) == null:
		return
	reload_timer = 0.0
	current_slot = slot
	draw_timer = float(current_def().get("draw_time", 0.4))
	_rebuild_weapon_view()
	game.audio.play("ui", -8.0)
	game.ui.update_weapon(self)

func _is_reloading() -> bool:
	return reload_timer > 0.0

func current_def() -> Dictionary:
	var state = weapons.get(current_slot, null)
	return state["def"] if state != null else GameConfig.resolve_weapon("p9")

func current_weapon_name() -> String:
	return String(current_def().get("name", "P9"))

func add_money(amount: int) -> void:
	money = maxi(0, money + amount)

func get_muzzle_position() -> Vector3:
	if weapon_holder == null:
		return camera.global_position
	return weapon_holder.to_global(muzzle_local)

func apply_loadout(loadout: Dictionary) -> void:
	weapons.clear()
	weapons["primary"] = null
	weapons["secondary"] = null
	var primary_id: String = loadout.get("primary_id", "ar21")
	if primary_id != "":
		var def = GameConfig.resolve_weapon(primary_id, loadout.get("primary_attachments", {}))
		def["id"] = primary_id
		weapons["primary"] = {"def": def, "ammo": int(def["mag"]), "reserve": int(def["reserve"]) + int(loadout.get("ammo_bonus", 0))}
	var secondary_id: String = loadout.get("secondary_id", "p9")
	var sdef = GameConfig.resolve_weapon(secondary_id, loadout.get("secondary_attachments", {}))
	sdef["id"] = secondary_id
	weapons["secondary"] = {"def": sdef, "ammo": int(sdef["mag"]), "reserve": int(sdef["reserve"]) + int(loadout.get("ammo_bonus", 0))}
	var knife_id: String = "tactical"
	if loadout.has("knife_id"):
		knife_id = String(loadout["knife_id"])
	elif game and game.settings.has("knife"):
		knife_id = String(game.settings["knife"])
	var kdef := GameConfig.resolve_knife(knife_id)
	weapons["knife"] = {"def": kdef, "ammo": 1, "reserve": 0}
	current_slot = "primary" if weapons["primary"] != null else "secondary"
	armor = float(loadout.get("armor", 0))
	kit = bool(loadout.get("kit", false))
	ammo_bonus = int(loadout.get("ammo_bonus", 0))
	draw_timer = float(current_def().get("draw_time", 0.4))
	reload_timer = 0.0
	_rebuild_weapon_view()

func reset_for_round(loadout: Dictionary, spawn_pos: Vector3, spawn_yaw: float) -> void:
	global_position = spawn_pos
	velocity = Vector3.ZERO
	yaw = spawn_yaw
	pitch = 0.0
	rotation = Vector3(0, yaw, 0)
	health = 100.0
	alive = true
	frozen = true
	bomb_carried = false
	death_time = 0.0
	collision_shape.set_deferred("disabled", false)
	camera.top_level = false
	camera.position = Vector3(0, 1.62, 0)
	camera.rotation = Vector3.ZERO
	eye_height = 1.62
	target_eye_height = 1.62
	ads = 0.0
	shake = 0.0
	reload_timer = 0.0
	fire_cooldown = 0.0
	shot_bloom = 0.0
	melee_anim = 0.0
	apply_loadout(loadout)
	camera.current = true
	weapon_holder.visible = true
	look_lock_timer = 0.25
	mouse_look_delta = Vector2.ZERO
	game.ui.set_dead(false)
	game.ui.update_vitals(self)
	game.ui.update_weapon(self)

func take_damage(amount: float, attacker, headshot: bool = false) -> void:
	if not alive:
		return
	var resolved = maxf(1.0, roundf(amount))
	var health_damage = resolved
	if armor > 0.0:
		var absorbed = minf(armor, resolved * 0.5)
		armor = maxf(0.0, armor - absorbed)
		health_damage = resolved - absorbed
	health = maxf(0.0, health - health_damage)
	shake = minf(1.2, shake + 0.32 + resolved * 0.008)
	game.audio.damage()
	game.bomb.cancel_actor(self)
	game.ui.on_player_damaged(int(resolved), headshot, attacker)
	game.ui.update_vitals(self)
	if health <= 0.0:
		_die(attacker, headshot)

func _die(attacker, headshot: bool) -> void:
	if not alive:
		return
	alive = false
	health = 0.0
	death_time = 0.0
	death_position = global_position
	stats["deaths"] = int(stats["deaths"]) + 1
	velocity = Vector3.ZERO
	collision_shape.set_deferred("disabled", true)
	game.bomb.cancel_actor(self)
	game.audio.damage()
	weapon_holder.visible = false
	camera.top_level = true
	camera.global_position = death_position + Vector3(0, 4.0, 0)
	game.ui.set_dead(true)
	game.ui.show_spectate(true)
	game.on_player_death(attacker, headshot)

func _update_dead_camera(delta: float) -> void:
	death_time += delta
	var angle = death_time * 0.18
	var target = death_position + Vector3(sin(angle) * 3.4, 4.2, cos(angle) * 3.4)
	camera.global_position = camera.global_position.lerp(target, 1.0 - exp(-4.0 * delta))
	var focus: Vector3 = game.get_spectate_focus(self) if game else death_position
	camera.look_at(focus + Vector3(0, 1.2, 0), Vector3.UP)

func _rebuild_weapon_view() -> void:
	if weapon_holder == null:
		return
	for child in weapon_holder.get_children():
		if child == muzzle_light or child == muzzle_flash or child == viewmodel_light:
			continue
		child.queue_free()
	current_weapon_mesh = null
	if weapons.get(current_slot, null) == null:
		return
	var def = current_def()
	var weapon_id: String = String(def.get("id", "ar21"))
	var team_color: Color = GameConfig.TEAM.get(team, GameConfig.TEAM["attack"])["color"]

	if String(def.get("slot", "")) == "knife":
		var knife := WeaponView.build(weapon_id, team_color)
		if knife == null:
			return
		weapon_holder.add_child(knife)
		current_weapon_mesh = knife
		muzzle_flash.visible = false
		muzzle_light.light_energy = 0.0
		var knife_view := WeaponView.view_transform(weapon_id)
		weapon_holder.position = knife_view["pos"]
		var knife_rot: Vector3 = knife_view["rot"]
		weapon_holder.rotation = Vector3(0.0, deg_to_rad(knife_rot.y), deg_to_rad(knife_rot.z))
		return

	var gun := WeaponView.build(weapon_id, team_color)
	if gun == null:
		return

	var scale_factor := WeaponView.view_scale()
	gun.scale = Vector3.ONE * scale_factor
	weapon_holder.add_child(gun)
	current_weapon_mesh = gun

	# 枪口位置随武器变化（无托枪、手枪、狙击枪枪管长度差别很大）
	muzzle_local = WeaponView.muzzle_offset(weapon_id, scale_factor)
	muzzle_flash.position = muzzle_local
	muzzle_light.position = muzzle_local

	# 切枪时直接落到该枪的持枪位，避免从上一把枪的位置滑过去
	var view := WeaponView.view_transform(weapon_id)
	weapon_holder.position = view["pos"]
	var rot: Vector3 = view["rot"]
	weapon_holder.rotation = Vector3(0.0, deg_to_rad(rot.y), deg_to_rad(rot.z))
	viewmodel_light.position = Vector3(0.05, 0.32, -0.45)

func _build_knife_mesh(root: Node3D, knife_id: String) -> void:
	var blade := StandardMaterial3D.new()
	blade.albedo_color = Color("#cbd7da")
	blade.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	var edge := StandardMaterial3D.new()
	edge.albedo_color = Color("#eef4f3")
	edge.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	var dark := StandardMaterial3D.new()
	dark.albedo_color = Color("#1c2226")
	dark.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	var team_color: Color = GameConfig.TEAM.get(team, GameConfig.TEAM["attack"])["color"]
	var accent := StandardMaterial3D.new()
	accent.albedo_color = team_color
	accent.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED

	match knife_id:
		"butterfly":
			# 蝴蝶刀：两片手柄 + 中间刀身，展开状态
			_make_box(root, Vector3(0.024, 0.045, 0.20), Vector3(-0.052, -0.02, -0.07), dark, Vector3(0, -8, 8))
			_make_box(root, Vector3(0.024, 0.045, 0.20), Vector3(0.052, -0.02, -0.07), dark, Vector3(0, 8, -8))
			_make_box(root, Vector3(0.026, 0.012, 0.28), Vector3(0, 0.03, -0.31), blade)
			_make_box(root, Vector3(0.01, 0.014, 0.26), Vector3(0, 0.042, -0.33), edge)
			_make_box(root, Vector3(0.075, 0.016, 0.03), Vector3(0, -0.005, -0.19), accent)
			_make_cylinder(root, 0.018, 0.022, Vector3(-0.052, 0.0, -0.18), accent, Vector3(0, 0, 90))
			_make_cylinder(root, 0.018, 0.022, Vector3(0.052, 0.0, -0.18), accent, Vector3(0, 0, 90))
		"karambit":
			# 爪子刀：弯刃 + 指环
			_make_box(root, Vector3(0.05, 0.055, 0.16), Vector3(0, -0.015, -0.03), dark, Vector3(8, 0, 0))
			_make_box(root, Vector3(0.032, 0.014, 0.20), Vector3(0, 0.035, -0.22), blade)
			_make_box(root, Vector3(0.026, 0.014, 0.14), Vector3(0.035, 0.055, -0.34), blade, Vector3(0, 18, 0))
			_make_box(root, Vector3(0.018, 0.016, 0.10), Vector3(0.07, 0.07, -0.42), edge, Vector3(0, 30, 0))
			_make_box(root, Vector3(0.075, 0.018, 0.035), Vector3(0, 0.0, -0.14), accent)
			_make_torus(root, 0.04, 0.012, Vector3(0, -0.045, 0.055), accent, Vector3(90, 0, 0))
		"bayonet":
			# 刺刀：长直刃 + 护手
			_make_box(root, Vector3(0.03, 0.012, 0.44), Vector3(0, 0.035, -0.38), blade)
			_make_box(root, Vector3(0.012, 0.014, 0.42), Vector3(0, 0.046, -0.40), edge)
			_make_box(root, Vector3(0.13, 0.024, 0.032), Vector3(0, 0.0, -0.16), accent)
			_make_box(root, Vector3(0.052, 0.065, 0.17), Vector3(0, -0.015, -0.04), dark, Vector3(8, 0, 0))
			_make_box(root, Vector3(0.06, 0.03, 0.10), Vector3(0, -0.045, 0.04), dark)
		"flip":
			# 折叠刀：窄刃 + 细柄
			_make_box(root, Vector3(0.026, 0.010, 0.27), Vector3(0, 0.032, -0.27), blade)
			_make_box(root, Vector3(0.01, 0.012, 0.26), Vector3(0, 0.042, -0.28), edge)
			_make_box(root, Vector3(0.10, 0.018, 0.026), Vector3(0, 0.0, -0.13), accent)
			_make_box(root, Vector3(0.045, 0.05, 0.16), Vector3(0, -0.012, -0.03), dark, Vector3(6, 0, 0))
			_make_cylinder(root, 0.017, 0.02, Vector3(0, 0.0, -0.12), accent, Vector3(0, 0, 90))
		_:
			# 经典匕首
			_make_box(root, Vector3(0.032, 0.012, 0.30), Vector3(0, 0.035, -0.30), blade)
			_make_box(root, Vector3(0.012, 0.014, 0.28), Vector3(0, 0.046, -0.31), edge)
			_make_box(root, Vector3(0.12, 0.022, 0.032), Vector3(0, 0.0, -0.15), accent)
			_make_box(root, Vector3(0.052, 0.06, 0.15), Vector3(0, -0.015, -0.04), dark, Vector3(8, 0, 0))
			_make_box(root, Vector3(0.06, 0.03, 0.09), Vector3(0, -0.04, 0.02), dark)

func _make_torus(parent: Node3D, inner: float, thickness: float, pos: Vector3, mat: Material, rot_deg = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var mesh := TorusMesh.new()
	mesh.inner_radius = inner
	mesh.outer_radius = inner + thickness
	mesh.rings = 16
	mesh.ring_segments = 8
	mi.mesh = mesh
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.material_override = mat
	parent.add_child(mi)
	return mi

func _make_box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material, rot_deg = Vector3.ZERO) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = BoxMesh.new()
	mesh.size = size
	mi.mesh = mesh
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.material_override = mat
	parent.add_child(mi)
	return mi

func _make_cylinder(parent: Node3D, radius: float, height: float, pos: Vector3, mat: Material, rot_deg = Vector3.ZERO) -> MeshInstance3D:
	var mi = MeshInstance3D.new()
	var mesh = CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 10
	mi.mesh = mesh
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.material_override = mat
	parent.add_child(mi)
	return mi

func _update_ui() -> void:
	if game and game.ui:
		game.ui.update_vitals(self)
		game.ui.update_ammo(self)

func get_aim_point(head = false) -> Vector3:
	return global_position + Vector3(0, 1.62 if head else 1.25, 0)

func get_eye_position() -> Vector3:
	return camera.global_position


