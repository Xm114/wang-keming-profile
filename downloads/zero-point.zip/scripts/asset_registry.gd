class_name AssetRegistry
extends RefCounted

## 素材槽位解析器。
## 当前不强制加载；素材为空时游戏使用 MapBuilder / Player / Bot 内的灰盒。
## 接入素材后，可在对应构建函数里调用 load_model() 替换占位。

const MANIFEST_PATH := "res://assets/manifest.json"
static var _manifest: Dictionary = {}
static var _loaded := false

static func _ensure_manifest() -> void:
	if _loaded:
		return
	_loaded = true
	if not FileAccess.file_exists(MANIFEST_PATH):
		return
	var file := FileAccess.open(MANIFEST_PATH, FileAccess.READ)
	if file == null:
		return
	var parsed = JSON.parse_string(file.get_as_text())
	if parsed is Dictionary:
		_manifest = parsed

static func resolve(key: String) -> String:
	_ensure_manifest()
	var parts := key.split(".")
	var current: Variant = _manifest
	for part in parts:
		if not current is Dictionary or not current.has(part):
			return ""
		current = current[part]
	if current is Dictionary:
		return String(current.get("path", ""))
	if current is String:
		return current
	return ""

static func exists(key: String) -> bool:
	var path := resolve(key)
	return path != "" and ResourceLoader.exists(path)

static func load_model(key: String) -> PackedScene:
	var path := resolve(key)
	if path == "" or not ResourceLoader.exists(path):
		return null
	return load(path) as PackedScene

static func load_texture(key: String) -> Texture2D:
	var path := resolve(key)
	if path == "" or not ResourceLoader.exists(path):
		return null
	return load(path) as Texture2D

static func load_audio(key: String) -> AudioStream:
	var path := resolve(key)
	if path == "" or not ResourceLoader.exists(path):
		return null
	return load(path) as AudioStream
