class_name NavGrid
extends RefCounted

## 轴对齐灰盒地图的栅格导航。
## 后续替换美术地图时，只需继续提供 AABB 障碍，或替换为 NavigationRegion3D。

var bounds: Rect2
var cell_size: float = 1.0
var agent_radius: float = 0.42
var cols: int = 0
var rows: int = 0
var walkable: PackedByteArray = PackedByteArray()
var astar = AStar2D.new()
var point_ids: Dictionary = {}
var solid_rects: Array[Rect2] = []

func build(map_bounds: Rect2, solids: Array[AABB], radius: float = 0.42, cell: float = 1.0) -> void:
	bounds = map_bounds
	cell_size = cell
	agent_radius = radius
	solid_rects.clear()
	for box in solids:
		# 导航只关心会挡人的高度区间（约 0.1 - 1.8m）。
		if box.end.y <= 0.15 or box.position.y >= 1.8:
			continue
		solid_rects.append(Rect2(box.position.x, box.position.z, box.size.x, box.size.z))
	var inner = bounds.grow(-1.0)
	cols = maxi(1, int(ceil(inner.size.x / cell_size)))
	rows = maxi(1, int(ceil(inner.size.y / cell_size)))
	walkable.resize(cols * rows)
	walkable.fill(1)
	astar.clear()
	point_ids.clear()

	for z in rows:
		for x in cols:
			var p = Vector2(inner.position.x + (x + 0.5) * cell_size, inner.position.y + (z + 0.5) * cell_size)
			var ok = is_walkable_world(p.x, p.y)
			walkable[z * cols + x] = 1 if ok else 0
			if ok:
				var id = z * cols + x
				astar.add_point(id, p)
				point_ids[Vector2i(x, z)] = id

	for z in rows:
		for x in cols:
			if not is_walkable_cell(x, z):
				continue
			var id = z * cols + x
			for d in [Vector2i(1, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(-1, 1)]:
				var nx = x + d.x
				var nz = z + d.y
				if not is_walkable_cell(nx, nz):
					continue
				if d.x != 0 and d.y != 0:
					if not is_walkable_cell(x + d.x, z) or not is_walkable_cell(x, z + d.y):
						continue
				var nid = nz * cols + nx
				if astar.has_point(nid) and not astar.are_points_connected(id, nid):
					astar.connect_points(id, nid, true)

func is_walkable_cell(x: int, z: int) -> bool:
	if x < 0 or z < 0 or x >= cols or z >= rows:
		return false
	return walkable[z * cols + x] == 1

func is_walkable_world(x: float, z: float) -> bool:
	if x < bounds.position.x + 0.6 or x > bounds.end.x - 0.6:
		return false
	if z < bounds.position.y + 0.6 or z > bounds.end.y - 0.6:
		return false
	var p = Vector2(x, z)
	for rect in solid_rects:
		if rect.grow(agent_radius).has_point(p):
			return false
	return true

func world_to_cell(x: float, z: float) -> Vector2i:
	var inner = bounds.grow(-1.0)
	return Vector2i(
		clampi(int(floor((x - inner.position.x) / cell_size)), 0, cols - 1),
		clampi(int(floor((z - inner.position.y) / cell_size)), 0, rows - 1)
	)

func cell_to_world(x: int, z: int) -> Vector2:
	var inner = bounds.grow(-1.0)
	return Vector2(inner.position.x + (x + 0.5) * cell_size, inner.position.y + (z + 0.5) * cell_size)

func nearest_walkable(cell: Vector2i, max_radius: int = 6) -> Vector2i:
	if is_walkable_cell(cell.x, cell.y):
		return cell
	for r in range(1, max_radius + 1):
		for dz in range(-r, r + 1):
			for dx in range(-r, r + 1):
				if absi(dx) != r and absi(dz) != r:
					continue
				if is_walkable_cell(cell.x + dx, cell.y + dz):
					return Vector2i(cell.x + dx, cell.y + dz)
	return Vector2i(-1, -1)

func find_path(from: Vector3, to: Vector3) -> PackedVector3Array:
	var start_cell = nearest_walkable(world_to_cell(from.x, from.z), 6)
	var goal_cell = nearest_walkable(world_to_cell(to.x, to.z), 8)
	if start_cell.x < 0 or goal_cell.x < 0:
		return PackedVector3Array()
	var start_id: int = point_ids.get(start_cell, -1)
	var goal_id: int = point_ids.get(goal_cell, -1)
	if start_id < 0 or goal_id < 0:
		return PackedVector3Array()
	if start_id == goal_id:
		return PackedVector3Array([to])
	var points = astar.get_point_path(start_id, goal_id)
	if points.is_empty():
		return PackedVector3Array()
	var raw: Array[Vector3] = []
	for p in points:
		raw.append(Vector3(p.x, 0.0, p.y))
	if raw.size() > 1:
		raw[raw.size() - 1] = to
	return PackedVector3Array(smooth(raw))

func segment_clear(a: Vector3, b: Vector3) -> bool:
	var dist = Vector2(b.x - a.x, b.z - a.z).length()
	var steps = maxi(2, int(ceil(dist / 0.32)))
	for i in range(1, steps):
		var t = float(i) / float(steps)
		var x = lerpf(a.x, b.x, t)
		var z = lerpf(a.z, b.z, t)
		if not is_walkable_world(x, z):
			return false
	return true

func smooth(points: Array[Vector3]) -> Array[Vector3]:
	if points.size() <= 2:
		return points
	var result: Array[Vector3] = [points[0]]
	var anchor = 0
	for i in range(2, points.size()):
		if not segment_clear(points[anchor], points[i]):
			result.append(points[i - 1])
			anchor = i - 1
	result.append(points[points.size() - 1])
	var deduped: Array[Vector3] = []
	for p in result:
		if deduped.is_empty() or p.distance_to(deduped[deduped.size() - 1]) > 0.1:
			deduped.append(p)
	return deduped

func random_point_near(x: float, z: float, min_radius: float = 0.6, max_radius: float = 3.0) -> Vector3:
	for i in 28:
		var angle = randf() * TAU
		var radius = randf_range(min_radius, max_radius)
		var px = x + cos(angle) * radius
		var pz = z + sin(angle) * radius
		if is_walkable_world(px, pz):
			return Vector3(px, 0.0, pz)
	return Vector3(x, 0.0, z)
