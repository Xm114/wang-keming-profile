class_name Effects
extends Node3D

## 第一/第三人称弹道、命中火花、枪口火光与爆炸。
## 使用短生命周期节点，原型阶段不引入粒子资产。

var _tracer_mat: StandardMaterial3D
var _impact_mat: StandardMaterial3D
var _spark_mat: StandardMaterial3D

func _ready() -> void:
	_tracer_mat = StandardMaterial3D.new()
	_tracer_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_tracer_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_tracer_mat.emission_enabled = true
	_tracer_mat.emission = Color("#ffd7a0")
	_tracer_mat.albedo_color = Color(1.0, 0.82, 0.55, 0.85)
	_tracer_mat.disable_receive_shadows = true

	_impact_mat = StandardMaterial3D.new()
	_impact_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_impact_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_impact_mat.emission_enabled = true
	_impact_mat.emission = Color("#ffc378")
	_impact_mat.albedo_color = Color(1.0, 0.72, 0.35, 0.95)

	_spark_mat = StandardMaterial3D.new()
	_spark_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_spark_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_spark_mat.emission_enabled = true
	_spark_mat.emission = Color("#ff8a3d")
	_spark_mat.albedo_color = Color(1.0, 0.52, 0.18, 1.0)

func spawn_tracer(from: Vector3, to: Vector3, color = Color("#ffd7a0")) -> void:
	var length = from.distance_to(to)
	if length < 0.08:
		return
	var mesh = MeshInstance3D.new()
	var box = BoxMesh.new()
	box.size = Vector3(0.018, 0.018, length)
	mesh.mesh = box
	var mat = _tracer_mat.duplicate() as StandardMaterial3D
	mat.albedo_color = Color(color.r, color.g, color.b, 0.9)
	mat.emission = color
	mesh.material_override = mat
	mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mesh)
	mesh.global_position = (from + to) * 0.5
	if (to - from).length() > 0.01 and absf((to - from).normalized().dot(Vector3.UP)) < 0.995:
		mesh.look_at(to, Vector3.UP)
	else:
		mesh.look_at(to, Vector3.FORWARD)
	var tween = create_tween()
	tween.tween_property(mat, "albedo_color:a", 0.0, 0.08)
	tween.tween_callback(mesh.queue_free)

func spawn_impact(point: Vector3, normal: Vector3, kind = "hard") -> void:
	var mesh = MeshInstance3D.new()
	var sphere = SphereMesh.new()
	sphere.radius = 0.08
	sphere.height = 0.16
	sphere.radial_segments = 8
	sphere.rings = 4
	mesh.mesh = sphere
	var mat = _impact_mat.duplicate() as StandardMaterial3D
	mat.albedo_color = Color(1.0, 0.35, 0.2, 0.95) if kind == "flesh" else Color(1.0, 0.7, 0.35, 0.95)
	mesh.material_override = mat
	mesh.position = point + normal * 0.03
	mesh.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mesh)
	mesh.scale = Vector3.ONE * 0.7
	var tween = create_tween()
	tween.set_parallel(true)
	tween.tween_property(mesh, "scale", Vector3.ONE * 2.2, 0.18)
	tween.tween_property(mat, "albedo_color:a", 0.0, 0.18)
	tween.chain().tween_callback(mesh.queue_free)

	# 飞溅火花
	var spark_count = 3 if kind == "flesh" else 5
	for i in spark_count:
		var spark = MeshInstance3D.new()
		var spark_mesh = BoxMesh.new()
		spark_mesh.size = Vector3(0.025, 0.025, 0.11)
		spark.mesh = spark_mesh
		spark.material_override = _spark_mat
		spark.position = point
		spark.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(spark)
		var dir = normal
		dir += Vector3(randf_range(-0.7, 0.7), randf_range(-0.2, 0.7), randf_range(-0.7, 0.7))
		dir = dir.normalized()
		var target = point + dir * randf_range(0.5, 1.5)
		var t = create_tween()
		t.set_parallel(true)
		t.tween_property(spark, "global_position", target, 0.26)
		t.tween_property(spark, "scale", Vector3(0.1, 0.1, 0.1), 0.26)
		t.chain().tween_callback(spark.queue_free)

func spawn_muzzle_flash(position: Vector3, color = Color("#ffc477"), scale = 1.0) -> void:
	var light = OmniLight3D.new()
	light.light_color = color
	light.light_energy = 4.5 * scale
	light.omni_range = 5.5
	light.position = position
	add_child(light)
	var t = create_tween()
	t.tween_property(light, "light_energy", 0.0, 0.06)
	t.tween_callback(light.queue_free)

func spawn_explosion(position: Vector3) -> void:
	var root = Node3D.new()
	root.position = position
	add_child(root)

	var light = OmniLight3D.new()
	light.light_color = Color("#ff6b2c")
	light.light_energy = 30.0
	light.omni_range = 34.0
	light.position.y = 2.0
	root.add_child(light)

	var sphere = MeshInstance3D.new()
	var sphere_mesh = SphereMesh.new()
	sphere_mesh.radius = 1.0
	sphere_mesh.height = 2.0
	sphere_mesh.radial_segments = 20
	sphere_mesh.rings = 10
	sphere.mesh = sphere_mesh
	var mat = StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.emission_enabled = true
	mat.emission = Color("#ffb15e")
	mat.albedo_color = Color(1.0, 0.65, 0.25, 0.9)
	sphere.material_override = mat
	sphere.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	root.add_child(sphere)

	var ring = MeshInstance3D.new()
	var torus = TorusMesh.new()
	torus.inner_radius = 0.9
	torus.outer_radius = 1.1
	torus.rings = 32
	torus.ring_segments = 4
	ring.mesh = torus
	var ring_mat = mat.duplicate() as StandardMaterial3D
	ring_mat.emission = Color("#ff6b2c")
	ring_mat.albedo_color = Color(1.0, 0.4, 0.1, 0.8)
	ring.material_override = ring_mat
	ring.position.y = 0.25
	root.add_child(ring)

	var particles = CPUParticles3D.new()
	particles.amount = 72
	particles.lifetime = 1.35
	particles.one_shot = true
	particles.explosiveness = 0.95
	particles.emitting = true
	particles.direction = Vector3(0, 1, 0)
	particles.spread = 180.0
	particles.initial_velocity_min = 4.0
	particles.initial_velocity_max = 18.0
	particles.gravity = Vector3(0, -13.0, 0)
	particles.scale_amount_min = 0.06
	particles.scale_amount_max = 0.2
	particles.color = Color("#ff9a4d")
	var quad = QuadMesh.new()
	quad.size = Vector2(0.22, 0.22)
	var pmat = StandardMaterial3D.new()
	pmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	pmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	pmat.billboard_mode = BaseMaterial3D.BILLBOARD_ENABLED
	pmat.albedo_color = Color(1.0, 0.5, 0.15, 0.9)
	pmat.emission_enabled = true
	pmat.emission = Color("#ff7b2d")
	quad.material = pmat
	particles.mesh = quad
	particles.position.y = 0.7
	root.add_child(particles)

	var tween = create_tween()
	tween.set_parallel(true)
	tween.tween_property(sphere, "scale", Vector3.ONE * 12.0, 0.55).set_ease(Tween.EASE_OUT)
	tween.tween_property(mat, "albedo_color:a", 0.0, 0.7)
	tween.tween_property(ring, "scale", Vector3.ONE * 14.0, 0.8).set_ease(Tween.EASE_OUT)
	tween.tween_property(ring_mat, "albedo_color:a", 0.0, 0.9)
	tween.tween_property(light, "light_energy", 0.0, 0.8)
	get_tree().create_timer(2.2).timeout.connect(root.queue_free)
