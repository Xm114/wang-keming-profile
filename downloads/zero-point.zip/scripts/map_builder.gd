class_name MapBuilder
extends Node3D

## 零点电站（ZP-01）灰盒地图。
## 同一份数据用于可视网格、物理碰撞和 A* 导航，之后可逐块替换为 GLB 资产。

const MAP_BOUNDS = Rect2(-40.0, -30.0, 80.0, 60.0)

var solids: Array[Dictionary] = []
var nav_solids: Array[AABB] = []
var sites: Array[Dictionary] = []
var spawns = {}
var bot_holds = {}
var world_body: StaticBody3D
var materials = {}
var ui_font: SystemFont
var site_visuals: Array[Dictionary] = []
var pulse_time = 0.0
var world_environment: WorldEnvironment

func build() -> void:
	_make_fonts()
	_make_materials()
	_build_environment()
	_build_lights()
	_build_ground()
	_define_solids()
	_build_solids()
	_build_sites()
	_build_decorations()
	_build_spawns_and_data()

func _make_fonts() -> void:
	ui_font = SystemFont.new()
	ui_font.font_names = PackedStringArray(["Microsoft YaHei UI", "Microsoft YaHei", "Noto Sans CJK SC", "Noto Sans SC", "Arial"])
	ui_font.font_weight = 500
	ui_font.allow_system_fallback = true

func _make_materials() -> void:
	materials["concrete"] = _mat(Color("#394347"), 0.92, 0.04)
	materials["concrete_dark"] = _mat(Color("#2d363a"), 0.95, 0.03)
	materials["metal"] = _mat(Color("#2d373c"), 0.48, 0.62)
	materials["metal_light"] = _mat(Color("#55636a"), 0.42, 0.68)
	materials["container_orange"] = _mat(Color("#533b2c"), 0.62, 0.4)
	materials["container_teal"] = _mat(Color("#294348"), 0.58, 0.48)
	materials["container_sand"] = _mat(Color("#4c473a"), 0.68, 0.34)
	materials["crate"] = _mat(Color("#3b3a2c"), 0.72, 0.3)
	materials["dark"] = _mat(Color("#0b1114"), 0.78, 0.28)
	materials["rubber"] = _mat(Color("#151b1e"), 0.96, 0.02)
	materials["steel_trim"] = _mat(Color("#6d7a80"), 0.34, 0.76)
	materials["hazard"] = _hazard_material()
	materials["ground"] = _ground_material()
	materials["glass"] = _glow_mat(Color("#0b2026"), Color("#12343d"), 0.5, true)
	materials["orange"] = _glow_mat(Color("#ff6b2c"), Color("#ff6b2c"), 1.4)
	materials["cyan"] = _glow_mat(Color("#42d8ff"), Color("#42d8ff"), 1.4)
	materials["red"] = _glow_mat(Color("#ff2d1a"), Color("#ff2d1a"), 2.0)
	materials["white_light"] = _glow_mat(Color("#d7eef4"), Color("#d7eef4"), 1.2)

func _mat(color: Color, roughness: float, metallic: float) -> StandardMaterial3D:
	var m = StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	m.metallic = metallic
	return m

func _glow_mat(color: Color, emission: Color, energy: float, transparent = false) -> StandardMaterial3D:
	var m = StandardMaterial3D.new()
	m.albedo_color = color
	m.emission_enabled = true
	m.emission = emission
	m.emission_energy_multiplier = energy
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	if transparent:
		m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		m.albedo_color.a = 0.7
	return m

func _hazard_material() -> ShaderMaterial:
	var shader = Shader.new()
	shader.code = """
shader_type spatial;
render_mode diffuse_burley;
uniform vec3 stripe_a : source_color = vec3(0.76, 0.48, 0.10);
uniform vec3 stripe_b : source_color = vec3(0.055, 0.07, 0.08);
void fragment() {
	float s = step(0.5, fract((UV.x + UV.y) * 5.0));
	ALBEDO = mix(stripe_a, stripe_b, s);
	ROUGHNESS = 0.72;
	METALLIC = 0.15;
}
"""
	var m = ShaderMaterial.new()
	m.shader = shader
	return m

func _ground_material() -> ShaderMaterial:
	var shader = Shader.new()
	shader.code = """
shader_type spatial;
render_mode diffuse_burley, specular_schlick_ggx;
uniform vec3 base_color : source_color = vec3(0.060, 0.078, 0.089);
uniform vec3 line_color : source_color = vec3(0.018, 0.028, 0.033);
varying vec3 world_pos;
float hash21(vec2 p) {
	p = fract(p * vec2(123.34, 345.45));
	p += dot(p, p + 34.345);
	return fract(p.x * p.y);
}
void vertex() {
	world_pos = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
}
void fragment() {
	vec2 grid = abs(fract(world_pos.xz / 6.0) - 0.5);
	float seam = smoothstep(0.478, 0.494, max(grid.x, grid.y));
	vec2 fine = abs(fract(world_pos.xz / 1.5) - 0.5);
	float fine_line = smoothstep(0.485, 0.497, max(fine.x, fine.y)) * 0.16;
	float n = hash21(floor(world_pos.xz * 2.5)) * 0.06;
	vec3 col = base_color + n;
	col = mix(col, line_color, seam * 0.75);
	col = mix(col, line_color, fine_line);
	ALBEDO = col;
	ROUGHNESS = 0.93;
	METALLIC = 0.04;
}
"""
	var m = ShaderMaterial.new()
	m.shader = shader
	return m

func _build_environment() -> void:
	var env = Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky = Sky.new()
	var sky_mat = ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color("#030a10")
	sky_mat.sky_horizon_color = Color("#102c35")
	sky_mat.ground_bottom_color = Color("#030608")
	sky_mat.ground_horizon_color = Color("#09151a")
	sky_mat.sun_angle_max = 18.0
	sky_mat.sun_curve = 0.12
	sky_mat.energy_multiplier = 0.9
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_color = Color("#3b4d55")
	env.ambient_light_energy = 0.55
	env.reflected_light_source = Environment.REFLECTION_SOURCE_SKY
	env.tonemap_mode = Environment.TONE_MAPPER_ACES
	env.tonemap_exposure = 1.12
	env.glow_enabled = true
	env.glow_intensity = 0.65
	env.glow_bloom = 0.12
	env.glow_hdr_threshold = 0.9
	env.glow_blend_mode = Environment.GLOW_BLEND_MODE_ADDITIVE
	env.fog_enabled = true
	env.fog_light_color = Color("#09171d")
	env.fog_light_energy = 0.55
	env.fog_density = 0.0125
	env.fog_sky_affect = 0.75
	world_environment = WorldEnvironment.new()
	world_environment.environment = env
	add_child(world_environment)

func _build_lights() -> void:
	var moon = DirectionalLight3D.new()
	moon.name = "MoonLight"
	moon.light_color = Color("#a5c7d8")
	moon.light_energy = 1.25
	moon.rotation_degrees = Vector3(-52.0, -34.0, 0.0)
	moon.shadow_enabled = true
	moon.directional_shadow_max_distance = 110.0
	moon.directional_shadow_mode = DirectionalLight3D.SHADOW_ORTHOGONAL
	moon.directional_shadow_split_1 = 0.15
	moon.directional_shadow_split_2 = 0.35
	moon.directional_shadow_split_3 = 0.65
	add_child(moon)

	for data in [
		{"pos": Vector3(-18, 4.2, -11), "color": Color("#ff6b2c"), "energy": 7.5, "range": 22.0},
		{"pos": Vector3(18, 4.2, -11), "color": Color("#42d8ff"), "energy": 6.8, "range": 22.0},
		{"pos": Vector3(0, 4.0, 22), "color": Color("#ff7a3d"), "energy": 3.8, "range": 20.0},
		{"pos": Vector3(0, 4.0, -22), "color": Color("#49d6ff"), "energy": 3.3, "range": 20.0},
		{"pos": Vector3(-31, 3.2, 8), "color": Color("#9cc8d6"), "energy": 2.3, "range": 16.0},
		{"pos": Vector3(31, 3.2, 8), "color": Color("#9cc8d6"), "energy": 2.3, "range": 16.0},
		{"pos": Vector3(-36, 3.2, 14), "color": Color("#a9d7e2"), "energy": 2.8, "range": 17.0},
		{"pos": Vector3(36, 3.2, 14), "color": Color("#a9d7e2"), "energy": 2.8, "range": 17.0},
		{"pos": Vector3(-32, 3.2, -23), "color": Color("#a9d7e2"), "energy": 2.0, "range": 14.0},
		{"pos": Vector3(32, 3.2, -23), "color": Color("#a9d7e2"), "energy": 2.0, "range": 14.0},
	]:
		var light = OmniLight3D.new()
		light.position = data["pos"]
		light.light_color = data["color"]
		light.light_energy = data["energy"]
		light.omni_range = data["range"]
		light.omni_attenuation = 1.2
		add_child(light)

	var center_fill = SpotLight3D.new()
	center_fill.light_color = Color("#b9d3de")
	center_fill.light_energy = 4.0
	center_fill.spot_range = 48.0
	center_fill.spot_angle = 58.0
	center_fill.position = Vector3(0, 18.0, 5.0)
	center_fill.shadow_enabled = false
	add_child(center_fill)
	center_fill.look_at(Vector3.ZERO)

func _build_ground() -> void:
	var ground = MeshInstance3D.new()
	ground.name = "Ground"
	var mesh = BoxMesh.new()
	mesh.size = Vector3(80.0, 0.2, 60.0)
	ground.mesh = mesh
	ground.position = Vector3(0, -0.1, 0)
	ground.material_override = materials["ground"]
	add_child(ground)

	var shape = CollisionShape3D.new()
	var box = BoxShape3D.new()
	box.size = Vector3(80.0, 0.2, 60.0)
	shape.shape = box
	shape.position = Vector3(0, -0.1, 0)
	_ensure_world_body()
	world_body.add_child(shape)

	# 地面水洼：高反射的扁平圆盘。
	for data in [
		[Vector3(-8, 0.011, 18), 3.8, 2.2],
		[Vector3(12, 0.011, 2), 4.5, 1.8],
		[Vector3(-25, 0.011, 10), 3.2, 1.4],
		[Vector3(26, 0.011, 12), 2.6, 3.2],
		[Vector3(-4, 0.011, -13), 3.1, 1.6],
	]:
		var puddle = MeshInstance3D.new()
		var cylinder = CylinderMesh.new()
		cylinder.top_radius = 1.0
		cylinder.bottom_radius = 1.0
		cylinder.height = 0.01
		cylinder.radial_segments = 32
		puddle.mesh = cylinder
		puddle.scale = Vector3(data[1], 1.0, data[2])
		puddle.position = data[0]
		var mat = StandardMaterial3D.new()
		mat.albedo_color = Color("#101b20")
		mat.roughness = 0.12
		mat.metallic = 0.78
		puddle.material_override = mat
		puddle.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(puddle)

	# 地面危险条
	for data in [
		[Vector3(-8, 0.02, 9.2), Vector3(7, 0.02, 0.42), 0.0],
		[Vector3(8, 0.02, 9.2), Vector3(7, 0.02, 0.42), 0.0],
		[Vector3(0, 0.02, 10.4), Vector3(4.2, 0.02, 0.3), 0.0],
		[Vector3(-28, 0.02, 21.2), Vector3(7, 0.02, 0.35), 0.0],
		[Vector3(28, 0.02, 21.2), Vector3(7, 0.02, 0.35), 0.0],
	]:
		var strip = MeshInstance3D.new()
		var strip_mesh = BoxMesh.new()
		strip_mesh.size = data[1]
		strip.mesh = strip_mesh
		strip.position = data[0]
		strip.material_override = materials["hazard"]
		strip.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(strip)

func _define_solids() -> void:
	# 外围
	_add_solid("perimeter-n", "concrete", 0, -30.5, 80, 1, 8)
	_add_solid("perimeter-s", "concrete", 0, 30.5, 80, 1, 8)
	_add_solid("perimeter-w", "concrete", -40.5, 0, 1, 60, 8)
	_add_solid("perimeter-e", "concrete", 40.5, 0, 1, 60, 8)

	# A 包点
	_add_solid("a-transformer", "metal", -27.5, -2.2, 5, 10, 4.8)
	_add_solid("a-control", "concrete", -10, -18, 9, 4.2, 4.0)
	_add_solid("a-backwall-left", "concrete", -23.5, -20.1, 5, 1, 3.2)
	_add_solid("a-backwall-right", "concrete", -16.5, -20.1, 5, 1, 3.2)
	_add_solid("a-container", "container_orange", -24.2, -13.2, 2.8, 5, 2.6)
	_add_solid("a-crate-cover", "container_teal", -14.8, -15, 2.6, 2.6, 2.6)
	_add_solid("a-barrier", "concrete", -14, -6.7, 5.2, 0.9, 1.2)
	_add_solid("a-crate-low", "crate", -19.2, -4.8, 1.7, 1.7, 1.25)
	_add_solid("a-crate-stack", "crate", -21.7, -4.6, 1.3, 1.3, 2.1)

	# B 包点
	_add_solid("b-pump", "metal", 27.2, -15, 6, 7, 4.4)
	_add_solid("b-turbine", "metal", 27.3, 0, 5, 9, 4.8)
	_add_solid("b-control", "concrete", 11, -18, 7, 4, 4.0)
	_add_solid("b-backwall-left", "concrete", 16.5, -20.1, 5, 1, 3.2)
	_add_solid("b-backwall-right", "concrete", 23.5, -20.1, 5, 1, 3.2)
	_add_solid("b-container", "container_orange", 21.2, -13.2, 2.8, 5, 2.6)
	_add_solid("b-crate-cover", "container_teal", 14.6, -15, 2.6, 2.6, 2.6)
	_add_solid("b-barrier", "concrete", 14, -6.7, 5.2, 0.9, 1.2)
	_add_solid("b-crate-low", "crate", 19, -4.8, 1.7, 1.7, 1.25)
	_add_solid("b-crate-stack", "crate", 21.5, -4.6, 1.3, 1.3, 2.1)

	# 中路
	_add_solid("mid-admin", "concrete", 0, -3.5, 10, 9, 4.8)
	_add_solid("mid-wall-s-left", "concrete", -16, 7.2, 18, 1.2, 3.1)
	_add_solid("mid-wall-s-right", "concrete", 16, 7.2, 18, 1.2, 3.1)
	_add_solid("mid-wall-n-left", "concrete", -18.5, -17.2, 16, 1.1, 3.0)
	_add_solid("mid-wall-n-right", "concrete", 18.5, -17.2, 16, 1.1, 3.0)
	_add_solid("mid-crate-center", "crate", 0, 4.2, 2.2, 2.2, 1.3)
	_add_solid("mid-crate-w", "crate", -8.5, 2.8, 1.6, 1.6, 1.1)
	_add_solid("mid-crate-e", "crate", 8.5, 2.8, 1.6, 1.6, 1.1)

	# 南侧
	_add_solid("south-barrier-w", "concrete", -10, 14, 5, 1, 1.15)
	_add_solid("south-barrier-e", "concrete", 10, 14, 5, 1, 1.15)
	_add_solid("south-container-w", "container_sand", -15, 19.5, 3.2, 2.6, 2.5)
	_add_solid("south-container-e", "container_sand", 15, 19.5, 3.2, 2.6, 2.5)
	_add_solid("south-crate-w", "crate", -3.5, 18, 1.4, 1.4, 1.1)
	_add_solid("south-crate-e", "crate", 3.5, 18, 1.4, 1.4, 1.1)

	# 北侧
	_add_solid("north-barrier-w", "concrete", -9, -19.8, 4, 1, 1.1)
	_add_solid("north-barrier-e", "concrete", 9, -19.8, 4, 1, 1.1)
	_add_solid("north-crate-w", "crate", -3.4, -20.7, 1.4, 1.4, 1.1)
	_add_solid("north-crate-e", "crate", 3.4, -20.7, 1.4, 1.4, 1.1)

	# A 长道
	_add_solid("a-long-crate", "crate", -30.5, 8.5, 2, 2, 1.4)
	_add_solid("a-long-barrier", "concrete", -29, 15.5, 4, 1, 1.15)
	_add_solid("a-long-crate-2", "crate", -31.3, 2.2, 1.5, 1.5, 1.2)
	_add_solid("a-link-crate", "crate", -23.5, 4.2, 1.8, 1.8, 1.25)

	# B 长道
	_add_solid("b-long-crate", "crate", 30.5, 8.5, 2, 2, 1.4)
	_add_solid("b-long-barrier", "concrete", 29, 15.5, 4, 1, 1.15)
	_add_solid("b-long-crate-2", "crate", 31.3, 2.2, 1.5, 1.5, 1.2)
	_add_solid("b-link-crate", "crate", 23.5, 4.2, 1.8, 1.8, 1.25)

	# 外圈西侧长道
	_add_solid("west-lane-container-1", "container_orange", -36.5, 18, 3, 4, 2.6)
	_add_solid("west-lane-barrier-1", "concrete", -36, 11, 5, 1, 1.15)
	_add_solid("west-lane-building", "concrete", -36, 4, 4, 4, 3.2)
	_add_solid("west-lane-container-2", "container_teal", -36.5, -4, 3, 5, 2.6)
	_add_solid("west-lane-crate", "crate", -33.5, -12, 2, 2, 1.3)
	_add_solid("west-lane-barrier-2", "concrete", -37, -20, 4, 1, 1.15)

	# 外圈东侧长道
	_add_solid("east-lane-container-1", "container_orange", 36.5, 18, 3, 4, 2.6)
	_add_solid("east-lane-barrier-1", "concrete", 36, 11, 5, 1, 1.15)
	_add_solid("east-lane-building", "concrete", 36, 4, 4, 4, 3.2)
	_add_solid("east-lane-container-2", "container_teal", 36.5, -4, 3, 5, 2.6)
	_add_solid("east-lane-crate", "crate", 33.5, -12, 2, 2, 1.3)
	_add_solid("east-lane-barrier-2", "concrete", 37, -20, 4, 1, 1.15)

	# 南侧外圈 / 出生区前掩体
	_add_solid("south-depot-w", "container_sand", -28, 24, 4, 3, 2.6)
	_add_solid("south-depot-e", "container_sand", 28, 24, 4, 3, 2.6)
	_add_solid("south-gate-w", "concrete", -10, 24, 6, 1, 2.2)
	_add_solid("south-gate-e", "concrete", 10, 24, 6, 1, 2.2)

	# 北侧后院 / 可绕后区域
	_add_solid("north-yard-building-w", "concrete", -33, -23, 4, 4, 3.2)
	_add_solid("north-yard-building-e", "concrete", 33, -23, 4, 4, 3.2)
	_add_solid("north-yard-crate-w", "crate", -27, -25.5, 2, 2, 1.3)
	_add_solid("north-yard-crate-e", "crate", 27, -25.5, 2, 2, 1.3)
	_add_solid("north-yard-barrier-w", "concrete", -8, -25, 5, 1, 1.15)
	_add_solid("north-yard-barrier-e", "concrete", 8, -25, 5, 1, 1.15)

	# 中场增加第二层掩体，打破长视线
	_add_solid("mid-cover-center-2", "crate", 0, 13, 2.2, 2.2, 1.3)
	_add_solid("mid-cover-sw-2", "concrete", -8, 12.5, 4, 1, 1.15)
	_add_solid("mid-cover-se-2", "concrete", 8, 12.5, 4, 1, 1.15)

func _add_solid(id: String, kind: String, x: float, z: float, w: float, d: float, h: float) -> void:
	var pos = Vector3(x, h * 0.5, z)
	var size = Vector3(w, h, d)
	solids.append({"id": id, "kind": kind, "pos": pos, "size": size})
	nav_solids.append(AABB(Vector3(x - w * 0.5, 0.0, z - d * 0.5), Vector3(w, h, d)))

func _ensure_world_body() -> void:
	if world_body != null:
		return
	world_body = StaticBody3D.new()
	world_body.name = "WorldCollision"
	world_body.collision_layer = 1
	world_body.collision_mask = 0
	world_body.add_to_group("world")
	add_child(world_body)

func _build_solids() -> void:
	_ensure_world_body()
	for s in solids:
		var kind: String = s["kind"]
		var mesh_instance = MeshInstance3D.new()
		var box = BoxMesh.new()
		box.size = s["size"]
		mesh_instance.mesh = box
		mesh_instance.position = s["pos"]
		mesh_instance.material_override = materials.get(kind, materials["concrete"])
		mesh_instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
		add_child(mesh_instance)

		var shape = CollisionShape3D.new()
		var collision_box = BoxShape3D.new()
		collision_box.size = s["size"]
		shape.shape = collision_box
		shape.position = s["pos"]
		world_body.add_child(shape)

		_add_solid_detail(s, mesh_instance)

	# 外围墙顶压条 / 立柱
	for s in solids:
		if not String(s["id"]).begins_with("perimeter"):
			continue
		var pos: Vector3 = s["pos"]
		var size: Vector3 = s["size"]
		var cap = MeshInstance3D.new()
		var cap_box = BoxMesh.new()
		cap_box.size = Vector3(size.x + 0.15, 0.16, size.z + 0.15)
		cap.mesh = cap_box
		cap.position = Vector3(pos.x, pos.y + size.y * 0.5 - 0.04, pos.z)
		cap.material_override = materials["dark"]
		add_child(cap)

func _add_solid_detail(s: Dictionary, mesh_instance: MeshInstance3D) -> void:
	var kind: String = s["kind"]
	var pos: Vector3 = s["pos"]
	var size: Vector3 = s["size"]
	if kind.begins_with("container"):
		var dark: Material = materials["dark"]
		for side in [-1.0, 1.0]:
			var post = MeshInstance3D.new()
			var post_mesh = BoxMesh.new()
			post_mesh.size = Vector3(0.08, size.y * 0.86, 0.04)
			post.mesh = post_mesh
			post.position = Vector3(pos.x + side * (size.x * 0.5 + 0.02), pos.y, pos.z)
			post.material_override = dark
			add_child(post)
		var rail = MeshInstance3D.new()
		var rail_mesh = BoxMesh.new()
		rail_mesh.size = Vector3(size.x + 0.05, 0.07, size.z + 0.05)
		rail.mesh = rail_mesh
		rail.position = Vector3(pos.x, pos.y + size.y * 0.5 + 0.02, pos.z)
		rail.material_override = dark
		add_child(rail)
		# 侧面波纹
		var ribs = int(maxf(2.0, size.z / 0.6))
		for i in ribs:
			var rib = MeshInstance3D.new()
			var rib_mesh = BoxMesh.new()
			rib_mesh.size = Vector3(0.03, size.y * 0.78, 0.035)
			rib.mesh = rib_mesh
			rib.position = Vector3(pos.x + size.x * 0.5 + 0.03, pos.y, pos.z - size.z * 0.42 + (size.z * 0.84) * (float(i) / float(maxi(1, ribs - 1))))
			rib.material_override = materials["container_teal"] if kind.ends_with("teal") else materials["dark"]
			add_child(rib)
	elif kind == "crate":
		var band = MeshInstance3D.new()
		var band_mesh = BoxMesh.new()
		band_mesh.size = Vector3(size.x + 0.01, 0.05, size.z + 0.01)
		band.mesh = band_mesh
		band.position = Vector3(pos.x, pos.y + size.y * 0.06, pos.z)
		band.material_override = materials["hazard"]
		add_child(band)
	elif kind == "concrete" and size.y > 2.5 and size.x * size.z < 120:
		# 工业建筑通风窗
		for i in 3:
			var vent = MeshInstance3D.new()
			var vent_mesh = BoxMesh.new()
			vent_mesh.size = Vector3(1.1, 0.35, 0.02)
			vent.mesh = vent_mesh
			vent.position = Vector3(pos.x - size.x * 0.24 + i * 1.8, pos.y + size.y * 0.16, pos.z + size.z * 0.5 + 0.012)
			vent.material_override = materials["glass"]
			add_child(vent)
	elif kind == "metal":
		var vent = MeshInstance3D.new()
		var vent_mesh = BoxMesh.new()
		vent_mesh.size = Vector3(size.x * 0.35, 0.6, size.z * 0.28)
		vent.mesh = vent_mesh
		vent.position = Vector3(pos.x - size.x * 0.16, pos.y + size.y * 0.5 + 0.3, pos.z - size.z * 0.12)
		vent.material_override = materials["metal_light"]
		add_child(vent)
		var pipe = MeshInstance3D.new()
		var pipe_mesh = CylinderMesh.new()
		pipe_mesh.top_radius = 0.1
		pipe_mesh.bottom_radius = 0.1
		pipe_mesh.height = size.y
		pipe_mesh.radial_segments = 8
		pipe.mesh = pipe_mesh
		pipe.position = Vector3(pos.x + size.x * 0.42, pos.y, pos.z + size.z * 0.42)
		pipe.material_override = materials["steel_trim"]
		add_child(pipe)

	if String(s["id"]).contains("barrier"):
		for side in [-1.0, 1.0]:
			var hazard = MeshInstance3D.new()
			var hazard_mesh = BoxMesh.new()
			hazard_mesh.size = Vector3(size.x * 0.96, 0.13, 0.015)
			hazard.mesh = hazard_mesh
			hazard.position = Vector3(pos.x, pos.y + size.y * 0.13, pos.z + side * (size.z * 0.5 + 0.01))
			hazard.material_override = materials["hazard"]
			add_child(hazard)

func _build_sites() -> void:
	sites = [
		{"id": "A", "name": "变电站", "subtitle": "SUBSTATION", "center": Vector3(-18, 0, -11), "radius": 4.15, "color": Color("#ff6b2c")},
		{"id": "B", "name": "泵房", "subtitle": "PUMP STATION", "center": Vector3(18, 0, -11), "radius": 4.15, "color": Color("#42d8ff")},
	]
	for site in sites:
		var center: Vector3 = site["center"]
		var color: Color = site["color"]
		var ring = MeshInstance3D.new()
		var torus = TorusMesh.new()
		torus.inner_radius = 3.98
		torus.outer_radius = 4.16
		torus.rings = 64
		torus.ring_segments = 6
		ring.mesh = torus
		ring.position = center + Vector3(0, 0.035, 0)
		var ring_mat = StandardMaterial3D.new()
		ring_mat.albedo_color = Color(color.r, color.g, color.b, 0.9)
		ring_mat.emission_enabled = true
		ring_mat.emission = color
		ring_mat.emission_energy_multiplier = 1.3
		ring_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		ring_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		ring.material_override = ring_mat
		ring.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(ring)

		var beam = MeshInstance3D.new()
		var cylinder = CylinderMesh.new()
		cylinder.top_radius = 3.85
		cylinder.bottom_radius = 3.85
		cylinder.height = 7.0
		cylinder.radial_segments = 32
		cylinder.rings = 1
		cylinder.cap_top = false
		cylinder.cap_bottom = false
		beam.mesh = cylinder
		beam.position = center + Vector3(0, 3.5, 0)
		var beam_mat = StandardMaterial3D.new()
		beam_mat.albedo_color = Color(color.r, color.g, color.b, 0.035)
		beam_mat.emission_enabled = true
		beam_mat.emission = color
		beam_mat.emission_energy_multiplier = 0.6
		beam_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		beam_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		beam_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
		beam.material_override = beam_mat
		beam.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(beam)

		var label = Label3D.new()
		label.text = site["id"]
		label.font = ui_font
		label.font_size = 300
		label.pixel_size = 0.012
		label.outline_size = 44
		label.modulate = color
		label.outline_modulate = Color(color.r, color.g, color.b, 0.55)
		label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		label.no_depth_test = true
		label.render_priority = 20
		label.position = center + Vector3(0, 3.8, 0)
		add_child(label)

		# 场地终端
		var terminal = Node3D.new()
		terminal.position = center + Vector3(-2.8 if site["id"] == "A" else 2.8, 0, 2.6)
		var body = MeshInstance3D.new()
		var body_mesh = BoxMesh.new()
		body_mesh.size = Vector3(0.65, 0.95, 0.42)
		body.mesh = body_mesh
		body.position.y = 0.475
		body.material_override = materials["dark"]
		terminal.add_child(body)
		var screen = MeshInstance3D.new()
		var screen_mesh = BoxMesh.new()
		screen_mesh.size = Vector3(0.43, 0.26, 0.02)
		screen.mesh = screen_mesh
		screen.position = Vector3(0, 0.62, 0.22)
		screen.material_override = materials["orange"] if site["id"] == "A" else materials["cyan"]
		terminal.add_child(screen)
		var antenna = MeshInstance3D.new()
		var antenna_mesh = CylinderMesh.new()
		antenna_mesh.top_radius = 0.018
		antenna_mesh.bottom_radius = 0.018
		antenna_mesh.height = 1.1
		antenna_mesh.radial_segments = 6
		antenna.mesh = antenna_mesh
		antenna.position = Vector3(0.22, 1.05, 0)
		antenna.material_override = materials["steel_trim"]
		terminal.add_child(antenna)
		add_child(terminal)

		site_visuals.append({"site": site, "beam": beam, "label": label, "ring": ring})

	# 墙面标识
	for data in [
		{"site": "A", "pos": Vector3(-23.5, 2.3, -19.52)},
		{"site": "B", "pos": Vector3(23.5, 2.3, -19.52)},
	]:
		var site_data: Dictionary = sites[0]
		for s in sites:
			if s["id"] == data["site"]:
				site_data = s
		var sign = Label3D.new()
		sign.text = "%s // %s\n%s" % [site_data["id"], site_data["name"], site_data["subtitle"]]
		sign.font = ui_font
		sign.font_size = 42
		sign.pixel_size = 0.012
		sign.outline_size = 8
		sign.modulate = site_data["color"]
		sign.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		sign.position = data["pos"]
		sign.double_sided = true
		sign.billboard = BaseMaterial3D.BILLBOARD_DISABLED
		add_child(sign)

func _build_decorations() -> void:
	# 屋顶设备
	for data in [
		{"pos": Vector3(-2.4, 5.2, -5.0), "size": Vector3(1.8, 0.8, 1.4)},
		{"pos": Vector3(2.6, 5.15, -1.8), "size": Vector3(1.4, 0.7, 1.4)},
	]:
		var unit = MeshInstance3D.new()
		var box = BoxMesh.new()
		box.size = data["size"]
		unit.mesh = box
		unit.position = data["pos"]
		unit.material_override = materials["metal"]
		add_child(unit)

	# 场外冷却塔 / 工业剪影
	for data in [
		{"pos": Vector3(-66, 13, -58), "r": 8.0, "h": 26.0},
		{"pos": Vector3(70, 12, -72), "r": 7.5, "h": 24.0},
		{"pos": Vector3(-88, 11, 20), "r": 7.0, "h": 22.0},
	]:
		var tower = MeshInstance3D.new()
		var cylinder = CylinderMesh.new()
		cylinder.top_radius = data["r"] * 0.78
		cylinder.bottom_radius = data["r"]
		cylinder.height = data["h"]
		cylinder.radial_segments = 20
		cylinder.cap_top = false
		cylinder.cap_bottom = false
		tower.mesh = cylinder
		tower.position = data["pos"]
		var mat = StandardMaterial3D.new()
		mat.albedo_color = Color("#091116")
		mat.roughness = 0.95
		tower.material_override = mat
		add_child(tower)

	# 高杆灯
	for data in [
		Vector3(-18, 0, -11), Vector3(18, 0, -11), Vector3(0, 0, 6),
		Vector3(-30, 0, 12), Vector3(30, 0, 12),
	]:
		var mast = MeshInstance3D.new()
		var mast_mesh = CylinderMesh.new()
		mast_mesh.top_radius = 0.06
		mast_mesh.bottom_radius = 0.08
		mast_mesh.height = 3.6
		mast_mesh.radial_segments = 8
		mast.mesh = mast_mesh
		mast.position = data + Vector3(0, 1.8, 0)
		mast.material_override = materials["steel_trim"]
		add_child(mast)
		var head = MeshInstance3D.new()
		var head_mesh = BoxMesh.new()
		head_mesh.size = Vector3(0.4, 0.14, 0.22)
		head.mesh = head_mesh
		head.position = data + Vector3(0, 3.55, 0)
		head.material_override = materials["dark"]
		add_child(head)
		var bulb = MeshInstance3D.new()
		var bulb_mesh = BoxMesh.new()
		bulb_mesh.size = Vector3(0.3, 0.03, 0.14)
		bulb.mesh = bulb_mesh
		bulb.position = data + Vector3(0, 3.48, 0)
		bulb.material_override = materials["orange"] if data.x < 0 else materials["cyan"]
		add_child(bulb)

	# 场区管道
	for data in [
		{"pos": Vector3(-12, 3.4, -21.3), "len": 9.0, "axis": "x"},
		{"pos": Vector3(12, 3.4, -21.3), "len": 9.0, "axis": "x"},
		{"pos": Vector3(-31.8, 3.3, 6.0), "len": 12.0, "axis": "z"},
		{"pos": Vector3(31.8, 3.3, 6.0), "len": 12.0, "axis": "z"},
	]:
		var pipe = MeshInstance3D.new()
		var cylinder = CylinderMesh.new()
		cylinder.top_radius = 0.12
		cylinder.bottom_radius = 0.12
		cylinder.height = data["len"]
		cylinder.radial_segments = 10
		pipe.mesh = cylinder
		pipe.position = data["pos"]
		if data["axis"] == "x":
			pipe.rotation_degrees = Vector3(0, 0, 90)
		else:
			pipe.rotation_degrees = Vector3(90, 0, 0)
		pipe.material_override = materials["steel_trim"]
		add_child(pipe)

	# 出生区地面文字

func _add_floor_label(pos: Vector3, text: String, color: Color) -> void:
	var label = Label3D.new()
	label.text = text
	label.font = ui_font
	label.font_size = 96
	label.pixel_size = 0.012
	label.modulate = Color(color.r, color.g, color.b, 0.55)
	label.outline_size = 12
	label.outline_modulate = Color(0, 0, 0, 0.6)
	label.billboard = BaseMaterial3D.BILLBOARD_DISABLED
	label.position = pos
	label.rotation_degrees = Vector3(-90, 0, 0)
	label.double_sided = true
	add_child(label)

func _build_spawns_and_data() -> void:
	spawns = {
		"attack": [
			{"pos": Vector3(0, 0, 27.2), "yaw": 0.0},
			{"pos": Vector3(-6.5, 0, 28.3), "yaw": 0.0},
			{"pos": Vector3(6.5, 0, 28.3), "yaw": 0.0},
			{"pos": Vector3(-9.5, 0, 26.8), "yaw": 0.08},
			{"pos": Vector3(9.5, 0, 26.8), "yaw": -0.08},
		],
		"defense": [
			{"pos": Vector3(0, 0, -27.2), "yaw": PI},
			{"pos": Vector3(-6.5, 0, -28.3), "yaw": PI},
			{"pos": Vector3(6.5, 0, -28.3), "yaw": PI},
			{"pos": Vector3(-9.5, 0, -26.8), "yaw": PI - 0.08},
			{"pos": Vector3(9.5, 0, -26.8), "yaw": PI + 0.08},
		],
	}
	bot_holds = {
		"attack": {
			"A": [
				Vector3(-31.5, 0, 18), Vector3(-30, 0, 10), Vector3(-32, 0, 2),
				Vector3(-31.5, 0, -7), Vector3(-27, 0, -11), Vector3(-22, 0, -9),
			],
			"B": [
				Vector3(31.5, 0, 18), Vector3(30, 0, 10), Vector3(32, 0, 2),
				Vector3(31.5, 0, -7), Vector3(27, 0, -11), Vector3(22, 0, -9),
			],
			"postplant": {
				"A": [
					Vector3(-22, 0, -9), Vector3(-18, 0, -16), Vector3(-12, 0, -12),
					Vector3(-26, 0, -18), Vector3(-9, 0, -7),
				],
				"B": [
					Vector3(22, 0, -9), Vector3(17, 0, -16), Vector3(12, 0, -12),
					Vector3(26, 0, -18), Vector3(9, 0, -7),
				],
			},
		},
		"defense": {
			"A": [
				Vector3(-25, 0, -18), Vector3(-20, 0, -7), Vector3(-11, 0, -12),
				Vector3(-19, 0, -16), Vector3(-27, 0, -10),
			],
			"B": [
				Vector3(26, 0, -8), Vector3(19, 0, -17), Vector3(11, 0, -12),
				Vector3(30, 0, -20), Vector3(23, 0, -6),
			],
			"mid": [
				Vector3(-8, 0, -2), Vector3(8, 0, -2), Vector3(0, 0, -14),
				Vector3(-2, 0, 4.8), Vector3(2, 0, 4.8),
			],
		},
	}

const ATTACK_APPROACH = {
	"A": [
		Vector3(-18, 0, -7.1), Vector3(-21.3, 0, -8.3), Vector3(-14.8, 0, -9.6),
		Vector3(-18.2, 0, -14.1), Vector3(-22.5, 0, -16.6),
	],
	"B": [
		Vector3(18, 0, -7.1), Vector3(15.2, 0, -9.4), Vector3(23.8, 0, -8.4),
		Vector3(17.8, 0, -14.1), Vector3(12.2, 0, -10.4),
	],
}

func get_spawn(team: String, index: int) -> Dictionary:
	var list: Array = spawns.get(team, spawns["attack"])
	return list[index % list.size()]

func get_site(id: String) -> Dictionary:
	for site in sites:
		if site["id"] == id:
			return site
	return sites[0]

func site_at(pos: Vector3) -> Dictionary:
	for site in sites:
		var center: Vector3 = site["center"]
		if Vector2(pos.x - center.x, pos.z - center.z).length() <= float(site["radius"]):
			return site
	return {}

func get_attack_approach(bot_index: int, site_id: String, carrier: bool) -> Vector3:
	if carrier:
		return get_site(site_id)["center"]
	var list: Array = ATTACK_APPROACH.get(site_id, ATTACK_APPROACH["A"])
	var p: Vector3 = list[bot_index % list.size()]
	return p + Vector3(randf_range(-0.35, 0.35), 0, randf_range(-0.35, 0.35))

func get_post_plant_hold(bot_index: int, site_id: String) -> Vector3:
	var list: Array = bot_holds["attack"]["postplant"].get(site_id, bot_holds["attack"]["postplant"]["A"])
	var p: Vector3 = list[bot_index % list.size()]
	return p + Vector3(randf_range(-0.3, 0.3), 0, randf_range(-0.3, 0.3))

func _process(delta: float) -> void:
	pulse_time += delta
	for v in site_visuals:
		var beam: MeshInstance3D = v["beam"]
		var label: Label3D = v["label"]
		if beam and beam.material_override is StandardMaterial3D:
			beam.material_override.emission_energy_multiplier = 0.45 + sin(pulse_time * 2.0 + (0.0 if v["site"]["id"] == "A" else 1.4)) * 0.15
		if label:
			label.position.y = 3.8 + sin(pulse_time * 1.1 + (0.0 if v["site"]["id"] == "A" else 1.7)) * 0.12


func _build_stars() -> void:
	var multimesh := MultiMesh.new()
	var sphere := SphereMesh.new()
	sphere.radius = 0.35
	sphere.height = 0.7
	sphere.radial_segments = 5
	sphere.rings = 3
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color(0.72, 0.86, 0.92, 0.8)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	mat.disable_fog = true
	sphere.material = mat
	multimesh.mesh = sphere
	multimesh.instance_count = 180
	for i in 180:
		var theta := randf() * TAU
		var phi := randf_range(0.08, 1.35)
		var radius := 165.0
		var pos := Vector3(cos(theta) * cos(phi) * radius, sin(phi) * radius + 8.0, sin(theta) * cos(phi) * radius)
		var basis := Basis.IDENTITY.scaled(Vector3.ONE * randf_range(0.45, 1.15))
		multimesh.set_instance_transform(i, Transform3D(basis, pos))
	var mmi := MultiMeshInstance3D.new()
	mmi.multimesh = multimesh
	mmi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mmi)
