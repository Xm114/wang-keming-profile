class_name Match
extends Node

## 比赛 / 回合 / 比分 / 换边 / 经济 / 玩家与炸弹交互。

var game
var player: Player
var bomb: Bomb
var ui

var initial_side = "attack"
var player_side = "attack"
var round_number = 0
var scores = {"attack": 0, "defense": 0}
var phase = "idle"
var phase_time = 0.0
var round_time = 90.0
var round_ended = false
var match_over = false
var side_swapped = false
var attack_site = "A"
var bots: Array[Bot] = []
var alpha_roster: Array[String] = []
var bravo_roster: Array[String] = []
var bot_stats = {}
var last_winner = ""
var last_reason = ""

func setup(game_ref, player_ref: Player, bomb_ref: Bomb, ui_ref) -> void:
	game = game_ref
	player = player_ref
	bomb = bomb_ref
	ui = ui_ref
	set_process(true)

func start_match(side: String = "attack") -> void:
	initial_side = "defense" if side == "defense" else "attack"
	player_side = initial_side
	round_number = 0
	scores = {"attack": 0, "defense": 0}
	side_swapped = false
	match_over = false
	round_ended = false
	last_winner = ""
	last_reason = ""
	bot_stats.clear()
	player.stats = {"kills": 0, "deaths": 0, "headshots": 0, "plants": 0, "defuses": 0, "damage": 0}
	alpha_roster = _build_roster(initial_side, true)
	bravo_roster = _build_roster(GameConfig.other_team(initial_side), false)
	_clear_bots()
	_create_bots()
	player.set_team(player_side)
	ui.reset_match(self)
	begin_round()

func _build_roster(side: String, alpha: bool) -> Array[String]:
	var source: Array = GameConfig.BOT_NAMES_ATTACK if side == "attack" else GameConfig.BOT_NAMES_DEFENSE
	var names: Array[String] = []
	for n in source:
		if n != player.player_name:
			names.append(n)
	var count = GameConfig.MATCH["team_size"] - 1 if alpha else GameConfig.MATCH["team_size"]
	return names.slice(0, count)

func _clear_bots() -> void:
	for bot in bots:
		if is_instance_valid(bot):
			remove_child(bot)
			bot.queue_free()
	bots.clear()

func _create_bots() -> void:
	var alpha_side = player_side
	var bravo_side = GameConfig.other_team(player_side)
	for i in alpha_roster.size():
		var bot = Bot.new()
		add_child(bot)
		bot.setup(game, alpha_side, alpha_roster[i], true, i, 0.38 + ((i + 1) % 4) * 0.16)
		_restore_bot_stats(bot)
		bots.append(bot)
	for i in bravo_roster.size():
		var bot = Bot.new()
		add_child(bot)
		bot.setup(game, bravo_side, bravo_roster[i], false, i, 0.38 + ((i + 2) % 4) * 0.16)
		_restore_bot_stats(bot)
		bots.append(bot)

func _restore_bot_stats(bot: Bot) -> void:
	if bot_stats.has(bot.bot_name):
		var s: Dictionary = bot_stats[bot.bot_name]
		bot.stats = s.duplicate()

func _save_bot_stats() -> void:
	for bot in bots:
		if is_instance_valid(bot):
			bot_stats[bot.bot_name] = bot.stats.duplicate()

func _rebuild_bots_for_side_switch() -> void:
	_save_bot_stats()
	_clear_bots()
	_create_bots()

func get_allies() -> Array:
	return bots.filter(func(b): return b.ally)

func get_enemies() -> Array:
	return bots.filter(func(b): return not b.ally)

func begin_round() -> void:
	round_number += 1
	round_ended = false
	round_time = float(GameConfig.MATCH["round_time"])
	phase = "buy"
	phase_time = float(GameConfig.MATCH["buy_time"])
	attack_site = "A" if randf() < 0.5 else "B"
	bomb.reset()
	ui.set_interaction(null)
	ui.show_planted_alert(false)

	if round_number > int(GameConfig.MATCH["switch_sides_after"]) and not side_swapped:
		scores = {"attack": scores["defense"], "defense": scores["attack"]}
		side_swapped = true
		player_side = GameConfig.other_team(initial_side)
		player.set_team(player_side)
		_rebuild_bots_for_side_switch()
		ui.show_banner("SIDE SWITCH", "攻守交换", "下半场开始 · 先取 6 分获胜", 3.6)

	player_side = initial_side if round_number <= int(GameConfig.MATCH["switch_sides_after"]) else GameConfig.other_team(initial_side)
	player.set_team(player_side)

	var player_spawn: Dictionary = game.map.get_spawn(player_side, 0)
	var loadout: Dictionary = ui.get_round_loadout(player_side, int(GameConfig.MATCH["start_credits"]))
	var cost = int(loadout.get("cost", 0))
	player.money = maxi(0, int(GameConfig.MATCH["start_credits"]) - cost)
	loadout["money"] = player.money
	if player_side != "defense":
		loadout["kit"] = false
	player.reset_for_round(loadout, player_spawn["pos"], player_spawn["yaw"])
	player.frozen = true

	var alpha_bots: Array = bots.filter(func(b): return b.ally)
	var bravo_bots: Array = bots.filter(func(b): return not b.ally)
	var alpha_spawns: Array = game.map.spawns[player_side]
	var bravo_spawns: Array = game.map.spawns[GameConfig.other_team(player_side)]
	var player_is_attacker = player_side == "attack"

	for i in alpha_bots.size():
		var bot: Bot = alpha_bots[i]
		var assignment = _make_assignment(player_side, i + 1, false)
		assignment["spawn"] = alpha_spawns[(i + 1) % alpha_spawns.size()]
		bot.configure_round(player_side, assignment["site"], assignment["role"], assignment["hold"], assignment["spawn"]["pos"], assignment["spawn"]["yaw"], assignment["weapon"], assignment["kit"], false)

	for i in bravo_bots.size():
		var bot: Bot = bravo_bots[i]
		var will_carry = (not player_is_attacker) and i == 0
		var assignment = _make_assignment(GameConfig.other_team(player_side), i, will_carry)
		assignment["spawn"] = bravo_spawns[i % bravo_spawns.size()]
		bot.configure_round(GameConfig.other_team(player_side), assignment["site"], assignment["role"], assignment["hold"], assignment["spawn"]["pos"], assignment["spawn"]["yaw"], assignment["weapon"], assignment["kit"], will_carry)

	if player_is_attacker:
		bomb.give_to(player)
	else:
		var carrier: Bot = bravo_bots[0] if bravo_bots.size() > 0 else null
		if carrier:
			bomb.give_to(carrier)
			carrier.set_bomb_carrier(true)

	for bot in bots:
		bot.set_frozen(true)

	ui.update_round(round_number)
	ui.update_score(scores)
	ui.update_alive(get_alive_counts()[0], get_alive_counts()[1])
	ui.update_clock({"phase": "buy", "phase_time": phase_time, "round_time": round_time, "bomb_remaining": null})
	ui.set_objective("前往 %s 包点，安放黑匣炸弹" % attack_site if player_is_attacker else "防守 %s 包点，阻止敌方安放" % attack_site)
	ui.show_banner("ROUND %02d" % round_number, "购买阶段", "按 B 打开军械库 · %d 秒后行动开始" % int(GameConfig.MATCH["buy_time"]), 2.6)
	game.on_round_started(self)

func _make_assignment(side: String, index: int, will_carry: bool) -> Dictionary:
	var weapon_list: Array = GameConfig.BOT_WEAPONS_ATTACK if side == "attack" else GameConfig.BOT_WEAPONS_DEFENSE
	var weapon: String = weapon_list[index % weapon_list.size()]
	var has_kit = side == "defense" and index == 0
	if side == "attack":
		var hold: Vector3 = game.map.get_attack_approach(index, attack_site, will_carry)
		return {
			"site": attack_site,
			"role": "carrier" if will_carry else "entry",
			"hold": hold,
			"weapon": weapon,
			"kit": false,
			"spawn": {},
		}
	var plan = _defense_plan()
	var slot: Dictionary = plan[index % plan.size()]
	return {
		"site": slot["site"],
		"role": "roamer" if slot["site"] == "mid" else "anchor",
		"hold": slot["hold"] + Vector3(randf_range(-0.7, 0.7), 0, randf_range(-0.7, 0.7)),
		"weapon": weapon,
		"kit": has_kit,
		"spawn": {},
	}

func _defense_plan() -> Array:
	var A: Array = game.map.bot_holds["defense"]["A"]
	var B: Array = game.map.bot_holds["defense"]["B"]
	var M: Array = game.map.bot_holds["defense"]["mid"]
	if player_side == "defense":
		return [
			{"site": "A", "hold": A[0]}, {"site": "A", "hold": A[2]},
			{"site": "B", "hold": B[0]}, {"site": "B", "hold": B[2]},
		]
	return [
		{"site": "A", "hold": A[0]}, {"site": "A", "hold": A[2]},
		{"site": "B", "hold": B[0]}, {"site": "B", "hold": B[2]},
		{"site": "mid", "hold": M[2]},
	]

func start_live() -> void:
	if phase != "buy":
		return
	phase = "live"
	phase_time = 0.0
	round_time = float(GameConfig.MATCH["round_time"])
	player.frozen = false
	for bot in bots:
		bot.set_frozen(false)
	ui.close_buy(true)
	ui.show_banner("ACTION", "行动开始", "突破防线，安放黑匣" if player_side == "attack" else "守住包点，拦截进攻", 1.7)
	game.audio.round_start()
	game.on_live_started(self)
	_refresh_hud()

func ready_up() -> void:
	start_live()

func _process(delta: float) -> void:
	if match_over:
		return
	if phase == "buy":
		phase_time -= delta
		ui.update_clock({"phase": "buy", "phase_time": phase_time, "round_time": round_time, "bomb_remaining": null})
		if phase_time <= 0.0:
			start_live()
		return
	if phase == "live":
		round_time = maxf(0.0, round_time - delta)
		bomb.update(delta)
		_update_player_interaction()
		ui.update_clock({
			"phase": "planted" if bomb.state == "planted" else "live",
			"phase_time": phase_time,
			"round_time": round_time,
			"bomb_remaining": bomb.remaining if bomb.state == "planted" else null,
		})
		if bomb.state != "planted" and round_time <= 0.0:
			end_round("defense", "回合时间耗尽")
		check_win_conditions()
		return
	if phase == "round_end":
		phase_time -= delta
		ui.update_clock({"phase": "live", "phase_time": 0.0, "round_time": 0.0, "bomb_remaining": null})
		if phase_time <= 0.0:
			if _should_end_match():
				finish_match()
			else:
				begin_round()

func _update_player_interaction() -> void:
	if not player.alive:
		ui.set_interaction(null)
		return
	if bomb.state == "carried" and bomb.carrier == player:
		var site: Dictionary = game.map.site_at(player.global_position)
		if not site.is_empty():
			var active = Input.is_action_pressed("interact")
			bomb.set_planting(player, active)
			var planting = bomb.planting_actor == player
			ui.set_interaction({
				"key": "E",
				"label": ("正在安放黑匣 · %s 包点" % site["id"]) if planting else ("按住 E 安放黑匣 · %s 包点" % site["id"]),
				"time": "%.1fs" % maxf(0.0, float(GameConfig.MATCH["plant_time"]) - (bomb.plant_progress if planting else 0.0)),
				"progress": bomb.plant_progress / float(GameConfig.MATCH["plant_time"]) if planting else 0.0,
				"tone": "plant",
			})
		else:
			bomb.set_planting(player, false)
			ui.set_interaction(null)
			ui.set_objective("前往 A / B 包点安放黑匣")
		return

	if bomb.state == "dropped" and player.team == "attack":
		if player.global_position.distance_to(bomb.global_position) <= float(GameConfig.MATCH["bomb_pickup_range"]):
			ui.set_interaction({"key": "E", "label": "拾取黑匣炸弹", "time": "", "progress": 0.0, "tone": "pickup"})
			if Input.is_action_just_pressed("interact"):
				if bomb.pickup(player):
					ui.toast("黑匣已回收，前往包点安放", "success")
					ui.set_interaction(null)
			return

	if bomb.state == "planted" and player.team == "defense":
		if player.global_position.distance_to(bomb.global_position) <= float(GameConfig.MATCH["defuse_range"]) + 0.4:
			var active = Input.is_action_pressed("interact")
			bomb.set_defusing(player, active)
			var defusing = bomb.defusing_actor == player
			var total = float(GameConfig.MATCH["defuse_kit_time"]) if player.kit else float(GameConfig.MATCH["defuse_time"])
			ui.set_interaction({
				"key": "E",
				"label": "正在拆除黑匣" if defusing else ("按住 E 拆除黑匣 · 拆弹器" if player.kit else "按住 E 拆除黑匣"),
				"time": "%.1fs" % maxf(0.0, total - (bomb.defuse_progress if defusing else 0.0)),
				"progress": bomb.defuse_progress / maxf(0.01, bomb.defuse_total) if defusing else 0.0,
				"tone": "defuse",
			})
			return

	bomb.set_planting(player, false)
	bomb.set_defusing(player, false)
	ui.set_interaction(null)

func check_win_conditions() -> void:
	if phase != "live" or round_ended:
		return
	var counts = get_alive_counts()
	var attackers: int = counts[0]
	var defenders: int = counts[1]
	if bomb.state == "planted":
		if defenders == 0:
			end_round("attack", "守军已全部阵亡")
		return
	if attackers == 0:
		end_round("defense", "进攻方已全部阵亡")
	elif defenders == 0:
		end_round("attack", "防守方已全部阵亡")
	elif round_time <= 0.0:
		end_round("defense", "回合时间耗尽")

func get_alive_counts() -> Array:
	var attackers = 0
	var defenders = 0
	if player.alive:
		if player.team == "attack":
			attackers += 1
		else:
			defenders += 1
	for bot in bots:
		if not bot.alive:
			continue
		if bot.team == "attack":
			attackers += 1
		else:
			defenders += 1
	return [attackers, defenders]

func end_round(winner: String, reason: String) -> void:
	if round_ended or match_over or phase == "round_end":
		return
	round_ended = true
	phase = "round_end"
	phase_time = float(GameConfig.MATCH["round_end_delay"])
	last_winner = winner
	last_reason = reason
	scores[winner] += 1
	player.frozen = true
	for bot in bots:
		bot.set_frozen(true)
	bomb.cancel_actor(player)
	for bot in bots:
		bomb.cancel_actor(bot)
	var player_won = winner == player.team
	ui.update_score(scores)
	ui.update_alive(get_alive_counts()[0], get_alive_counts()[1])
	ui.show_planted_alert(false)
	ui.set_interaction(null)
	ui.show_round_result({
		"player_won": player_won,
		"winner": winner,
		"reason": reason,
		"scores": scores,
		"round_number": round_number,
		"countdown": float(GameConfig.MATCH["round_end_delay"]),
	})
	game.audio.play("round_start", -2.0)
	game.on_round_ended(self, winner, reason)

func _should_end_match() -> bool:
	return scores["attack"] >= int(GameConfig.MATCH["rounds_to_win"]) or scores["defense"] >= int(GameConfig.MATCH["rounds_to_win"]) or round_number >= int(GameConfig.MATCH["max_rounds"])

func finish_match() -> void:
	if match_over:
		return
	match_over = true
	phase = "match_end"
	player.frozen = true
	for bot in bots:
		bot.set_frozen(true)
	ui.update_score(scores)
	var player_won = scores[player.team] > scores[GameConfig.other_team(player.team)]
	game.on_match_end(self, player_won)

func get_scoreboard() -> Array:
	var rows: Array = [{
		"name": player.player_name,
		"team": player.team,
		"kills": player.stats["kills"],
		"deaths": player.stats["deaths"],
		"headshots": player.stats["headshots"],
		"alive": player.alive,
		"is_player": true,
	}]
	for bot in bots:
		rows.append({
			"name": bot.bot_name,
			"team": bot.team,
			"kills": bot.stats["kills"],
			"deaths": bot.stats["deaths"],
			"headshots": bot.stats["headshots"],
			"alive": bot.alive,
			"is_player": false,
		})
	rows.sort_custom(func(a, b):
		if a["team"] != b["team"]:
			return a["team"] == player.team
		if a["kills"] != b["kills"]:
			return a["kills"] > b["kills"]
		return a["deaths"] < b["deaths"])
	return rows

func get_alive_combatants() -> Array:
	var list: Array = []
	if player.alive:
		list.append(player)
	for bot in bots:
		if bot.alive:
			list.append(bot)
	return list

func _refresh_hud() -> void:
	ui.update_alive(get_alive_counts()[0], get_alive_counts()[1])
	ui.update_score(scores)
	ui.update_round(round_number)

func cleanup() -> void:
	_clear_bots()
	phase = "idle"
	match_over = true
