﻿class_name MiniMap
extends Control

## 战术雷达。显示体A/B 包点、队友黑匣，以及玩有线的敌人?
var game
var map
var match_ref
var player
var font: Font

func setup(game_ref, map_ref, match_ref, player_ref, p_font: Font) -> void:
	game = game_ref
	map = map_ref
	player = player_ref
	font = p_font
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	queue_redraw()

func _process(_delta: float) -> void:
	queue_redraw()

func _draw() -> void:
	if map == null or player == null:
		return
	var w = size.x
	var h = size.y
	draw_rect(Rect2(Vector2.ZERO, size), Color("#081014"))
	# 网格
	for i in range(1, 6):
		var x = w * float(i) / 6.0
		draw_line(Vector2(x, 0), Vector2(x, h), Color(0.18, 0.32, 0.36, 0.12), 1.0)
	for i in range(1, 5):
		var y = h * float(i) / 5.0
		draw_line(Vector2(0, y), Vector2(w, y), Color(0.18, 0.32, 0.36, 0.12), 1.0)

	var world_bounds = MapBuilder.MAP_BOUNDS
	var scale_x = w / world_bounds.size.x
	var scale_z = h / world_bounds.size.y
	var origin = Vector2(-world_bounds.position.x, -world_bounds.position.y)
	var to_map = func(p: Vector3) -> Vector2:
		return Vector2((p.x + origin.x) * scale_x, (p.z + origin.y) * scale_z)

	# 墙体与掩体
	for s in map.solids:
		if String(s["kind"]) == "barrier":
			pass
		var pos: Vector3 = s["pos"]
		var sz: Vector3 = s["size"]
		var r = Rect2(
			Vector2((pos.x - sz.x * 0.5 + origin.x) * scale_x, (pos.z - sz.z * 0.5 + origin.y) * scale_z),
			Vector2(maxf(1.0, sz.x * scale_x), maxf(1.0, sz.z * scale_z))
		)
		var color = Color(0.24, 0.33, 0.36, 0.65)
		if String(s["kind"]).begins_with("container"):
			color = Color(0.28, 0.28, 0.24, 0.85)
		elif String(s["kind"]) == "crate":
			color = Color(0.35, 0.33, 0.25, 0.8)
		draw_rect(r, color, true)

	# 包点
	for site in map.sites:
		var c: Vector3 = site["center"]
		var p: Vector2 = to_map.call(c)
		var radius = float(site["radius"]) * scale_x
		var col: Color = site["color"]
		draw_arc(p, radius, 0.0, TAU, 28, Color(col.r, col.g, col.b, 0.7), 1.5)
		draw_string(font, p + Vector2(-4, 4), String(site["id"]), HORIZONTAL_ALIGNMENT_LEFT, -1, 12, col)

	# 黑匣
	if match_ref and match_ref.bomb and match_ref.bomb.state in ["dropped", "planted"]:
		var bp: Vector2 = to_map.call(match_ref.bomb.global_position)
		var blink = 0.55 + sin(Time.get_ticks_msec() * 0.008) * 0.35
		draw_circle(bp, 4.0, Color(1.0, 0.38, 0.1, blink))
		draw_arc(bp, 7.0, 0, TAU, 16, Color(1.0, 0.38, 0.1, blink * 0.7), 1.0)

	# 队友
	if match_ref:
		for bot in match_ref.bots:
			if bot.ally and bot.alive:
				var p: Vector2 = to_map.call(bot.global_position)
				draw_circle(p, 2.8, GameConfig.TEAM[player.team]["color"])
		# 敌人：只画玩家有视线?		for bot in match_ref.bots:
			if not bot.ally and bot.alive:
				if _player_can_see(bot):
					var p: Vector2 = to_map.call(bot.global_position)
					draw_circle(p, 3.0, Color("#ff4d4d"))
					draw_arc(p, 5.5, 0, TAU, 12, Color(1.0, 0.3, 0.2, 0.4), 1.0)

	# 鐜╁绠ご
	var pp: Vector2 = to_map.call(player.global_position)
	var forward: Vector3 = -player.global_transform.basis.z
	var angle = atan2(forward.x, -forward.z) - PI * 0.5
	var points = PackedVector2Array([
		pp + Vector2(cos(angle), sin(angle)) * 8.0,
		pp + Vector2(cos(angle + 2.5), sin(angle + 2.5)) * 5.0,
		pp + Vector2(cos(angle - 2.5), sin(angle - 2.5)) * 5.0,
	])
	draw_colored_polygon(points, GameConfig.TEAM[player.team]["soft"])

	# 杈规
	draw_rect(Rect2(Vector2.ZERO, size), Color(1, 1, 1, 0.07), false, 1.0)

func _player_can_see(bot) -> bool:
	if player == null or not player.alive:
		return false
	var from: Vector3 = player.global_position + Vector3(0, player.eye_height, 0)
	var to: Vector3 = bot.global_position + Vector3(0, 1.2, 0)
	if from.distance_to(to) > 50.0:
		return false
	var query = PhysicsRayQueryParameters3D.create(from, to)
	query.collision_mask = 1
	var hit: Dictionary = player.get_world_3d().direct_space_state.intersect_ray(query)
	return hit.is_empty() or hit["position"].distance_to(from) > from.distance_to(to) - 0.2

