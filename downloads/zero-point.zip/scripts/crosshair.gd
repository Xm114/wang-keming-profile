class_name Crosshair
extends Control

var spread = 6.0
var hit_alpha = 0.0
var hit_kill = false
var _hit_tween: Tween

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	custom_minimum_size = Vector2(64, 64)
	queue_redraw()

func set_spread(value: float) -> void:
	spread = clampf(value, 6.0, 24.0)
	queue_redraw()

func flash_hit(kill = false) -> void:
	hit_kill = kill
	if _hit_tween and _hit_tween.is_valid():
		_hit_tween.kill()
	hit_alpha = 1.0
	queue_redraw()
	_hit_tween = create_tween()
	_hit_tween.tween_method(func(v): hit_alpha = v; queue_redraw(), 1.0, 0.0, 0.22)

func _draw() -> void:
	var center = size * 0.5
	var color = Color(0.96, 0.99, 1.0, 0.9)
	var shadow = Color(0, 0, 0, 0.8)
	var gap = spread
	var length = 8.0
	for offset in [
		[Vector2(0, -1), Vector2(0, -gap)],
		[Vector2(0, 1), Vector2(0, gap)],
		[Vector2(-1, 0), Vector2(-gap, 0)],
		[Vector2(1, 0), Vector2(gap, 0)],
	]:
		var a: Vector2 = center + offset[0] * (gap + length)
		var b: Vector2 = center + offset[0] * (gap - 1.0)
		draw_line(a + Vector2.ONE, b + Vector2.ONE, shadow, 2.0)
		draw_line(a, b, color, 1.0)
	draw_circle(center + Vector2.ONE, 1.5, shadow)
	draw_circle(center, 1.6, Color("#ff6b2c"))
	if hit_alpha > 0.01:
		var c = Color("#ff6b2c") if hit_kill else Color(1, 1, 1, hit_alpha)
		c.a = hit_alpha
		for dir in [Vector2(1, 1), Vector2(-1, 1), Vector2(1, -1), Vector2(-1, -1)]:
			draw_line(center + dir * 8.0, center + dir * 15.0, c, 2.0)
