extends Node3D

## 零点交火 / ZERO POINT
## 原生 Godot 4.7 主控制器：场景装配、比赛生命周期、命中裁决、输入与菜单。
var state = "loading"
var paused = false
var menu_time = 0.0
var menu_camera: Camera3D
var map: MapBuilder
var nav: NavGrid
var audio: AudioBus
var effects: Effects
var player: Player
var bomb: Bomb
var game_match: Match
var ui: GameUI
var settings = {"sensitivity": 1.0, "volume": 0.65, "fov": 78.0}
var pickups: Array[Dictionary] = []
var _pause_live = false
var _fps_time = 0.0
var _fps_frames = 0
var _pickup_prompt = false

var can_control: bool:
	get:
		return (
			state == "playing"
			and not paused
			and game_match != null
			and game_match.phase == "live"
			and not ui.buy_open
			and not ui.manual_layer.visible
			and not ui.settings_layer.visible
			and not game_match.match_over
			and Input.mouse_mode == Input.MOUSE_MODE_CAPTURED
		)

func _ready() -> void:
	randomize()
	_setup_input()
	_load_settings()
	_build_world()
	state = "menu"
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	ui.hide_loading()
	process_priority = 10
	var args := OS.get_cmdline_user_args()
	if args.has("--autostart"):
		get_tree().create_timer(0.4).timeout.connect(func():
			start_match("attack")
			if args.has("--autolive"):
				get_tree().create_timer(0.2).timeout.connect(func(): ready_up())
		)
	var show_index := args.find("--show")
	if show_index >= 0 and show_index + 1 < args.size():
		var screen_name := args[show_index + 1]
		get_tree().create_timer(1.4).timeout.connect(func():
			match screen_name:
				"manual": ui.show_manual(false)
				"settings": ui.show_settings(false)
				"scoreboard": Input.action_press("scoreboard")
				"pause": pause_game()
				"buy": ui.open_buy()
				"end": on_match_end(game_match, true)
		)
	var shot_index := args.find("--shot")
	if shot_index >= 0 and shot_index + 1 < args.size():
		var shot_path := args[shot_index + 1]
		get_tree().create_timer(3.0).timeout.connect(func():
			await RenderingServer.frame_post_draw
			var image := get_viewport().get_texture().get_image()
			image.save_png(shot_path)
			print("Screenshot saved: ", shot_path)
			get_tree().quit()
		)

func _setup_input() -> void:
	_add_key("move_forward", KEY_W)
	_add_key("move_back", KEY_S)
	_add_key("move_left", KEY_A)
	_add_key("move_right", KEY_D)
	_add_key("jump", KEY_SPACE)
	_add_key("sprint", KEY_SHIFT)
	_add_key("crouch", KEY_CTRL)
	_add_key("reload", KEY_R)
	_add_key("inspect", KEY_F)
	_add_key("interact", KEY_E)
	_add_key("buy", KEY_B)
	_add_key("scoreboard", KEY_TAB)
	_add_key("weapon_1", KEY_1)
	_add_key("weapon_2", KEY_2)
	_add_key("weapon_3", KEY_3)
	_add_mouse("fire", MOUSE_BUTTON_LEFT)
	_add_mouse("aim", MOUSE_BUTTON_RIGHT)

func _add_key(action: String, key: Key) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var exists = false
	for ev in InputMap.action_get_events(action):
		if ev is InputEventKey and ev.physical_keycode == key:
			exists = true
	if not exists:
		var event = InputEventKey.new()
		event.physical_keycode = key
		InputMap.action_add_event(action, event)

func _add_mouse(action: String, button: MouseButton) -> void:
	if not InputMap.has_action(action):
		InputMap.add_action(action)
	var exists = false
	for ev in InputMap.action_get_events(action):
		if ev is InputEventMouseButton and ev.button_index == button:
			exists = true
	if not exists:
		var event = InputEventMouseButton.new()
		event.button_index = button
		InputMap.action_add_event(action, event)

func _build_world() -> void:
	map = MapBuilder.new()
	map.name = "ZP01"
	add_child(map)
	map.build()

	nav = NavGrid.new()
	nav.build(MapBuilder.MAP_BOUNDS, map.nav_solids, 0.42, 1.0)

	audio = AudioBus.new()
	add_child(audio)
	audio.set_volume(float(settings["volume"]))

	effects = Effects.new()
	add_child(effects)

	player = Player.new()
	add_child(player)
	player.setup(self)
	player.weapon_holder.visible = false

	bomb = Bomb.new()
	add_child(bomb)
	bomb.setup(self)

	ui = GameUI.new()
	add_child(ui)
	ui.setup(self)

	game_match = Match.new()
	add_child(game_match)
	game_match.setup(self, player, bomb, ui)
	ui.minimap.setup(self, map, game_match, player, ui.font_regular)

	menu_camera = Camera3D.new()
	menu_camera.name = "MenuCamera"
	menu_camera.fov = 55.0
	menu_camera.near = 0.05
	menu_camera.far = 280.0
	add_child(menu_camera)
	menu_camera.current = true
	_update_menu_camera(0.0)

func _load_settings() -> void:
	var config = ConfigFile.new()
	if config.load("user://settings.cfg") == OK:
		settings["sensitivity"] = float(config.get_value("settings", "sensitivity", 1.0))
		settings["volume"] = float(config.get_value("settings", "volume", 0.65))
		settings["fov"] = float(config.get_value("settings", "fov", 78.0))
		settings["knife"] = String(config.get_value("settings", "knife", "tactical"))
		if not GameConfig.KNIVES.has(settings["knife"]):
			settings["knife"] = "tactical"

func save_settings() -> void:
	var config = ConfigFile.new()
	config.set_value("settings", "sensitivity", settings["sensitivity"])
	config.set_value("settings", "volume", settings["volume"])
	config.set_value("settings", "fov", settings["fov"])
	config.set_value("settings", "knife", settings.get("knife", "tactical"))
	config.save("user://settings.cfg")
	if audio:
		audio.set_volume(float(settings["volume"]))

func _unhandled_input(event: InputEvent) -> void:
	if state == "playing" and event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if Input.mouse_mode != Input.MOUSE_MODE_CAPTURED and not paused and not ui.buy_open and not ui.manual_layer.visible and not ui.settings_layer.visible:
			_capture_mouse()
			get_viewport().set_input_as_handled()

func _input(event: InputEvent) -> void:
	if not (event is InputEventKey) or not event.pressed or event.echo:
		return
	match event.physical_keycode:
		KEY_ESCAPE:
			_on_escape()
			get_viewport().set_input_as_handled()
		KEY_B:
			if state == "playing" and paused == false and not ui.manual_layer.visible and not ui.settings_layer.visible:
				if game_match.phase == "buy":
					ui.toggle_buy()
					get_viewport().set_input_as_handled()
				elif game_match.phase == "live":
					ui.toast("军械库仅在购买阶段开放", "info")
		KEY_H:
			if state == "menu":
				ui.show_manual(false)
			elif state == "playing" and paused:
				ui.show_manual(true)
		KEY_F11:
			var w = DisplayServer.window_get_mode()
			DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED if w == DisplayServer.WINDOW_MODE_FULLSCREEN else DisplayServer.WINDOW_MODE_FULLSCREEN)

func _process(delta: float) -> void:
	if state == "menu":
		menu_time += delta
		_update_menu_camera(delta)
		return
	if state == "playing":
		if paused:
			return
		_update_scoreboard()
		_update_fps(delta)
		if game_match and game_match.phase == "live":
			_update_pickups(delta)
			_update_pickup_interaction()
		return

func _update_menu_camera(delta: float) -> void:
	if menu_camera == null:
		return
	menu_time += delta
	var t = menu_time * 0.025
	menu_camera.position = Vector3(31.0 + sin(t) * 1.5, 16.0 + sin(menu_time * 0.17) * 0.35, 33.0 + cos(t) * 1.2)
	menu_camera.look_at(Vector3(-1.0, 1.0, -7.0), Vector3.UP)

func _update_fps(delta: float) -> void:
	_fps_frames += 1
	_fps_time += delta
	if _fps_time >= 0.6:
		ui.set_fps(roundi(_fps_frames / _fps_time))
		_fps_frames = 0
		_fps_time = 0.0

func _update_scoreboard() -> void:
	var show: bool = Input.is_action_pressed("scoreboard") and not paused and not ui.buy_open and not ui.manual_layer.visible and not ui.settings_layer.visible and not game_match.match_over
	if show != ui.scoreboard_layer.visible:
		ui.show_scoreboard(show)

func _on_escape() -> void:
	if state != "playing":
		return
	if ui.manual_layer.visible:
		ui.hide_manual()
		return
	if ui.settings_layer.visible:
		ui.hide_settings()
		return
	if ui.buy_open:
		ui.close_buy()
		return
	if ui.scoreboard_layer.visible:
		ui.show_scoreboard(false)
		return
	if paused:
		resume_game()
	else:
		pause_game()

func _capture_mouse() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	if player:
		player.lock_look(0.25)

func _release_mouse() -> void:
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

# ============================================================
# Match lifecycle
# ============================================================
func start_match(side: String) -> void:
	if state == "playing" or state == "match_end":
		game_match.cleanup()
	paused = false
	state = "playing"
	ui.show_hud()
	ui.show_pause(false)
	ui.show_scoreboard(false)
	menu_camera.current = false
	player.camera.current = true
	player.weapon_holder.visible = true
	game_match.set_process(true)
	var resolved_side = side
	if resolved_side == "random":
		resolved_side = "attack" if randf() < 0.5 else "defense"
	game_match.start_match(resolved_side)
	_release_mouse()

func on_round_started(_match) -> void:
	ui.set_dead(false)
	ui.show_spectate(false)
	ui.show_planted_alert(false)
	ui.set_interaction(null)
	ui.kill_feed_clear()
	clear_pickups()
	ui.open_buy()

func on_live_started(_match) -> void:
	ui.show_spectate(false)
	if not paused and not ui.manual_layer.visible and not ui.settings_layer.visible:
		_capture_mouse()
	_pickup_prompt = false

func on_round_ended(_match, _winner, _reason) -> void:
	ui.set_interaction(null)
	ui.show_planted_alert(false)
	_pickup_prompt = false

func on_buy_opened() -> void:
	_release_mouse()

func on_buy_closed() -> void:
	if state == "playing" and game_match and game_match.phase == "live" and not paused:
		_capture_mouse()

func ready_up() -> void:
	if game_match and game_match.phase == "buy":
		game_match.start_live()
		_capture_mouse()

func pause_game() -> void:
	if state != "playing" or paused:
		return
	_pause_live = game_match.phase == "live"
	paused = true
	game_match.set_process(false)
	game_match.player.set_frozen(true)
	for bot in game_match.bots:
		bot.set_frozen(true)
	ui.show_pause(true)
	ui.show_scoreboard(false)
	_release_mouse()

func resume_game() -> void:
	if state != "playing" or not paused:
		return
	paused = false
	ui.show_pause(false)
	game_match.set_process(true)
	if game_match.phase == "live":
		game_match.player.set_frozen(false)
		for bot in game_match.bots:
			bot.set_frozen(false)
		_capture_mouse()
	elif game_match.phase == "buy":
		_release_mouse()

func return_to_menu() -> void:
	if state == "menu":
		return
	state = "menu"
	paused = false
	game_match.cleanup()
	game_match.set_process(false)
	clear_pickups()
	bomb.reset()
	player.weapon_holder.visible = false
	ui.show_pause(false)
	ui.show_scoreboard(false)
	ui.hide_manual()
	ui.hide_settings()
	ui.show_menu()
	_release_mouse()
	menu_camera.current = true
	menu_time = 0.0
	_update_menu_camera(0.0)

func on_match_end(match_ref, player_won: bool) -> void:
	state = "match_end"
	paused = false
	game_match.set_process(false)
	_release_mouse()
	player.weapon_holder.visible = false
	ui.show_match_end({
		"player_won": player_won,
		"scores": match_ref.scores,
		"stats": player.stats,
		"player_team": player.team,
	})
	ui.show_pause(false)
	ui.show_scoreboard(false)

# ============================================================
# Combat
# ============================================================
func player_melee(shooter, def: Dictionary, origin: Vector3, direction: Vector3) -> void:
	var range_value: float = float(def.get("range", 1.8)) + 0.38
	var flat_dir := Vector3(direction.x, 0.0, direction.z).normalized()
	var best = null
	var best_distance := range_value
	for enemy in get_enemies_of(shooter.team):
		if not is_instance_valid(enemy) or not enemy.alive:
			continue
		var target_point: Vector3 = enemy.global_position + Vector3(0, 1.15, 0)
		var to_target: Vector3 = target_point - origin
		var distance := to_target.length()
		if distance > range_value:
			continue
		var flat_to := Vector3(to_target.x, 0.0, to_target.z).normalized()
		if flat_to.dot(flat_dir) < 0.35:
			continue
		var query := PhysicsRayQueryParameters3D.create(origin, target_point)
		query.collision_mask = 1
		var hit: Dictionary = shooter.get_world_3d().direct_space_state.intersect_ray(query)
		if not hit.is_empty() and hit["position"].distance_to(origin) < distance - 0.1:
			continue
		if distance < best_distance:
			best_distance = distance
			best = enemy
	if best == null:
		return
	var to_attacker: Vector3 = (shooter.global_position - best.global_position).normalized()
	var target_forward: Vector3 = -best.global_transform.basis.z
	var backstab: bool = target_forward.dot(to_attacker) < -0.3
	var damage: float = float(def.get("damage", 55.0)) * (float(def.get("backstab", 3.0)) if backstab else 1.0)
	var was_alive: bool = best.alive
	best.take_damage(damage, shooter, false)
	if shooter == player:
		player.stats["damage"] = int(player.stats["damage"]) + int(damage)
		ui.show_hitmarker(false, not best.alive)
		audio.hit(false)
		if not best.alive and was_alive:
			audio.kill()
	effects.spawn_impact(best.global_position + Vector3(0, 1.15, 0), -direction, "flesh")

func player_fire(shooter, def: Dictionary, origin: Vector3, direction: Vector3) -> void:
	_fire_ray(shooter, def, origin, direction, true)

func bot_fire(shooter, def: Dictionary, origin: Vector3, direction: Vector3) -> void:
	_fire_ray(shooter, def, origin, direction, false)

func _fire_ray(shooter, def: Dictionary, origin: Vector3, direction: Vector3, is_player_shot: bool) -> void:
	var weapon_range: float = float(def.get("range", 80.0))
	var from = origin
	var to = origin + direction.normalized() * weapon_range
	var query = PhysicsRayQueryParameters3D.create(from, to)
	query.collision_mask = 3
	query.collide_with_bodies = true
	query.collide_with_areas = false
	query.exclude = [shooter.get_rid()]
	var result: Dictionary = shooter.get_world_3d().direct_space_state.intersect_ray(query)
	var muzzle: Vector3 = shooter.get_muzzle_position() if shooter.has_method("get_muzzle_position") else shooter.global_position
	if result.is_empty():
		effects.spawn_tracer(muzzle, to, Color("#ffd7a0") if shooter.team == "attack" else Color("#9aeaff"))
		return
	var point: Vector3 = result["position"]
	var collider = result.get("collider")
	effects.spawn_tracer(muzzle, point, Color("#ffd7a0") if shooter.team == "attack" else Color("#9aeaff"))
	if collider == null:
		effects.spawn_impact(point, result.get("normal", Vector3.UP), "hard")
		return
	if collider == shooter or not (collider is Player or collider is Bot):
		effects.spawn_impact(point, result.get("normal", Vector3.UP), "hard")
		return
	if collider.team == shooter.team:
		effects.spawn_impact(point, result.get("normal", Vector3.UP), "hard")
		return
	var headshot: bool = point.y - collider.global_position.y > 1.45
	var distance = origin.distance_to(point)
	var falloff = _damage_falloff(def, distance)
	var damage = maxf(1.0, roundf(float(def.get("damage", 20.0)) * (float(def.get("head_multiplier", 2.0)) if headshot else 1.0) * falloff))
	if not is_player_shot:
		damage = maxf(1.0, roundf(damage * 0.8))
	if is_player_shot:
		player.stats["damage"] = int(player.stats["damage"]) + int(damage)
	var was_alive: bool = collider.alive
	collider.take_damage(damage, shooter, headshot)
	effects.spawn_impact(point, result.get("normal", Vector3.UP), "flesh")
	if is_player_shot:
		ui.show_hitmarker(headshot, not collider.alive)
		audio.hit(headshot)
		if not collider.alive and was_alive:
			audio.play("headshot", -2.0)

func _damage_falloff(def: Dictionary, distance: float) -> float:
	var start = float(def.get("falloff_start", 20.0))
	var end = float(def.get("falloff_end", def.get("range", 80.0)))
	if distance <= start:
		return 1.0
	var t = clampf((distance - start) / maxf(1.0, end - start), 0.0, 1.0)
	return 1.0 - t * 0.45

func on_bot_death(bot, attacker, headshot: bool) -> void:
	if bomb.carrier == bot:
		bomb.drop(bot)
		if bot.team == "attack":
			ui.toast("黑匣掉落！", "danger")
	if game_match.phase == "live":
		_register_kill(attacker, bot, headshot)
		_spawn_pickup(bot)
	ui.update_alive(game_match.get_alive_counts()[0], game_match.get_alive_counts()[1])

func on_player_death(attacker, headshot: bool) -> void:
	if bomb.carrier == player:
		bomb.drop(player)
		ui.toast("你携带的黑匣已掉落", "danger")
	_register_kill(attacker, player, headshot)
	ui.update_alive(game_match.get_alive_counts()[0], game_match.get_alive_counts()[1])

func _register_kill(killer, victim, headshot: bool) -> void:
	if killer == null or killer == victim:
		return
	var weapon_name = "黑匣爆炸"
	if killer == player:
		weapon_name = player.current_weapon_name()
		player.stats["kills"] = int(player.stats["kills"]) + 1
		if headshot:
			player.stats["headshots"] = int(player.stats["headshots"]) + 1
		player.add_money(int(GameConfig.MATCH["kill_reward"]))
		ui.toast("击倒 %s · +₡ %d" % [victim.player_name if victim.is_player else victim.bot_name, int(GameConfig.MATCH["kill_reward"])], "success")
	else:
		weapon_name = String(killer.weapon_def.get("name", "武器"))
		killer.stats["kills"] = int(killer.stats["kills"]) + 1
		if headshot:
			killer.stats["headshots"] = int(killer.stats["headshots"]) + 1
	ui.add_kill_feed({
		"killer_name": killer.player_name if killer.is_player else killer.bot_name,
		"killer_team": killer.team,
		"victim_name": victim.player_name if victim.is_player else victim.bot_name,
		"victim_team": victim.team,
		"weapon": weapon_name,
		"headshot": headshot,
	})

func get_enemies_of(team: String) -> Array:
	var list: Array = []
	if player.alive and player.team != team:
		list.append(player)
	for bot in game_match.bots:
		if bot.alive and bot.team != team:
			list.append(bot)
	return list

func get_spectate_focus(from_player) -> Vector3:
	var best = null
	var best_distance = INF
	for bot in game_match.bots:
		if bot.ally and bot.alive:
			var d: float = bot.global_position.distance_to(from_player.global_position)
			if d < best_distance:
				best_distance = d
				best = bot
	if best:
		return best.global_position
	if bomb.state == "planted":
		return bomb.global_position
	return from_player.global_position

func should_bot_pickup_bomb(bot) -> bool:
	if bomb.state != "dropped" or bot.team != "attack":
		return false
	var best = null
	var best_distance = INF
	for candidate in game_match.get_alive_combatants():
		if candidate.team != "attack":
			continue
		var d: float = candidate.global_position.distance_to(bomb.global_position)
		if d < best_distance:
			best_distance = d
			best = candidate
	return best == bot

func get_site(site_id: String) -> Dictionary:
	return map.get_site(site_id)

func on_bomb_planted(_bomb, actor, site_data: Dictionary) -> void:
	if actor == player:
		player.stats["plants"] = int(player.stats["plants"]) + 1
		player.add_money(int(GameConfig.MATCH["plant_reward"]))
		ui.toast("黑匣已安放 · +₡ %d" % int(GameConfig.MATCH["plant_reward"]), "success")
	ui.show_planted_alert(true)
	ui.set_objective("黑匣已安放于 %s 点 · 拆除或守住" % site_data["id"])
	ui.toast("黑匣已安放于 %s 包点" % site_data["id"], "danger")

func on_bomb_defused(_bomb, actor) -> void:
	if actor == player:
		player.stats["defuses"] = int(player.stats["defuses"]) + 1
		player.add_money(int(GameConfig.MATCH["defuse_reward"]))
		ui.toast("拆除成功 · +₡ %d" % int(GameConfig.MATCH["defuse_reward"]), "success")
	ui.show_planted_alert(false)
	game_match.end_round("defense", "%s 拆除了黑匣炸弹" % (actor.player_name if actor.is_player else actor.bot_name))

func on_bomb_exploded(_bomb) -> void:
	ui.show_planted_alert(false)
	_apply_explosion_damage()
	game_match.end_round("attack", "黑匣炸弹引爆")

func _apply_explosion_damage() -> void:
	var epicenter: Vector3 = bomb.global_position + Vector3(0, 0.8, 0)
	for victim in game_match.get_alive_combatants():
		var chest: Vector3 = victim.get_aim_point(false)
		var distance = chest.distance_to(epicenter)
		if distance > 20.0:
			continue
		var query = PhysicsRayQueryParameters3D.create(epicenter, chest)
		query.collision_mask = 1
		var hit = get_world_3d().direct_space_state.intersect_ray(query)
		var visible: bool = hit.is_empty() or hit["position"].distance_to(epicenter) > epicenter.distance_to(chest) - 0.1
		var factor = pow(clampf(1.0 - distance / 20.0, 0.0, 1.0), 1.55)
		var damage = maxf(2.0, roundf(440.0 * factor * (1.0 if visible else 0.32)))
		var killer = bomb.planted_by
		if killer == victim:
			killer = null
		victim.take_damage(damage, killer, false)

# ============================================================
# Loot
# ============================================================
func _spawn_pickup(bot) -> void:
	var root = Node3D.new()
	root.position = bot.global_position + Vector3(randf_range(-0.3, 0.3), 0.16, randf_range(-0.3, 0.3))
	var body = MeshInstance3D.new()
	var box = BoxMesh.new()
	box.size = Vector3(0.42, 0.18, 0.28)
	body.mesh = box
	var mat = StandardMaterial3D.new()
	mat.albedo_color = Color("#2c3436")
	mat.metallic = 0.65
	mat.roughness = 0.42
	mat.emission_enabled = true
	mat.emission = Color("#ff6b2c")
	mat.emission_energy_multiplier = 0.4
	body.material_override = mat
	root.add_child(body)
	var ring = MeshInstance3D.new()
	var torus = TorusMesh.new()
	torus.inner_radius = 0.35
	torus.outer_radius = 0.46
	torus.rings = 20
	torus.ring_segments = 4
	ring.mesh = torus
	var rmat = StandardMaterial3D.new()
	rmat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	rmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	rmat.albedo_color = Color(1.0, 0.5, 0.2, 0.45)
	rmat.emission_enabled = true
	rmat.emission = Color("#ff7a3d")
	ring.material_override = rmat
	ring.position.y = -0.14
	root.add_child(ring)
	var value = int(randf_range(float(GameConfig.MATCH["pickup_min"]), float(GameConfig.MATCH["pickup_max"])))
	add_child(root)
	pickups.append({"node": root, "ring": ring, "value": value, "name": bot.weapon_def.get("short", "装备"), "life": 30.0, "phase": randf() * TAU})

func _update_pickups(delta: float) -> void:
	for i in range(pickups.size() - 1, -1, -1):
		var p: Dictionary = pickups[i]
		p["life"] = float(p["life"]) - delta
		p["phase"] = float(p["phase"]) + delta * 2.2
		var node: Node3D = p["node"]
		if not is_instance_valid(node):
			pickups.remove_at(i)
			continue
		node.position.y = 0.16 + sin(float(p["phase"])) * 0.07
		node.rotation.y += delta * 1.4
		(p["ring"] as MeshInstance3D).rotation.y += delta * 0.7
		if float(p["life"]) <= 0.0:
			node.queue_free()
			pickups.remove_at(i)

func _update_pickup_interaction() -> void:
	if not player.alive or paused or ui.buy_open:
		if _pickup_prompt:
			ui.set_interaction(null)
			_pickup_prompt = false
		return
	if _has_bomb_interaction():
		return
	var nearest: Dictionary = {}
	var best = 1.9
	for p in pickups:
		var node: Node3D = p["node"]
		if not is_instance_valid(node):
			continue
		var d = Vector2(player.global_position.x - node.global_position.x, player.global_position.z - node.global_position.z).length()
		if d < best:
			best = d
			nearest = p
	if nearest.is_empty():
		if _pickup_prompt:
			ui.set_interaction(null)
			_pickup_prompt = false
		return
	_pickup_prompt = true
	ui.set_interaction({
		"key": "E",
		"label": "回收 %s 装备" % nearest["name"],
		"time": "+₡ %d" % int(nearest["value"]),
		"progress": 0.0,
		"tone": "pickup",
	})
	if Input.is_action_just_pressed("interact"):
		player.add_money(int(nearest["value"]))
		ui.toast("已回收 %s · +₡ %d" % [nearest["name"], int(nearest["value"])], "success")
		audio.buy()
		var node: Node3D = nearest["node"]
		node.queue_free()
		pickups.erase(nearest)
		_pickup_prompt = false
		ui.set_interaction(null)

func _has_bomb_interaction() -> bool:
	if bomb == null:
		return false
	if bomb.state == "carried" and bomb.carrier == player:
		return not map.site_at(player.global_position).is_empty()
	if bomb.state == "dropped" and player.team == "attack":
		return player.global_position.distance_to(bomb.global_position) <= float(GameConfig.MATCH["bomb_pickup_range"])
	if bomb.state == "planted" and player.team == "defense":
		return player.global_position.distance_to(bomb.global_position) <= float(GameConfig.MATCH["defuse_range"]) + 0.4
	return false

func clear_pickups() -> void:
	for p in pickups:
		if is_instance_valid(p["node"]):
			p["node"].queue_free()
	pickups.clear()
	_pickup_prompt = false
