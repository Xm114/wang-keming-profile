class_name WeaponView
extends RefCounted

## 用 assets/data/weapon_layout.json 的部件数据 + assets/textures 下的 PBR 贴图
## 生成第一人称武器视图。数据与贴图同源，改 JSON 或重跑 tools/gen_textures.py 即可。

const LAYOUT_PATH := "res://assets/data/weapon_layout.json"
const TEX_PER_METER := 3.33       # 枪：一张 1024 贴图覆盖约 0.30 m
const KNIFE_TEX_PER_METER := 6.67 # 刀：部件小，一张图约 0.15 m
const DEFAULT_MUZZLE := Vector3(0.0, 0.02, -0.68)
const DEFAULT_VIEW_SCALE := 0.92
const USE_EMISSION := false

## 游戏内视图模型用无光照材质保证夜战可读；
## 离线预览渲染时可以关掉，用真实光照看形体。
static var unshaded_viewmodel := true

static var _layout: Dictionary = {}
static var _loaded := false


static func _ensure_layout() -> void:
	if _loaded:
		return
	_loaded = true
	if not FileAccess.file_exists(LAYOUT_PATH):
		return
	var file := FileAccess.open(LAYOUT_PATH, FileAccess.READ)
	if file == null:
		return
	var parsed = JSON.parse_string(file.get_as_text())
	if parsed is Dictionary:
		_layout = parsed
	file.close()


static func spec(weapon_id: String) -> Dictionary:
	_ensure_layout()
	var weapons: Dictionary = _layout.get("weapons", {})
	if weapons.has(weapon_id):
		return weapons[weapon_id]
	var knives: Dictionary = _layout.get("knives", {})
	if knives.has(weapon_id):
		return knives[weapon_id]
	var props: Dictionary = _layout.get("props", {})
	return props.get(weapon_id, {})


static func view_scale() -> float:
	_ensure_layout()
	return float(_layout.get("view_scale", DEFAULT_VIEW_SCALE))


static func muzzle_offset(weapon_id: String, scale_factor: float) -> Vector3:
	var s := spec(weapon_id)
	var m: Array = s.get("muzzle", [])
	if m.size() != 3:
		return DEFAULT_MUZZLE * (scale_factor / DEFAULT_VIEW_SCALE)
	return Vector3(float(m[0]), float(m[1]), float(m[2])) * scale_factor


static func view_transform(weapon_id: String) -> Dictionary:
	var s := spec(weapon_id)
	var v: Dictionary = s.get("view", {})
	var pos_array: Array = v.get("pos", [0.26, -0.17, -0.72])
	var rot_array: Array = v.get("rot", [0.0, 7.0, 2.0])
	var ads_array: Array = v.get("ads", [0.0, -0.10, -0.44])
	return {
		"pos": Vector3(float(pos_array[0]), float(pos_array[1]), float(pos_array[2])),
		"rot": Vector3(float(rot_array[0]), float(rot_array[1]), float(rot_array[2])),
		"ads": Vector3(float(ads_array[0]), float(ads_array[1]), float(ads_array[2])),
	}


static func _texture_path(tex_id: String, map_name: String) -> String:
	var kind := "weapons"
	if _is_knife(tex_id):
		kind = "knives"
	elif _is_prop(tex_id):
		kind = "props"
	return "res://assets/textures/%s/%s/%s.png" % [kind, tex_id, map_name]


static func _is_gun(weapon_id: String) -> bool:
	_ensure_layout()
	return (_layout.get("weapons", {}) as Dictionary).has(weapon_id)


static func _is_knife(tex_id: String) -> bool:
	_ensure_layout()
	var base := tex_id.trim_suffix("_grip")
	return (_layout.get("knives", {}) as Dictionary).has(base)


static func _is_prop(tex_id: String) -> bool:
	_ensure_layout()
	return (_layout.get("props", {}) as Dictionary).has(tex_id)


static func _role_params(role: String) -> Dictionary:
	# gl_compatibility 下没有环境反射，金属度过高会发灰发白，统一压低
	match role:
		"barrel":
			return {"tint": Color(1.45, 1.45, 1.48), "metallic": 0.20, "roughness": 1.20}
		"polymer":
			return {"tint": Color(1.22, 1.23, 1.25), "metallic": 0.05, "roughness": 1.35}
		"rubber":
			return {"tint": Color(0.88, 0.88, 0.90), "metallic": 0.02, "roughness": 1.55}
		"wood":
			return {"tint": Color(1.60, 1.16, 0.86), "metallic": 0.0, "roughness": 1.30}
		"metal":
			return {"tint": Color(1.52, 1.52, 1.55), "metallic": 0.18, "roughness": 1.22}
		"blade":
			return {"tint": Color(0.92, 0.95, 0.99), "metallic": 0.25, "roughness": 0.90}
		"edge":
			return {"tint": Color(1.55, 1.60, 1.65), "metallic": 0.30, "roughness": 0.70}
		"guard":
			return {"tint": Color(0.70, 0.72, 0.75), "metallic": 0.22, "roughness": 1.05}
		"handle":
			return {"tint": Color(1.15, 1.15, 1.15), "metallic": 0.04, "roughness": 1.30}
		_:
			return {"tint": Color(1.55, 1.55, 1.58), "metallic": 0.15, "roughness": 1.25}


static func make_material(tex_id: String, role: String, team_color: Color, uv_scale: Vector3) -> Material:
	var material := StandardMaterial3D.new()

	if role == "accent":
		material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		material.albedo_color = team_color
		material.emission_enabled = true
		material.emission = team_color
		material.emission_energy_multiplier = 1.7
		return material

	if role == "glass":
		# 镜片必须通透：低 alpha + 双面渲染，否则瞄准时会看到一块实心板
		material.albedo_color = Color(0.42, 0.58, 0.62, 0.16)
		material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		material.cull_mode = BaseMaterial3D.CULL_DISABLED
		material.roughness = 0.05
		material.metallic = 0.0
		material.emission_enabled = true
		material.emission = Color(0.20, 0.45, 0.52)
		material.emission_energy_multiplier = 0.12
		return material

	if role == "dot":
		# 红点镜的发光点
		material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		material.albedo_color = Color(1.0, 0.16, 0.10)
		material.emission_enabled = true
		material.emission = Color(1.0, 0.12, 0.06)
		material.emission_energy_multiplier = 3.0
		return material

	var params := _role_params(role)
	material.albedo_color = params["tint"]
	material.metallic = float(params["metallic"])
	material.roughness = float(params["roughness"])
	material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_LINEAR_WITH_MIPMAPS_ANISOTROPIC

	var albedo_path := _texture_path(tex_id, "albedo")
	if not ResourceLoader.exists(albedo_path):
		return material

	material.albedo_texture = load(albedo_path)

	var roughness_path := _texture_path(tex_id, "roughness")
	if ResourceLoader.exists(roughness_path):
		material.roughness_texture = load(roughness_path)

	var metallic_path := _texture_path(tex_id, "metallic")
	if ResourceLoader.exists(metallic_path):
		material.metallic_texture = load(metallic_path)

	var normal_path := _texture_path(tex_id, "normal")
	if ResourceLoader.exists(normal_path):
		material.normal_enabled = true
		material.normal_texture = load(normal_path)
		material.normal_scale = 0.85

	var emission_path := _texture_path(tex_id, "emission")
	if USE_EMISSION and not unshaded_viewmodel and ResourceLoader.exists(emission_path):
		material.emission_enabled = true
		material.emission_texture = load(emission_path)
		material.emission = Color.WHITE
		material.emission_energy_multiplier = 1.25

	# 视图模型统一走无光照材质：夜间场景里普通材质几乎全黑，而且手上这把枪不该被
	# 场景灯光随机打亮/打暗。贴图本身已经烘了板面、磨损和贴花，无光照下依然有层次。
	if unshaded_viewmodel:
		material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
		material.albedo_color = params["tint"] * 0.40
		material.roughness = 1.0
		material.metallic = 0.0
	else:
		material.albedo_color = params["tint"] * 0.85
		material.emission_enabled = true
		material.emission = Color(0.13, 0.135, 0.14)
		material.emission_energy_multiplier = 1.0

	material.uv1_scale = Vector3(
		maxf(0.08, uv_scale.x),
		maxf(0.08, uv_scale.y),
		maxf(0.08, uv_scale.z)
	)
	return material


static func _box_mesh(size: Vector3, tex_per_meter: float) -> ArrayMesh:
	## 自己生成盒体并写入逐面 UV：Godot 的 BoxMesh 每个面都是 0..1，
	## 直接乘 uv1_scale 会让不同尺寸的面拉伸不一致。
	var surface := SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	var h := size * 0.5
	# normal, u 轴, v 轴（满足 u × v = normal，保证朝外）
	var faces := [
		[Vector3(1, 0, 0), Vector3(0, 0, -1), Vector3(0, 1, 0)],
		[Vector3(-1, 0, 0), Vector3(0, 0, 1), Vector3(0, 1, 0)],
		[Vector3(0, 1, 0), Vector3(1, 0, 0), Vector3(0, 0, -1)],
		[Vector3(0, -1, 0), Vector3(1, 0, 0), Vector3(0, 0, 1)],
		[Vector3(0, 0, 1), Vector3(1, 0, 0), Vector3(0, 1, 0)],
		[Vector3(0, 0, -1), Vector3(-1, 0, 0), Vector3(0, 1, 0)],
	]
	for face in faces:
		var normal: Vector3 = face[0]
		var u_axis: Vector3 = face[1]
		var v_axis: Vector3 = face[2]
		var center := normal * absf(normal.dot(h))
		var half_u := u_axis * absf(u_axis.dot(h))
		var half_v := v_axis * absf(v_axis.dot(h))
		var uv_u := half_u.length() * 2.0 * tex_per_meter
		var uv_v := half_v.length() * 2.0 * tex_per_meter
		var corners := [
			center - half_u - half_v,
			center + half_u - half_v,
			center + half_u + half_v,
			center - half_u + half_v,
		]
		var uvs := [Vector2(0, 0), Vector2(uv_u, 0), Vector2(uv_u, uv_v), Vector2(0, uv_v)]
		var order := [0, 2, 1, 0, 3, 2]  # Godot 前向面为顺时针
		for index in order:
			surface.set_normal(normal)
			surface.set_uv(uvs[index])
			surface.add_vertex(corners[index])
	return surface.commit()


static func _poly_mesh(profile: Array, thick: float, tex_per_meter: float) -> ArrayMesh:
	## 把 ZY 平面（侧视）上的闭合轮廓沿 X 挤出成刀身：
	## 能做出真刀尖、鹰嘴弧刃、不对称刃型，而不是一根方条。
	var surface := SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	var count := profile.size()
	if count < 3:
		return null
	var half := thick * 0.5

	var points: Array[Vector2] = []
	for item in profile:
		points.append(Vector2(float(item[0]), float(item[1])))  # (z, y)

	var centroid := Vector2.ZERO
	for point in points:
		centroid += point
	centroid /= float(count)

	for sign_x in [1.0, -1.0]:
		var sx: float = sign_x
		var normal := Vector3(sx, 0, 0)
		var x := half * sx
		for i in range(count):
			var a := points[i]
			var b := points[(i + 1) % count]
			var va := Vector3(x, centroid.y, centroid.x)
			var vb := Vector3(x, a.y, a.x)
			var vc := Vector3(x, b.y, b.x)
			if sx > 0.0:
				_triangle(surface, va, vc, vb, normal, tex_per_meter)
			else:
				_triangle(surface, va, vb, vc, normal, tex_per_meter)

	for i in range(count):
		var a := points[i]
		var b := points[(i + 1) % count]
		var edge := b - a
		var normal := Vector3(0.0, -edge.x, edge.y).normalized()
		var v0 := Vector3(-half, a.y, a.x)
		var v1 := Vector3(half, a.y, a.x)
		var v2 := Vector3(half, b.y, b.x)
		var v3 := Vector3(-half, b.y, b.x)
		_triangle(surface, v0, v1, v2, normal, tex_per_meter)
		_triangle(surface, v0, v2, v3, normal, tex_per_meter)

	return surface.commit()


static func _triangle(surface: SurfaceTool, a: Vector3, b: Vector3, c: Vector3,
		normal: Vector3, tex_per_meter: float) -> void:
	for vertex in [a, b, c]:
		surface.set_normal(normal)
		surface.set_uv(Vector2(vertex.z, vertex.y) * tex_per_meter)
		surface.add_vertex(vertex)


static func build(weapon_id: String, team_color: Color) -> Node3D:
	var s := spec(weapon_id)
	if s.is_empty():
		return null
	var parts: Array = s.get("parts", [])
	if parts.is_empty():
		return null

	var root := Node3D.new()
	root.name = "Gun"
	# 刀的部件很小，用更密的贴图密度，不然护手/柄尾会糊成一团
	var density := KNIFE_TEX_PER_METER if _is_knife(weapon_id) else TEX_PER_METER

	for part in parts:
		var info: Dictionary = part
		var role := String(info.get("m", "body"))
		var instance := MeshInstance3D.new()
		instance.name = String(info.get("n", "part"))
		var uv := Vector3.ONE
		var shape := String(info.get("s", "box"))

		if shape == "box":
			var size_array: Array = info.get("sz", [0.1, 0.1, 0.1])
			var size := Vector3(float(size_array[0]), float(size_array[1]), float(size_array[2]))
			instance.mesh = _box_mesh(size, density)
			uv = Vector3.ONE
		elif shape == "poly":
			var profile: Array = info.get("profile", [])
			var blade_thick := float(info.get("thick", 0.006))
			instance.mesh = _poly_mesh(profile, blade_thick, density)
			uv = Vector3.ONE
		elif shape == "torus":
			var inner := float(info.get("inner", 0.02))
			var thickness := float(info.get("thick", 0.008))
			var torus := TorusMesh.new()
			torus.inner_radius = inner
			torus.outer_radius = inner + thickness
			torus.rings = 20
			torus.ring_segments = 8
			instance.mesh = torus
			uv = Vector3(TAU * inner, TAU * thickness, 1.0) * density
		elif shape == "tube":
			# 镜筒：开口圆管，两端不封盖，双面渲染，瞄准时能直接看穿
			var tube_radius := float(info.get("rad", 0.028))
			var tube_height := float(info.get("h", 0.26))
			var tube := CylinderMesh.new()
			tube.top_radius = tube_radius
			tube.bottom_radius = tube_radius
			tube.height = tube_height
			tube.radial_segments = 24
			tube.rings = 1
			tube.cap_top = false
			tube.cap_bottom = false
			instance.mesh = tube
			uv = Vector3(TAU * tube_radius, tube_height, 1.0) * density
		else:
			var radius := float(info.get("rad", 0.01))
			var height := float(info.get("h", 0.1))
			var cylinder := CylinderMesh.new()
			cylinder.top_radius = radius
			cylinder.bottom_radius = radius
			cylinder.height = height
			cylinder.radial_segments = 18
			cylinder.rings = 1
			instance.mesh = cylinder
			uv = Vector3(TAU * radius, height, 1.0) * density

		# 刀柄用单独一套贴图（刃材和柄材差别太大）
		var tex_id := weapon_id + "_grip" if role == "handle" else weapon_id
		instance.material_override = make_material(tex_id, role, team_color, uv)

		# 镜筒内外都要能看到，否则从目镜看进去还是一片黑
		if shape == "tube":
			var tube_mat := (instance.material_override as StandardMaterial3D).duplicate() as StandardMaterial3D
			tube_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
			instance.material_override = tube_mat
		# 视图模型不应往场景里投影，否则会在地面出现一把"1 米小枪"的影子
		instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF

		var pos_array: Array = info.get("p", [0, 0, 0])
		instance.position = Vector3(float(pos_array[0]), float(pos_array[1]), float(pos_array[2]))
		var rot_array: Array = info.get("rot", [0, 0, 0])
		instance.rotation_degrees = Vector3(
			float(rot_array[0]), float(rot_array[1]), float(rot_array[2])
		)
		root.add_child(instance)

	return root
