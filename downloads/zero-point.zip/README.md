# 零点交火 / ZERO POINT

> 5V5 战术爆破 FPS · Godot 4.7.2 原生项目 · 可导出 Windows EXE

`零点交火` 是一个从零搭建的 5V5 爆破模式原型：
进攻方携带黑匣炸弹，在 A / B 包点完成 10 秒安放；炸弹引爆倒计时 40 秒；
防守方可以拆除炸弹、拖满回合，或全歼进攻方。先取 6 分获胜，第 6 回合后换边；每局攻防随机分配，回合时限 1 分 30 秒。

项目已从最初的 Web 原型切换为 **Godot 4.7.2 原生工程**，不再使用 HTML / 浏览器运行。
当前版本是可玩的框架：规则、AI、经济、HUD 齐全；**6 把枪与 C4 已经换上了按真实比例建模 + 程序化
PBR 贴图的第一人称模型**，地图与干员仍是灰盒。素材规范见 [素材接入](docs/ASSETS.md)，
贴图怎么生成的见 [贴图管线](docs/TEXTURES.md)。

![主菜单](docs/screenshots/menu.png)

## 运行

最快方式：**双击 `启动游戏.bat`**，会直接用本机 Godot 4.7.2 打开工程。

环境：**Godot 4.7.2**（本机路径 `C:\Users\HP\Desktop\AI\godot\bin\Godot_v4.7.2-stable_win64.exe`）。

1. 打开 Godot → 导入 → 选择本目录的 `project.godot`。
2. 按 **F5** 运行；首次打开请等待几秒让 Godot 完成导入。
3. 或命令行运行：

```powershell
& "C:\Users\HP\Desktop\AI\godot\bin\Godot_v4.7.2-stable_win64.exe" --path "C:\Users\HP\Desktop\DeepSeek\零点交火"
```

> 当前机器没有安装 Godot 导出模板，因此暂未生成 EXE；在 Godot 中
> **项目 → 导出 → Windows Desktop** 添加模板后即可导出。导出配置和素材路径已经按原生工程组织。

## 操作

| 键位 | 功能 |
| --- | --- |
| `W A S D` | 移动 |
| `Shift` / `Ctrl` | 冲刺 / 蹲伏 |
| `Space` | 跳跃 |
| 鼠标左键 / 右键 | 射击 / 瞄准 |
| `R` | 换弹 |
| `E` | 安放 / 拆除 / 拾取 / 回收 |
| `1` / `2` / `3` | 主武器 / 副武器 / 近战刀 |
| `B` | 购买阶段打开军械库 |
| `Tab` | 按住查看计分板 |
| `Esc` | 暂停 / 关闭当前面板 |
| `H` | 打开作战手册（菜单或暂停中） |

## 已实现

- **5V5 回合**：本地玩家 + 4 名 AI 队友，对 5 名 AI；先取 6 分，6 回合后攻守交换，最多 11 回合。
- **黑匣炸弹**：携带 / 掉落 / 拾取 / 安放 10 秒 / 引爆 40 秒 / 拆除 10 秒（拆弹器 5 秒）。
  安放与拆除需要站定；移动或受击会打断并清空进度。
- **经济系统**：每回合 10,000 信用点；每回合购买阶段 10 秒；主武器、护甲、拆弹器、弹药；所有配件免费；击杀掉落装备，
  靠近按 `E` 回收换取信用点。
- **军械库**：4 把主武器 + 2 把副武器；瞄具 / 枪管 / 握把 / 弹匣四组免费改装；实时数值预览。
- **近战刀**：3 号位装备刀；五种刀型（经典匕首 / 蝴蝶刀 / 爪子刀 / 刺刀 / 折叠刀）只在主菜单选择，进入对局后不能更换刀型，背刺造成额外伤害。
- **武器系统**：全自动 / 半自动 / 泵动、射速、弹匣、换弹、开镜、散布、后坐力、距离衰减、爆头、
  护甲吸收、霰弹多弹丸、切枪。
- **第一人称控制**：鼠标锁定、冲刺、蹲伏、跳跃、镜头晃动、武器摆动 / 后坐 / 换弹动作、死亡观战。
- **Bot AI**：A* 栅格寻路、到点后随机游走 / 换位、绕墙不站桩、视线检测、遇敌开火；反应与命中强度已下调，不会见面秒人。
- **HUD**：比分、回合钟、人数、雷达、击杀信息、血量护甲、弹药、目标提示、安放/拆除进度、回合横幅。
- **菜单与流程**：主菜单、购买、暂停、作战手册、设置、计分板、回合结算、比赛结算。
- **程序化占位音效**：枪声、命中、换弹、C4 蜂鸣、拆除、爆炸、UI 提示（WebAudio 风格的 Godot 合成器）。

![游戏画面](docs/screenshots/game.png)

## 工程结构

```
project.godot                Godot 4.7 工程配置
scenes/main.tscn             唯一入口场景（其余节点由代码构建）
scripts/
  main.gd                    总装 / 生命周期 / 命中裁决 / 主菜单回调
  game_config.gd             规则、武器、配件、经济数据
  map_builder.gd             零点电站灰盒地图、碰撞、灯光、站点
  nav_grid.gd                A* 栅格导航
  player.gd                  第一人称控制器与武器视图模型
  bot.gd                     5V5 Bot AI / 模型 / 战斗
  match.gd                   回合、比分、换边、Buy 流程
  bomb.gd                    黑匣炸弹状态机
  ui.gd                      菜单 / HUD / 军械库 / 结算
  minimap.gd                 战术雷达
  crosshair.gd               动态准星
  weapon_preview.gd          军械库武器结构预览
  map_diagram.gd             菜单战术地图
  effects.gd                 弹道 / 命中 / 爆炸
  audio_bus.gd               程序化音频
  asset_registry.gd          素材槽位解析（预留）
assets/                      后续素材目录，见 docs/ASSETS.md
docs/                        设计说明、素材规范、截图
```

## 已知边界（本版是框架，不是最终成品）

- 目前是 **本地 BOT 对战**，没有联网 5v5 同步；`Match` / `Bot` / `Bomb` 的接口已经按可拆分服务端逻辑设计，
  但联机层尚未实现。
- 干员技能、枪械精细 GLB 模型、动画、真实音效均为下一阶段素材接入内容；
  枪械目前是「真实比例的低模 + 程序化 PBR 贴图」，见 [贴图管线](docs/TEXTURES.md)。
- 导航使用自定义 A* 栅格；换成复杂美术地图后，可替换为 Godot `NavigationRegion3D`。
- 没有安装导出模板，所以还没有 `EXE`；打开工程即可直接运行。

## 开发调试参数

```powershell
# 自动进入对局并跳到行动阶段（用于快速看 HUD / 场景）
& $godot --path . -- --autostart --autolive

# 自动进对局并截图后退出
& $godot --path . -- --autostart --autolive --shot "C:\path\shot.png"

# 只截主菜单
& $godot --path . -- --shot "C:\path\menu.png"

# 显示指定界面：manual / settings / scoreboard / pause / buy / end
& $godot --path . -- --autostart --autolive --show scoreboard
```

## 下一步建议

1. 先替换 **1 张地图** 的灰盒体块与材质（保留 `MapBuilder.solids` 的 AABB 数据，或改为 NavMesh）。
2. 替换 **玩家/Bot 模型**；枪械若要升级为精细 GLB，直接替换 `WeaponView.build()` 的网格来源即可，
   贴图与 UV 密度（约 0.30 m 一张）可以沿用。
3. 接入真实枪声 / 脚步 / C4 音效，保留 `AudioBus` 的调用接口。
4. 添加干员技能（侦察 / 突破 / 支援）与更细的攻防默认站位。
5. 安装导出模板，导出 Windows EXE。
