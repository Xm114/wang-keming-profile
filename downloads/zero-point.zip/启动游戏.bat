@echo off
setlocal
set "GODOT=C:\Users\HP\Desktop\AI\godot\bin\Godot_v4.7.2-stable_win64.exe"
if not exist "%GODOT%" goto missing
start "" "%GODOT%" --path "%~dp0." --resolution 1600x900 --log-file "%~dp0launcher.log"
exit /b 0
:missing
echo Godot executable not found:
echo %GODOT%
pause
exit /b 1
