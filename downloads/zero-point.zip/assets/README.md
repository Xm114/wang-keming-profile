# assets

素材存放目录。当前为空，游戏完全使用程序化灰盒与合成音效。

- `models/weapons/`：枪械 GLB
- `models/characters/`：干员 GLB
- `models/props/`：集装箱、掩体、终端、C4
- `textures/`：可平铺贴图
- `audio/`：枪声、脚步、C4、爆炸
- `ui/`：Logo、菜单背景

详细规范见 [`docs/ASSETS.md`](../docs/ASSETS.md)。
