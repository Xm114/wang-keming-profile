const scoreEl = document.querySelector("#score");
const rankEl = document.querySelector("#rank");
const fishEl = document.querySelector("#fish");
const fishStageEl = document.querySelector("#fishStage");
const nextTitleEl = document.querySelector("#nextTitle");
const progressBarEl = document.querySelector("#progressBar");
const resetEl = document.querySelector("#reset");
const toastEl = document.querySelector("#toast");
const milestoneEls = Array.from(document.querySelectorAll(".milestone"));
const rebirthCountEl = document.querySelector("#rebirthCount");
const multiplierEl = document.querySelector("#multiplier");
const rebirthNeedEl = document.querySelector("#rebirthNeed");
const rebirthEl = document.querySelector("#rebirth");
const autoKeyEl = document.querySelector("#autoKey");
const autoInfoEl = document.querySelector("#autoInfo");
const rebirthDialogEl = document.querySelector("#rebirthDialog");
const rebirthMessageEl = document.querySelector("#rebirthMessage");
const confirmRebirthEl = document.querySelector("#confirmRebirth");
const adminToggleEl = document.querySelector("#adminToggle");
const adminPanelEl = document.querySelector("#adminPanel");
const adminPasswordDialogEl = document.querySelector("#adminPasswordDialog");
const adminPasswordFormEl = document.querySelector("#adminPasswordForm");
const adminPasswordEl = document.querySelector("#adminPassword");
const adminPasswordHintEl = document.querySelector("#adminPasswordHint");
const adminPasswordCancelEl = document.querySelector("#adminPasswordCancel");
const adminScoreEl = document.querySelector("#adminScore");
const adminRebirthsEl = document.querySelector("#adminRebirths");
const adminMultiplierEl = document.querySelector("#adminMultiplier");
const adminAutoEnabledEl = document.querySelector("#adminAutoEnabled");
const adminApplyEl = document.querySelector("#adminApply");
const adminDefaultMultiplierEl = document.querySelector("#adminDefaultMultiplier");

const legacyScoreKey = "moyu-game-score";
const stateKey = "moyu-game-state-v2";
const adminPassword = "132547";
const baseRebirthNeed = 1000;
const ranks = [
  { value: 100, name: "摸鱼小新手", className: "rank-novice" },
  { value: 1000, name: "摸鱼小能手", className: "rank-adept" },
  { value: 10000, name: "摸鱼老手", className: "rank-veteran" },
  { value: 50000, name: "摸鱼大师", className: "rank-master" },
  { value: 100000, name: "摸鱼王者", className: "rank-king" },
  { value: 500000, name: "摸鱼界的大佬！", className: "rank-boss" },
  { value: 1000000, name: "闲得发慌", className: "rank-egg", egg: true }
];

let state = loadState();
let adminMode = false;
let toastTimer = 0;
let autoTimer = 0;

function loadState() {
  const fallbackScore = Number(localStorage.getItem(legacyScoreKey) || 0);
  try {
    const parsed = JSON.parse(localStorage.getItem(stateKey) || "{}");
    return normalizeState({
      score: parsed.score ?? fallbackScore,
      rebirths: parsed.rebirths ?? 0,
      autoEnabled: parsed.autoEnabled ?? false,
      multiplierOverride: parsed.multiplierOverride ?? null
    });
  } catch {
    return normalizeState({
      score: fallbackScore,
      rebirths: 0,
      autoEnabled: false,
      multiplierOverride: null
    });
  }
}

function normalizeState(value) {
  const override = Number(value.multiplierOverride);
  return {
    score: Math.max(0, Number(value.score) || 0),
    rebirths: Math.max(0, Math.floor(Number(value.rebirths) || 0)),
    autoEnabled: Boolean(value.autoEnabled),
    multiplierOverride: Number.isFinite(override) && override > 0 ? override : null
  };
}

function saveState() {
  state = normalizeState(state);
  localStorage.setItem(stateKey, JSON.stringify(state));
  localStorage.setItem(legacyScoreKey, String(state.score));
}

function getDefaultMultiplier() {
  return 1 + state.rebirths;
}

function getMultiplier() {
  return state.multiplierOverride ?? getDefaultMultiplier();
}

function getRebirthNeed() {
  return baseRebirthNeed * 2 ** state.rebirths;
}

function getAutoRate() {
  return state.rebirths >= 3 ? 5 + (state.rebirths - 3) : 0;
}

function getCurrentRank(value) {
  return ranks.reduce((current, rank) => (value >= rank.value ? rank : current), null);
}

function getNextRank(value) {
  return ranks.find((rank) => value < rank.value) || null;
}

function formatNumber(value) {
  const fractionDigits = Number.isInteger(value) ? 0 : 1;
  return new Intl.NumberFormat("zh-CN", {
    maximumFractionDigits: fractionDigits,
    minimumFractionDigits: fractionDigits
  }).format(value);
}

function formatMultiplier(value) {
  return `x${Number.isInteger(value) ? value : value.toFixed(1)}`;
}

function isTypingTarget(target) {
  const tag = target?.tagName?.toLowerCase();
  return tag === "input" || tag === "textarea" || tag === "select" || target?.isContentEditable;
}

function updateView(previousScore = state.score) {
  const currentRank = getCurrentRank(state.score);
  const previousRank = getCurrentRank(previousScore);
  const nextRank = getNextRank(state.score);
  const autoRate = getAutoRate();

  scoreEl.textContent = formatNumber(state.score);
  rebirthCountEl.textContent = formatNumber(state.rebirths);
  multiplierEl.textContent = formatMultiplier(getMultiplier());
  rebirthNeedEl.textContent = formatNumber(getRebirthNeed());

  rankEl.className = `rank ${currentRank ? currentRank.className : "rank-none"}`;
  rankEl.textContent = currentRank ? currentRank.name : "暂无称号";

  milestoneEls.forEach((item, index) => {
    item.classList.toggle("active", state.score >= ranks[index].value);
    if (ranks[index].egg) {
      item.textContent = state.score >= ranks[index].value
        ? `${formatNumber(ranks[index].value)} · ${ranks[index].name}`
        : `${formatNumber(ranks[index].value)} · [彩蛋称号]`;
    }
  });

  if (nextRank) {
    const previousGate = currentRank ? currentRank.value : 0;
    const span = nextRank.value - previousGate;
    const gained = state.score - previousGate;
    const percent = Math.max(0, Math.min(100, (gained / span) * 100));
    progressBarEl.style.width = `${percent}%`;
    nextTitleEl.textContent = nextRank.egg
      ? "彩蛋称号隐藏中"
      : `距离「${nextRank.name}」还差 ${formatNumber(nextRank.value - state.score)}`;
  } else {
    progressBarEl.style.width = "100%";
    nextTitleEl.textContent = "彩蛋称号已解锁";
  }

  if (state.rebirths < 3) {
    autoKeyEl.disabled = true;
    autoInfoEl.textContent = `重生 3 次后解锁自动按键，还差 ${formatNumber(3 - state.rebirths)} 次`;
  } else {
    autoKeyEl.disabled = false;
    autoInfoEl.textContent = `自动按键速度：${formatNumber(autoRate)} 次/s`;
  }

  autoKeyEl.classList.toggle("active", state.autoEnabled && state.rebirths >= 3);
  autoKeyEl.setAttribute("aria-pressed", String(state.autoEnabled && state.rebirths >= 3));
  autoKeyEl.textContent = state.autoEnabled && state.rebirths >= 3 ? "关闭自动按键" : "自动按键";

  if (adminMode) {
    fillAdminPanel();
  }

  if (currentRank && currentRank !== previousRank) {
    showToast(`获得称号：${currentRank.name}`);
  }
}

function fillAdminPanel() {
  adminScoreEl.value = String(Math.round(state.score * 10) / 10);
  adminRebirthsEl.value = String(state.rebirths);
  adminMultiplierEl.value = String(Math.round(getMultiplier() * 10) / 10);
  adminAutoEnabledEl.checked = state.autoEnabled && state.rebirths >= 3;
}

function showToast(message) {
  window.clearTimeout(toastTimer);
  toastEl.textContent = message;
  toastEl.classList.add("show");
  toastTimer = window.setTimeout(() => {
    toastEl.classList.remove("show");
  }, 1800);
}

function addPoint(event, options = {}) {
  const previousScore = state.score;
  const amount = getMultiplier();
  state.score += amount;
  saveState();
  updateView(previousScore);
  spawnPoint(event, { ...options, amount });
}

function spawnPoint(event, options = {}) {
  const stageRect = fishStageEl.getBoundingClientRect();
  const fishRect = fishEl.getBoundingClientRect();
  const point = document.createElement("span");
  const isKeyboard = options.source === "keyboard" || options.source === "auto";
  let x = event?.clientX ? event.clientX - stageRect.left : stageRect.width / 2;
  let y = event?.clientY ? event.clientY - stageRect.top : stageRect.height / 2;

  if (isKeyboard) {
    const insetX = Math.min(34, fishRect.width * 0.12);
    const insetY = Math.min(28, fishRect.height * 0.16);
    const minX = fishRect.left - stageRect.left + insetX;
    const maxX = fishRect.right - stageRect.left - insetX;
    const minY = fishRect.top - stageRect.top + insetY;
    const maxY = fishRect.bottom - stageRect.top - insetY;
    x = minX + Math.random() * Math.max(1, maxX - minX);
    y = minY + Math.random() * Math.max(1, maxY - minY);
  }

  point.className = "pop";
  point.textContent = `+${formatNumber(options.amount ?? 1)}`;
  point.style.setProperty("--x", `${Math.max(24, Math.min(stageRect.width - 24, x))}px`);
  point.style.setProperty("--y", `${Math.max(24, Math.min(stageRect.height - 24, y))}px`);
  fishStageEl.append(point);
  point.addEventListener("animationend", () => point.remove(), { once: true });
}

function openRebirthDialog() {
  const need = getRebirthNeed();
  const canRebirth = state.score >= need;
  confirmRebirthEl.disabled = !canRebirth;
  rebirthMessageEl.textContent = canRebirth
    ? `当前摸鱼值已满足 ${formatNumber(need)}。重生后摸鱼值清零，重生次数 +1，摸鱼倍率提升到 ${formatMultiplier(getMultiplier() + 1)}，下次重生需求翻倍。`
    : `当前摸鱼值不足。重生需要 ${formatNumber(need)} 摸鱼值，你还差 ${formatNumber(need - state.score)}。`;
  rebirthDialogEl.showModal();
}

function confirmRebirth() {
  const need = getRebirthNeed();
  if (state.score < need) {
    showToast("摸鱼值不足，无法重生");
    updateView();
    return;
  }

  state.score = 0;
  state.rebirths += 1;
  if (state.multiplierOverride !== null) {
    state.multiplierOverride += 1;
  }
  saveState();
  updateView();
  syncAutoTimer();
  rebirthDialogEl.close();
  showToast(`重生成功！当前倍率 ${formatMultiplier(getMultiplier())}`);
}

function toggleAutoKey() {
  if (state.rebirths < 3) {
    showToast("重生 3 次后才能使用自动按键");
    updateView();
    return;
  }

  state.autoEnabled = !state.autoEnabled;
  saveState();
  updateView();
  syncAutoTimer();
  showToast(state.autoEnabled ? "自动按键已开启" : "自动按键已关闭");
}

function syncAutoTimer() {
  window.clearInterval(autoTimer);
  autoTimer = 0;

  const rate = getAutoRate();
  if (!state.autoEnabled || rate <= 0) {
    if (state.rebirths < 3 && state.autoEnabled) {
      state.autoEnabled = false;
      saveState();
      updateView();
    }
    return;
  }

  autoTimer = window.setInterval(() => {
    addPoint(null, { source: "auto" });
  }, 1000 / rate);
}

function toggleAdminMode() {
  if (adminMode) {
    adminMode = false;
    adminPanelEl.hidden = true;
    adminToggleEl.classList.remove("active");
    adminToggleEl.textContent = "管理员";
    showToast("管理员模式已关闭");
    return;
  }

  adminPasswordEl.value = "123456";
  adminPasswordHintEl.textContent = "";
  adminPasswordDialogEl.showModal();
  adminPasswordEl.focus();
}

function enterAdminMode() {
  adminMode = true;
  adminPanelEl.hidden = false;
  adminToggleEl.classList.add("active");
  adminToggleEl.textContent = "关闭管理员";
  fillAdminPanel();
  showToast("管理员模式已开启");
}

function applyAdminChanges() {
  const nextScore = Number(adminScoreEl.value);
  const nextRebirths = Number(adminRebirthsEl.value);
  const nextMultiplier = Number(adminMultiplierEl.value);

  if (!Number.isFinite(nextScore) || nextScore < 0) {
    showToast("摸鱼值必须大于等于 0");
    return;
  }

  if (!Number.isFinite(nextRebirths) || nextRebirths < 0) {
    showToast("重生次数必须大于等于 0");
    return;
  }

  if (!Number.isFinite(nextMultiplier) || nextMultiplier <= 0) {
    showToast("倍率必须大于 0");
    return;
  }

  state.score = nextScore;
  state.rebirths = Math.floor(nextRebirths);
  state.multiplierOverride = nextMultiplier;
  state.autoEnabled = state.rebirths >= 3 && adminAutoEnabledEl.checked;
  saveState();
  updateView();
  syncAutoTimer();
  showToast("管理员修改已保存");
}

function restoreDefaultMultiplier() {
  state.multiplierOverride = null;
  saveState();
  updateView();
  showToast(`倍率已恢复默认：${formatMultiplier(getMultiplier())}`);
}

fishEl.addEventListener("pointerdown", (event) => {
  if (event.button !== 0) return;
  event.preventDefault();
  addPoint(event, { source: "mouse" });
});

window.addEventListener("keydown", (event) => {
  if (event.repeat) return;
  if (rebirthDialogEl.open || adminPasswordDialogEl.open || isTypingTarget(event.target)) return;
  if ([" ", "ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(event.key)) {
    event.preventDefault();
  }
  addPoint(null, { source: "keyboard" });
});

resetEl.addEventListener("click", () => {
  state.score = 0;
  saveState();
  updateView();
  showToast("摸鱼值已清零");
});

rebirthEl.addEventListener("click", openRebirthDialog);
confirmRebirthEl.addEventListener("click", confirmRebirth);
autoKeyEl.addEventListener("click", toggleAutoKey);
adminToggleEl.addEventListener("click", toggleAdminMode);
adminApplyEl.addEventListener("click", applyAdminChanges);
adminDefaultMultiplierEl.addEventListener("click", restoreDefaultMultiplier);

adminPasswordFormEl.addEventListener("submit", (event) => {
  event.preventDefault();
  if (adminPasswordEl.value === adminPassword) {
    adminPasswordDialogEl.close();
    enterAdminMode();
  } else {
    adminPasswordHintEl.textContent = "密码错误";
    adminPasswordEl.select();
  }
});

adminPasswordCancelEl.addEventListener("click", () => {
  adminPasswordDialogEl.close();
});

if (state.rebirths < 3 && state.autoEnabled) {
  state.autoEnabled = false;
  saveState();
}

updateView();
syncAutoTimer();
