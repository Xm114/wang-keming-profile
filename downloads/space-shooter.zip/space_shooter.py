import math
import random
import sys
from dataclasses import dataclass
from pathlib import Path

try:
    import pygame
except ImportError:
    print("缺少 pygame。请先运行: python -m pip install pygame")
    raise


WIDTH, HEIGHT = 1000, 650
WORLD_WIDTH, WORLD_HEIGHT = 2600, 900
FPS = 60

GRAVITY = 0.75
MOVE_SPEED = 5.3
JUMP_SPEED = -15
PLAYER_WIDTH = 50
PLAYER_HEIGHT = 60
PISTOL_MAX_DIMENSION = PLAYER_HEIGHT // 2
MAX_HP = 100

MAX_AMMO = 12
RELOAD_TIME = 1050
FIRE_COOLDOWN = 150
BULLET_SPEED = 15
BULLET_LIFE = 900
MEDICINE_COOLDOWN = 25000
MEDICINE_DURATION = 5000
MEDICINE_HEAL_PER_SECOND = 5

BLUE = (47, 127, 255)
RED = (220, 55, 55)
DARK_RED = (145, 30, 30)
YELLOW = (255, 218, 75)
BG = (17, 21, 31)
FLOOR = (82, 90, 106)
PLATFORM = (112, 125, 145)
WHITE = (238, 241, 247)
MUTED = (165, 174, 190)
GREEN = (80, 220, 140)
BLACK = (0, 0, 0)
BROWN = (145, 92, 42)
SLOT_BG = (30, 36, 49)
SLOT_BORDER = (95, 108, 130)
SLOT_ACTIVE = (255, 218, 75)
MED_RED = (225, 62, 80)
LADDER_WIDTH = 18
CLIMB_SPEED = 4.2
ACTIVE_ENEMY_TARGET = 8
ENEMY_SIZE = 34
ENEMY_SPAWN_MARGIN = 14
ENEMY_MIN_PLAYER_DISTANCE = 220
ROOT = Path(__file__).resolve().parent
DOG_IMAGE_PATH = ROOT / "dog_player.png"
PISTOL_IMAGE_PATH = ROOT / "m1911_pistol.png"


def clamp(value, low, high):
    return max(low, min(high, value))


def draw_gun_model(surface, x, y, scale=1, facing=1):
    barrel_w = int(30 * scale)
    barrel_h = int(8 * scale)
    grip_w = int(8 * scale)
    grip_h = int(18 * scale)

    if facing >= 0:
        barrel = pygame.Rect(int(x), int(y), barrel_w, barrel_h)
        grip = pygame.Rect(int(x + 2 * scale), int(y + barrel_h), grip_w, grip_h)
    else:
        barrel = pygame.Rect(int(x - barrel_w), int(y), barrel_w, barrel_h)
        grip = pygame.Rect(int(x - grip_w - 2 * scale), int(y + barrel_h), grip_w, grip_h)

    pygame.draw.rect(surface, BLACK, barrel)
    pygame.draw.rect(surface, BLACK, grip)


def draw_pistol_sprite(surface, pistol_images, x, y, facing=1, anchor="midleft"):
    if not pistol_images:
        draw_gun_model(surface, x, y, scale=0.75, facing=facing)
        return

    image = pistol_images[1 if facing >= 0 else -1]
    image_rect = image.get_rect()
    setattr(image_rect, anchor, (int(x), int(y)))
    surface.blit(image, image_rect)


def draw_medicine_icon(surface, rect, progress=1):
    bottle = pygame.Rect(rect.centerx - 10, rect.centery - 13, 20, 26)
    pygame.draw.rect(surface, MED_RED, bottle, border_radius=4)
    pygame.draw.rect(surface, WHITE, (bottle.centerx - 3, bottle.y + 5, 6, 16), border_radius=1)
    pygame.draw.rect(surface, WHITE, (bottle.x + 4, bottle.centery - 3, 12, 6), border_radius=1)
    if progress < 1:
        shade = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 135))
        surface.blit(shade, rect.topleft)
        cover_height = int(rect.height * (1 - progress))
        pygame.draw.rect(surface, (22, 25, 34), (rect.x, rect.y, rect.width, cover_height), border_radius=8)


def load_player_images():
    if not DOG_IMAGE_PATH.exists():
        return None

    left_image = pygame.image.load(str(DOG_IMAGE_PATH)).convert_alpha()
    scale = PLAYER_HEIGHT / left_image.get_height()
    size = (int(left_image.get_width() * scale), PLAYER_HEIGHT)
    left_image = pygame.transform.smoothscale(left_image, size)
    right_image = pygame.transform.flip(left_image, True, False)
    return {-1: left_image, 1: right_image}


def load_pistol_images():
    if not PISTOL_IMAGE_PATH.exists():
        return None

    right_image = pygame.image.load(str(PISTOL_IMAGE_PATH)).convert_alpha()
    scale = PISTOL_MAX_DIMENSION / max(right_image.get_width(), right_image.get_height())
    size = (max(1, int(right_image.get_width() * scale)), max(1, int(right_image.get_height() * scale)))
    right_image = pygame.transform.smoothscale(right_image, size)
    left_image = pygame.transform.flip(right_image, True, False)
    return {-1: left_image, 1: right_image}


@dataclass
class Bullet:
    x: float
    y: float
    vx: float
    vy: float
    born: int
    owner: str

    @property
    def rect(self):
        return pygame.Rect(int(self.x) - 4, int(self.y) - 4, 8, 8)

    def update(self, now):
        self.x += self.vx
        self.y += self.vy
        if now - self.born > BULLET_LIFE:
            return False
        return 0 <= self.x <= WORLD_WIDTH and 0 <= self.y <= WORLD_HEIGHT

    def draw(self, surface, camera_x, camera_y):
        pygame.draw.circle(surface, YELLOW, (int(self.x - camera_x), int(self.y - camera_y)), 4)


class Actor:
    def __init__(self, x, y, size, color):
        if isinstance(size, tuple):
            self.rect = pygame.Rect(x, y, size[0], size[1])
        else:
            self.rect = pygame.Rect(x, y, size, size)
        self.color = color
        self.vx = 0
        self.vy = 0
        self.on_ground = False
        self.hp = 100
        self.facing = 1

    def move_and_collide(self, platforms, apply_gravity=True, ignore_vertical_collisions=False):
        self.rect.x += int(self.vx)
        self.rect.x = clamp(self.rect.x, 0, WORLD_WIDTH - self.rect.width)
        for block in platforms:
            if self.rect.colliderect(block):
                if self.vx > 0:
                    self.rect.right = block.left
                elif self.vx < 0:
                    self.rect.left = block.right

        if apply_gravity:
            self.vy += GRAVITY
        self.vy = min(self.vy, 18)
        self.rect.y += int(self.vy)
        self.on_ground = False
        if not ignore_vertical_collisions:
            for block in platforms:
                if self.rect.colliderect(block):
                    if self.vy > 0:
                        self.rect.bottom = block.top
                        self.vy = 0
                        self.on_ground = True
                    elif self.vy < 0:
                        self.rect.top = block.bottom
                        self.vy = 0

        if self.rect.bottom > WORLD_HEIGHT:
            self.rect.bottom = WORLD_HEIGHT
            self.vy = 0
            self.on_ground = True

    def draw(self, surface, camera_x, camera_y):
        pygame.draw.rect(surface, self.color, self.rect.move(-camera_x, -camera_y), border_radius=3)


class Player(Actor):
    def __init__(self, x, y):
        super().__init__(x, y, (PLAYER_WIDTH, PLAYER_HEIGHT), BLUE)
        self.hp = MAX_HP
        self.ammo = MAX_AMMO
        self.reloading = False
        self.reload_started = 0
        self.last_shot = -FIRE_COOLDOWN
        self.kills = 0
        self.facing = -1
        self.selected_item = 1
        self.medicine_last_used = -MEDICINE_COOLDOWN
        self.medicine_active_until = 0
        self.medicine_last_tick = 0

    def start_reload(self, now):
        if not self.reloading and self.ammo < MAX_AMMO:
            self.reloading = True
            self.reload_started = now

    def update_reload(self, now):
        if self.reloading and now - self.reload_started >= RELOAD_TIME:
            self.ammo = MAX_AMMO
            self.reloading = False

    def medicine_ready(self, now):
        return now - self.medicine_last_used >= MEDICINE_COOLDOWN

    def use_medicine(self, now):
        if not self.medicine_ready(now) or self.hp >= MAX_HP:
            return
        self.medicine_last_used = now
        self.medicine_active_until = now + MEDICINE_DURATION
        self.medicine_last_tick = now

    def update_medicine(self, now):
        if now <= self.medicine_last_tick or self.medicine_last_tick >= self.medicine_active_until:
            return
        heal_until = min(now, self.medicine_active_until)
        elapsed = (heal_until - self.medicine_last_tick) / 1000
        self.hp = clamp(self.hp + MEDICINE_HEAL_PER_SECOND * elapsed, 0, MAX_HP)
        self.medicine_last_tick = heal_until

    def shoot(self, mouse_pos, camera_x, camera_y, now, bullets):
        if self.reloading or self.ammo <= 0 or now - self.last_shot < FIRE_COOLDOWN:
            return

        target_x = mouse_pos[0] + camera_x
        target_y = mouse_pos[1] + camera_y
        start_x = self.rect.centerx
        start_y = self.rect.centery
        dx = target_x - start_x
        dy = target_y - start_y
        dist = math.hypot(dx, dy) or 1
        vx = dx / dist * BULLET_SPEED
        vy = dy / dist * BULLET_SPEED
        bullets.append(Bullet(start_x, start_y, vx, vy, now, "player"))
        self.ammo -= 1
        self.last_shot = now
        if self.ammo == 0:
            self.start_reload(now)

    def touched_ladder(self, ladders):
        touch_rect = self.rect.inflate(4, 0)
        for ladder in ladders:
            if touch_rect.colliderect(ladder):
                return ladder
        return None

    def draw(self, surface, camera_x, camera_y, player_images=None, pistol_images=None):
        screen_rect = self.rect.move(-camera_x, -camera_y)
        if player_images:
            image = player_images[self.facing]
            image_rect = image.get_rect(midbottom=screen_rect.midbottom)
            surface.blit(image, image_rect)
        else:
            pygame.draw.rect(surface, self.color, screen_rect, border_radius=3)

        if self.selected_item == 1:
            gun_x = screen_rect.right - 4 if self.facing >= 0 else screen_rect.left + 4
            gun_y = screen_rect.top + int(screen_rect.height * 0.52)
            anchor = "midleft" if self.facing >= 0 else "midright"
            draw_pistol_sprite(surface, pistol_images, gun_x, gun_y, self.facing, anchor)


class Enemy(Actor):
    def __init__(self, x, y, patrol_left, patrol_right):
        super().__init__(x, y, ENEMY_SIZE, RED)
        self.hp = 45
        self.speed = random.choice([2.0, 2.3, 2.6])
        self.direction = random.choice([-1, 1])
        self.patrol_left = patrol_left
        self.patrol_right = patrol_right
        self.attack_cooldown = 0

    def update_ai(self, player, platforms, now):
        distance_x = player.rect.centerx - self.rect.centerx
        distance_y = abs(player.rect.centery - self.rect.centery)
        can_chase = abs(distance_x) < 520 and distance_y < 190

        if can_chase:
            self.direction = 1 if distance_x > 0 else -1
            self.vx = self.direction * (self.speed + 0.8)
        else:
            self.vx = self.direction * self.speed
            if self.rect.left <= self.patrol_left or self.rect.right >= self.patrol_right:
                self.direction *= -1

        self.facing = self.direction
        self.move_and_collide(platforms)

        if self.rect.colliderect(player.rect) and now >= self.attack_cooldown:
            player.hp -= 10
            push = 14 if player.rect.centerx > self.rect.centerx else -14
            player.rect.x = clamp(player.rect.x + push, 0, WORLD_WIDTH - player.rect.width)
            player.vy = -8
            self.attack_cooldown = now + 650

    def draw(self, surface, camera_x, camera_y):
        screen_rect = self.rect.move(-camera_x, -camera_y)
        pygame.draw.rect(surface, self.color, screen_rect, border_radius=3)
        hp_width = int(screen_rect.width * max(self.hp, 0) / 45)
        pygame.draw.rect(surface, DARK_RED, (screen_rect.x, screen_rect.y - 8, screen_rect.width, 4))
        pygame.draw.rect(surface, GREEN, (screen_rect.x, screen_rect.y - 8, hp_width, 4))


def build_platforms():
    return [
        pygame.Rect(0, WORLD_HEIGHT - 60, WORLD_WIDTH, 80),
        pygame.Rect(150, 705, 330, 30),
        pygame.Rect(570, 625, 300, 30),
        pygame.Rect(980, 740, 420, 30),
        pygame.Rect(1330, 570, 280, 30),
        pygame.Rect(1740, 690, 350, 30),
        pygame.Rect(2190, 590, 280, 30),
        pygame.Rect(360, 460, 260, 28),
        pygame.Rect(760, 365, 260, 28),
        pygame.Rect(1160, 440, 270, 28),
        pygame.Rect(1600, 360, 310, 28),
        pygame.Rect(2050, 420, 290, 28),
    ]


def build_ladders():
    return [
        pygame.Rect(360, 460, LADDER_WIDTH, 245),
        pygame.Rect(760, 365, LADDER_WIDTH, 260),
        pygame.Rect(1160, 440, LADDER_WIDTH, 300),
        pygame.Rect(1892, 360, LADDER_WIDTH, 330),
        pygame.Rect(2190, 420, LADDER_WIDTH, 198),
    ]


def create_enemy_on_surface(surface):
    left = surface.left + ENEMY_SPAWN_MARGIN
    right = surface.right - ENEMY_SPAWN_MARGIN - ENEMY_SIZE
    if right < left:
        return None

    x = random.randint(left, right)
    y = surface.top - ENEMY_SIZE
    patrol_left = surface.left + ENEMY_SPAWN_MARGIN
    patrol_right = surface.right - ENEMY_SPAWN_MARGIN
    return Enemy(x, y, patrol_left, patrol_right)


def enemy_spawn_is_clear(enemy, platforms, player_rect, existing_enemies):
    if any(enemy.rect.colliderect(block) for block in platforms):
        return False
    if player_rect and enemy.rect.colliderect(player_rect.inflate(ENEMY_MIN_PLAYER_DISTANCE, 120)):
        return False
    if any(enemy.rect.colliderect(other.rect.inflate(16, 16)) for other in existing_enemies):
        return False
    return True


def spawn_enemy(platforms, player_rect=None, existing_enemies=None):
    existing_enemies = existing_enemies or []
    surfaces = [block for block in platforms if block.width >= ENEMY_SIZE + ENEMY_SPAWN_MARGIN * 2]
    if not surfaces:
        return None

    for _ in range(80):
        surface = random.choice(surfaces)
        enemy = create_enemy_on_surface(surface)
        if enemy and enemy_spawn_is_clear(enemy, platforms, player_rect, existing_enemies):
            return enemy

    surface = max(surfaces, key=lambda block: block.width)
    return create_enemy_on_surface(surface)


def spawn_enemies(platforms, player_rect):
    enemies = []
    while len(enemies) < ACTIVE_ENEMY_TARGET:
        enemy = spawn_enemy(platforms, player_rect, enemies)
        if enemy:
            enemies.append(enemy)
    return enemies


def draw_ladder(surface, ladder, camera_x, camera_y):
    x = ladder.centerx - camera_x
    top = ladder.top - camera_y
    bottom = ladder.bottom - camera_y
    pygame.draw.line(surface, BROWN, (x, top), (x, bottom), 6)
    for y in range(ladder.top + 18, ladder.bottom, 28):
        pygame.draw.circle(surface, (98, 60, 28), (x, y - camera_y), 4)


def draw_world(surface, platforms, ladders, player, enemies, bullets, camera_x, camera_y, player_images, pistol_images):
    surface.fill(BG)

    for x in range(0, WORLD_WIDTH, 120):
        sx = x - camera_x
        if -80 < sx < WIDTH + 80:
            pygame.draw.line(surface, (25, 31, 45), (sx, 0), (sx, HEIGHT), 1)
    for y in range(0, WORLD_HEIGHT, 120):
        sy = y - camera_y
        if -80 < sy < HEIGHT + 80:
            pygame.draw.line(surface, (25, 31, 45), (0, sy), (WIDTH, sy), 1)

    for block in platforms:
        rect = block.move(-camera_x, -camera_y)
        color = FLOOR if block.width > 1000 else PLATFORM
        pygame.draw.rect(surface, color, rect, border_radius=4)
        pygame.draw.rect(surface, (52, 59, 72), rect, 2, border_radius=4)

    for ladder in ladders:
        draw_ladder(surface, ladder, camera_x, camera_y)

    for bullet in bullets:
        bullet.draw(surface, camera_x, camera_y)
    for enemy in enemies:
        enemy.draw(surface, camera_x, camera_y)
    player.draw(surface, camera_x, camera_y, player_images, pistol_images)


def draw_inventory(surface, small_font, player, now, pistol_images):
    slot_size = 48
    gap = 10
    start_x = 315
    y = 4

    pistol_rect = pygame.Rect(start_x, y, slot_size, slot_size)
    medicine_rect = pygame.Rect(start_x + slot_size + gap, y, slot_size, slot_size)

    for index, rect in ((1, pistol_rect), (2, medicine_rect)):
        border_color = SLOT_ACTIVE if player.selected_item == index else SLOT_BORDER
        pygame.draw.rect(surface, SLOT_BG, rect, border_radius=9)
        pygame.draw.rect(surface, border_color, rect, 3, border_radius=9)

    draw_pistol_sprite(surface, pistol_images, pistol_rect.centerx, pistol_rect.centery + 2, 1, "center")

    cooldown_progress = clamp((now - player.medicine_last_used) / MEDICINE_COOLDOWN, 0, 1)
    draw_medicine_icon(surface, medicine_rect, cooldown_progress)

    for index, rect in ((1, pistol_rect), (2, medicine_rect)):
        number = small_font.render(str(index), True, WHITE)
        surface.blit(number, (rect.x + 5, rect.y + 3))

    if player.medicine_active_until > now:
        active_text = small_font.render("HEAL", True, GREEN)
        surface.blit(active_text, (medicine_rect.centerx - active_text.get_width() // 2, medicine_rect.bottom - 16))


def draw_hud(surface, font, small_font, player, enemies, now, game_over, victory, pistol_images):
    pygame.draw.rect(surface, (10, 13, 20), (0, 0, WIDTH, 54))
    pygame.draw.line(surface, (40, 47, 62), (0, 54), (WIDTH, 54), 2)

    hp_text = font.render(f"HP {int(max(player.hp, 0))}", True, WHITE)
    ammo_label = "RELOADING" if player.reloading else f"AMMO {player.ammo}/{MAX_AMMO}"
    ammo_text = font.render(ammo_label, True, WHITE if not player.reloading else YELLOW)
    help_text = small_font.render("1 pistol   2 medicine   LMB use   A/D move   SPACE jump/climb   R reload", True, MUTED)

    surface.blit(hp_text, (18, 14))
    surface.blit(ammo_text, (135, 14))
    draw_inventory(surface, small_font, player, now, pistol_images)
    surface.blit(help_text, (WIDTH - help_text.get_width() - 18, 18))

    pygame.draw.rect(surface, DARK_RED, (18, 42, 100, 7), border_radius=3)
    pygame.draw.rect(surface, GREEN, (18, 42, int(clamp(player.hp, 0, MAX_HP)), 7), border_radius=3)

    if player.reloading:
        progress = clamp((now - player.reload_started) / RELOAD_TIME, 0, 1)
        pygame.draw.rect(surface, (50, 50, 56), (135, 42, 110, 7), border_radius=3)
        pygame.draw.rect(surface, YELLOW, (135, 42, int(110 * progress), 7), border_radius=3)

    if game_over or victory:
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 150))
        surface.blit(overlay, (0, 0))
        title = "YOU WIN" if victory else "GAME OVER"
        title_color = GREEN if victory else RED
        title_img = font.render(title, True, title_color)
        retry_img = small_font.render("Press ENTER to restart or ESC to quit", True, WHITE)
        surface.blit(title_img, (WIDTH // 2 - title_img.get_width() // 2, HEIGHT // 2 - 35))
        surface.blit(retry_img, (WIDTH // 2 - retry_img.get_width() // 2, HEIGHT // 2 + 8))


def reset_game():
    player = Player(80, WORLD_HEIGHT - 130)
    platforms = build_platforms()
    ladders = build_ladders()
    enemies = spawn_enemies(platforms, player.rect)
    bullets = []
    return player, platforms, ladders, enemies, bullets


def main():
    pygame.init()
    pygame.display.set_caption("有限空间 2D 平面射击")
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()
    font = pygame.font.Font(None, 32)
    small_font = pygame.font.Font(None, 22)
    player_images = load_player_images()
    pistol_images = load_pistol_images()

    player, platforms, ladders, enemies, bullets = reset_game()
    game_over = False
    victory = False

    while True:
        dt = clock.tick(FPS)
        now = pygame.time.get_ticks()

        camera_x = clamp(player.rect.centerx - WIDTH // 2, 0, WORLD_WIDTH - WIDTH)
        camera_y = clamp(player.rect.centery - HEIGHT // 2, 0, WORLD_HEIGHT - HEIGHT)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                if event.key == pygame.K_RETURN and (game_over or victory):
                    player, platforms, ladders, enemies, bullets = reset_game()
                    game_over = False
                    victory = False
                if event.key == pygame.K_1 and not game_over and not victory:
                    player.selected_item = 1
                if event.key == pygame.K_2 and not game_over and not victory:
                    player.selected_item = 2
                if event.key == pygame.K_r and not game_over and not victory:
                    player.start_reload(now)
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and not game_over and not victory:
                if player.selected_item == 1:
                    player.shoot(pygame.mouse.get_pos(), camera_x, camera_y, now, bullets)
                elif player.selected_item == 2:
                    player.use_medicine(now)

        keys = pygame.key.get_pressed()
        mouse_buttons = pygame.mouse.get_pressed()

        if not game_over and not victory:
            ladder = player.touched_ladder(ladders)
            climbing = bool(ladder and keys[pygame.K_SPACE])

            player.vx = 0
            if keys[pygame.K_a]:
                player.vx -= MOVE_SPEED
                player.facing = -1
            if keys[pygame.K_d]:
                player.vx += MOVE_SPEED
                player.facing = 1

            if climbing:
                player.vy = -CLIMB_SPEED
                player.on_ground = False
                player.move_and_collide(platforms, apply_gravity=False, ignore_vertical_collisions=True)
            elif keys[pygame.K_SPACE] and player.on_ground:
                player.vy = JUMP_SPEED
                player.on_ground = False
                player.move_and_collide(platforms)
            else:
                player.move_and_collide(platforms)

            if mouse_buttons[0] and player.selected_item == 1:
                player.shoot(pygame.mouse.get_pos(), camera_x, camera_y, now, bullets)

            player.update_reload(now)
            player.update_medicine(now)

            for enemy in enemies:
                enemy.update_ai(player, platforms, now)

            alive_bullets = []
            for bullet in bullets:
                if not bullet.update(now):
                    continue
                hit_platform = any(bullet.rect.colliderect(block) for block in platforms)
                if hit_platform:
                    continue
                hit_enemy = False
                for enemy in enemies:
                    if bullet.owner == "player" and bullet.rect.colliderect(enemy.rect):
                        enemy.hp -= 18
                        hit_enemy = True
                        break
                if not hit_enemy:
                    alive_bullets.append(bullet)
            bullets = alive_bullets

            before = len(enemies)
            enemies = [enemy for enemy in enemies if enemy.hp > 0]
            player.kills += before - len(enemies)
            while len(enemies) < ACTIVE_ENEMY_TARGET:
                enemy = spawn_enemy(platforms, player.rect, enemies)
                if not enemy:
                    break
                enemies.append(enemy)

            if player.hp <= 0 or player.rect.top > WORLD_HEIGHT + 200:
                game_over = True

        draw_world(screen, platforms, ladders, player, enemies, bullets, camera_x, camera_y, player_images, pistol_images)
        draw_hud(screen, font, small_font, player, enemies, now, game_over, victory, pistol_images)
        pygame.display.flip()


if __name__ == "__main__":
    main()
